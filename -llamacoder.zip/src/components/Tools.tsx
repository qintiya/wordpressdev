import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Play, Pause, RotateCcw, Copy, Check, Plus, Minus } from "lucide-react";
import {
  SURAHS,
  CALLIGRAPHY_STYLES,
  ASMA_NAMES,
  DUAS,
  ISLAMIC_NAMES,
  HALAL_ADDITIVES,
  UMRAH_STEPS,
  PACKING_ITEMS,
  ISLAMIC_EVENTS,
} from "@/data/content";

type T = (k: string) => string;

/* ---------- Pegon converter ---------- */
const PEGON_MAP: Record<string, string> = {
  a: "ا", b: "ب", t: "ت", ts: "ث", j: "ج", h: "ح", kh: "خ", d: "د", dz: "ذ",
  r: "ر", z: "ز", s: "س", sy: "ش", sh: "ص", dl: "ض", th: "ط", zh: "ظ",
  "'": "ع", gh: "غ", f: "ف", q: "ق", k: "ك", l: "ل", m: "م", n: "ن", w: "و",
  y: "ي", i: "ي", u: "و", e: "ي", o: "و",
};

function latinToPegon(text: string): string {
  return text
    .toLowerCase()
    .split(/\s+/)
    .map((w) => {
      let out = "";
      let i = 0;
      while (i < w.length) {
        const two = w.slice(i, i + 2);
        const one = w[i];
        if (PEGON_MAP[two]) {
          out += PEGON_MAP[two];
          i += 2;
        } else if (PEGON_MAP[one]) {
          out += PEGON_MAP[one];
          i += 1;
        } else {
          out += one;
          i += 1;
        }
      }
      return out;
    })
    .join(" ");
}

export function PegonTool({ t }: { t: T }) {
  const [latin, setLatin] = useState("Bismillahirrahmanirrahim");
  const [pegon, setPegon] = useState("");
  const [copied, setCopied] = useState(false);
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Arabic Pegon Converter</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>Latin Transliteration</Label>
          <Textarea
            value={latin}
            onChange={(e) => setLatin(e.target.value)}
            className="mt-1.5"
            rows={3}
          />
        </div>
        <Button
          onClick={() => setPegon(latinToPegon(latin))}
          className="bg-emerald-700 hover:bg-emerald-800"
        >
          {t("convert")}
        </Button>
        <div>
          <Label>Arabic Pegon</Label>
          <div
            dir="rtl"
            className="mt-1.5 min-h-20 rounded-lg border border-emerald-200/70 bg-emerald-50/50 p-4 text-2xl leading-loose dark:border-emerald-900/60 dark:bg-emerald-950/30"
          >
            {pegon || "—"}
          </div>
        </div>
        {pegon && (
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5"
            onClick={() => {
              navigator.clipboard?.writeText(pegon);
              setCopied(true);
              setTimeout(() => setCopied(false), 1500);
            }}
          >
            {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? t("copied") : t("copy")}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

/* ---------- Hijri converter ---------- */
function gregorianToHijri(date: Date) {
  const jd = Math.floor((date.getTime() - Date.UTC(1970, 0, 1)) / 86400000) + 2440588;
  const l = jd - 1948440 + 10632;
  const n = Math.floor((l - 1) / 10631);
  let l2 = l - 10631 * n + 354;
  const j =
    Math.floor((10985 - l2) / 5316) * Math.floor((50 * l2) / 17719) +
    Math.floor(l2 / 5670) * Math.floor((43 * l2) / 15238);
  l2 =
    l2 -
    Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) -
    Math.floor(j / 16) * Math.floor((15238 * j) / 43) +
    29;
  const month = Math.floor((24 * l2) / 709);
  const day = l2 - Math.floor((709 * month) / 24);
  const year = 30 * n + j - 30;
  const months = [
    "Muharram", "Safar", "Rabi' al-Awwal", "Rabi' al-Thani", "Jumada al-Ula",
    "Jumada al-Akhirah", "Rajab", "Sha'ban", "Ramadan", "Shawwal",
    "Dhu al-Qi'dah", "Dhu al-Hijjah",
  ];
  return { day, month: months[month - 1] ?? "", year };
}

export function HijriTool({ t }: { t: T }) {
  const [value, setValue] = useState(new Date().toISOString().slice(0, 10));
  const result = value ? gregorianToHijri(new Date(value)) : null;
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Hijri Date Converter</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>{t("gregorian")}</Label>
          <Input
            type="date"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            className="mt-1.5 max-w-xs"
          />
        </div>
        {result && (
          <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/60 p-5 dark:border-emerald-900/60 dark:bg-emerald-950/30">
            <p className="text-xs uppercase tracking-widest text-emerald-700/70 dark:text-emerald-300/60">
              {t("hijri")}
            </p>
            <p className="mt-1 font-serif text-2xl font-bold">
              {result.day} {result.month} {result.year} AH
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ---------- Timer & Stopwatch ---------- */
export function TimerTool({ t }: { t: T }) {
  const [mode, setMode] = useState<"stopwatch" | "timer">("stopwatch");
  const [ms, setMs] = useState(0);
  const [running, setRunning] = useState(false);
  const [timerSec, setTimerSec] = useState(60);
  const ref = useRef<number | null>(null);

  useEffect(() => {
    if (!running) return;
    ref.current = window.setInterval(() => {
      setMs((prev) => {
        if (mode === "timer") {
          const next = prev - 100;
          if (next <= 0) {
            setRunning(false);
            return 0;
          }
          return next;
        }
        return prev + 100;
      });
    }, 100);
    return () => {
      if (ref.current) window.clearInterval(ref.current);
    };
  }, [running, mode]);

  const fmt = (v: number) => {
    const total = Math.max(0, Math.floor(v / 1000));
    const m = String(Math.floor(total / 60)).padStart(2, "0");
    const s = String(total % 60).padStart(2, "0");
    const cs = String(Math.floor((Math.max(0, v) % 1000) / 10)).padStart(2, "0");
    return `${m}:${s}.${cs}`;
  };

  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Timer &amp; Stopwatch</CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="flex gap-2">
          <Button
            variant={mode === "stopwatch" ? "default" : "outline"}
            onClick={() => {
              setMode("stopwatch");
              setRunning(false);
              setMs(0);
            }}
            className={mode === "stopwatch" ? "bg-emerald-700 hover:bg-emerald-800" : ""}
          >
            {t("stopwatch")}
          </Button>
          <Button
            variant={mode === "timer" ? "default" : "outline"}
            onClick={() => {
              setMode("timer");
              setRunning(false);
              setMs(timerSec * 1000);
            }}
            className={mode === "timer" ? "bg-emerald-700 hover:bg-emerald-800" : ""}
          >
            {t("timer")}
          </Button>
        </div>

        {mode === "timer" && (
          <div>
            <Label>Seconds</Label>
            <Input
              type="number"
              min={1}
              value={timerSec}
              onChange={(e) => {
                const v = Number(e.target.value) || 1;
                setTimerSec(v);
                setMs(v * 1000);
              }}
              className="mt-1.5 w-28"
            />
          </div>
        )}

        <div className="rounded-2xl bg-emerald-950 p-8 text-center">
          <p className="font-mono text-4xl font-bold tracking-wider text-amber-300 sm:text-5xl">
            {fmt(ms)}
          </p>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={() => setRunning(!running)}
            className="gap-2 bg-emerald-700 hover:bg-emerald-800"
          >
            {running ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {running ? t("pause") : t("start")}
          </Button>
          <Button
            variant="outline"
            className="gap-2"
            onClick={() => {
              setRunning(false);
              setMs(mode === "timer" ? timerSec * 1000 : 0);
            }}
          >
            <RotateCcw className="h-4 w-4" /> {t("reset")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Calligraphy ---------- */
export function CalligraphyTool({ t }: { t: T }) {
  const [text, setText] = useState("بسم الله الرحمن الرحيم");
  const [style, setStyle] = useState(CALLIGRAPHY_STYLES[0]);
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Arabic Calligraphy</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>Arabic Text</Label>
          <Textarea
            dir="rtl"
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="mt-1.5 text-xl"
            rows={2}
          />
        </div>
        <div>
          <Label>Style</Label>
          <Select value={style} onValueChange={setStyle}>
            <SelectTrigger className="mt-1.5 w-56">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CALLIGRAPHY_STYLES.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="rounded-2xl border border-amber-200/70 bg-gradient-to-br from-amber-50 to-emerald-50 p-8 text-center dark:border-amber-900/40 dark:from-emerald-950/40 dark:to-amber-950/20">
          <p
            dir="rtl"
            className="font-serif text-4xl leading-loose text-emerald-900 dark:text-amber-200 sm:text-5xl"
          >
            {text}
          </p>
          <Badge variant="secondary" className="mt-4">
            {style}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Quran / Murotal ---------- */
export function QuranTool({ t, audio }: { t: T; audio: boolean }) {
  const [surah, setSurah] = useState(SURAHS[0]);
  const [playing, setPlaying] = useState(false);
  const idx = SURAHS.indexOf(surah) + 1;
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">{audio ? "Murotal 30 Juz" : "Digital Quran"}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>Surah</Label>
          <Select value={surah} onValueChange={setSurah}>
            <SelectTrigger className="mt-1.5 w-full max-w-md">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="max-h-72">
              {SURAHS.map((s, i) => (
                <SelectItem key={s} value={s}>
                  {i + 1}. {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/60 p-5 dark:border-emerald-900/60 dark:bg-emerald-950/30">
          <p className="text-xs uppercase tracking-widest text-emerald-700/70 dark:text-emerald-300/60">
            Surah {idx} · {surah}
          </p>
          <p dir="rtl" className="mt-3 font-serif text-2xl leading-loose">
            بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
          </p>
          <p className="mt-3 text-sm text-muted-foreground">
            In the name of Allah, the Most Gracious, the Most Merciful.
          </p>
        </div>
        {audio && (
          <Button
            onClick={() => setPlaying(!playing)}
            className="gap-2 bg-emerald-700 hover:bg-emerald-800"
          >
            {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {playing ? t("stop") : t("listen")}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

/* ---------- Zakat ---------- */
export function ZakatTool({ t }: { t: T }) {
  const [wealth, setWealth] = useState(10000000);
  const zakat = wealth * 0.025;
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Zakat Calculator</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>Total Wealth (IDR)</Label>
          <Input
            type="number"
            value={wealth}
            onChange={(e) => setWealth(Number(e.target.value) || 0)}
            className="mt-1.5 max-w-xs"
          />
        </div>
        <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/60 p-5 dark:border-emerald-900/60 dark:bg-emerald-950/30">
          <p className="text-xs uppercase tracking-widest text-emerald-700/70 dark:text-emerald-300/60">
            Zakat (2.5%)
          </p>
          <p className="mt-1 font-serif text-2xl font-bold">
            Rp {zakat.toLocaleString("id-ID")}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Tasbeeh ---------- */
export function TasbeehTool({ t }: { t: T }) {
  const [count, setCount] = useState(0);
  const [target, setTarget] = useState(33);
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Tasbeeh Counter</CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div>
          <Label>Target</Label>
          <Input
            type="number"
            min={1}
            value={target}
            onChange={(e) => setTarget(Number(e.target.value) || 1)}
            className="mt-1.5 w-28"
          />
        </div>
        <button
          onClick={() => setCount((c) => (c + 1 > target ? 1 : c + 1))}
          className="grid h-44 w-44 place-items-center rounded-full bg-gradient-to-br from-emerald-600 to-emerald-800 text-5xl font-bold text-amber-200 shadow-lg transition-transform active:scale-95"
        >
          {count}
        </button>
        <div>
          <Button variant="outline" onClick={() => setCount(0)} className="gap-2">
            <RotateCcw className="h-4 w-4" /> {t("reset")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Prayer times ---------- */
export function PrayerTimesTool({ t }: { t: T }) {
  const times = [
    { name: "Fajr", time: "04:32" },
    { name: "Dhuhr", time: "11:58" },
    { name: "Asr", time: "15:18" },
    { name: "Maghrib", time: "17:56" },
    { name: "Isha", time: "19:08" },
  ];
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Prayer Times</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {times.map((x) => (
          <div
            key={x.name}
            className="flex items-center justify-between rounded-xl border border-emerald-200/70 bg-emerald-50/50 px-4 py-3 dark:border-emerald-900/60 dark:bg-emerald-950/30"
          >
            <span className="font-medium">{x.name}</span>
            <span className="font-mono text-lg font-semibold text-emerald-800 dark:text-emerald-300">
              {x.time}
            </span>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

/* ---------- Qibla ---------- */
export function QiblaTool({ t }: { t: T }) {
  const [lat, setLat] = useState(-6.2088);
  const [lng, setLng] = useState(106.8456);
  const kaabaLat = 21.4225;
  const kaabaLng = 39.8262;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const toDeg = (r: number) => (r * 180) / Math.PI;
  const dLng = toRad(kaabaLng - lng);
  const y = Math.sin(dLng) * Math.cos(toRad(kaabaLat));
  const x =
    Math.cos(toRad(lat)) * Math.sin(toRad(kaabaLat)) -
    Math.sin(toRad(lat)) * Math.cos(toRad(kaabaLat)) * Math.cos(dLng);
  const bearing = (toDeg(Math.atan2(y, x)) + 360) % 360;
  const R = 6371;
  const dLat = toRad(kaabaLat - lat);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat)) * Math.cos(toRad(kaabaLat)) * Math.sin(dLng / 2) ** 2;
  const distance = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Qibla Finder</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <Label>Latitude</Label>
            <Input
              type="number"
              value={lat}
              onChange={(e) => setLat(Number(e.target.value))}
              className="mt-1.5"
            />
          </div>
          <div>
            <Label>Longitude</Label>
            <Input
              type="number"
              value={lng}
              onChange={(e) => setLng(Number(e.target.value))}
              className="mt-1.5"
            />
          </div>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/60 p-5 text-center dark:border-emerald-900/60 dark:bg-emerald-950/30">
            <p className="text-xs uppercase tracking-widest text-emerald-700/70 dark:text-emerald-300/60">
              {t("bearing")}
            </p>
            <p className="mt-1 font-serif text-3xl font-bold">{bearing.toFixed(1)}°</p>
          </div>
          <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/60 p-5 text-center dark:border-emerald-900/60 dark:bg-emerald-950/30">
            <p className="text-xs uppercase tracking-widest text-emerald-700/70 dark:text-emerald-300/60">
              {t("distance")}
            </p>
            <p className="mt-1 font-serif text-3xl font-bold">{distance.toFixed(0)} km</p>
          </div>
        </div>
        <div className="flex justify-center">
          <div className="relative grid h-40 w-40 place-items-center rounded-full border-4 border-emerald-200 dark:border-emerald-900">
            <div
              className="absolute h-1 w-16 origin-left rounded-full bg-emerald-700"
              style={{ transform: `rotate(${bearing - 90}deg) translateX(8px)` }}
            />
            <span className="text-2xl">🕋</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Salah tracker ---------- */
export function SalahTrackerTool({ t }: { t: T }) {
  const prayers = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"];
  const [done, setDone] = useState<Record<string, boolean>>({});
  const completed = prayers.filter((p) => done[p]).length;
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Salah Tracker</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          {prayers.map((p) => (
            <button
              key={p}
              onClick={() => setDone((d) => ({ ...d, [p]: !d[p] }))}
              className={`flex w-full items-center justify-between rounded-xl border px-4 py-3 transition-colors ${
                done[p]
                  ? "border-emerald-500 bg-emerald-100 dark:bg-emerald-900/50"
                  : "border-emerald-200/70 bg-emerald-50/50 hover:bg-emerald-100/60 dark:border-emerald-900/60 dark:bg-emerald-950/30"
              }`}
            >
              <span className="font-medium">{p}</span>
              {done[p] ? (
                <Check className="h-5 w-5 text-emerald-700 dark:text-emerald-300" />
              ) : (
                <span className="h-5 w-5 rounded-full border-2 border-emerald-300" />
              )}
            </button>
          ))}
        </div>
        <div>
          <div className="mb-1 flex justify-between text-sm">
            <span>{t("progress")}</span>
            <span>
              {completed} / {prayers.length}
            </span>
          </div>
          <Progress value={(completed / prayers.length) * 100} className="h-2" />
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Fasting tracker ---------- */
export function FastingTrackerTool({ t }: { t: T }) {
  const [days, setDays] = useState<boolean[]>(Array(30).fill(false));
  const count = days.filter(Boolean).length;
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Fasting Tracker</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-6 gap-2 sm:grid-cols-10">
          {days.map((d, i) => (
            <button
              key={i}
              onClick={() =>
                setDays((prev) => prev.map((v, j) => (j === i ? !v : v)))
              }
              className={`grid h-9 w-9 place-items-center rounded-lg text-xs font-semibold transition-colors ${
                d
                  ? "bg-emerald-700 text-white"
                  : "bg-emerald-50 text-emerald-800 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-300"
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
        <p className="text-sm text-muted-foreground">
          {count} / 30 {t("days")}
        </p>
      </CardContent>
    </Card>
  );
}

/* ---------- Dua library ---------- */
export function DuaTool({ t }: { t: T }) {
  const [q, setQ] = useState("");
  const list = DUAS.filter(
    (d) =>
      d.en.toLowerCase().includes(q.toLowerCase()) ||
      d.tr.toLowerCase().includes(q.toLowerCase())
  );
  const speak = (text: string) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "ar-SA";
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Dua Library</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Input placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="space-y-3">
          {list.map((d, i) => (
            <div
              key={i}
              className="rounded-xl border border-emerald-200/70 bg-emerald-50/50 p-4 dark:border-emerald-900/60 dark:bg-emerald-950/30"
            >
              <p dir="rtl" className="font-serif text-xl leading-loose">
                {d.ar}
              </p>
              <p className="mt-2 text-sm font-medium">{d.tr}</p>
              <p className="text-sm text-muted-foreground">{d.en}</p>
              <Button
                size="sm"
                variant="outline"
                className="mt-2 gap-1.5"
                onClick={() => speak(d.ar)}
              >
                <Play className="h-3.5 w-3.5" /> {t("listen")}
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- 99 Names ---------- */
export function AsmaTool({ t }: { t: T }) {
  const speak = (text: string) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "ar-SA";
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">99 Names of Allah</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {ASMA_NAMES.map((n, i) => (
            <button
              key={i}
              onClick={() => speak(n.ar)}
              className="rounded-xl border border-emerald-200/70 bg-emerald-50/50 p-4 text-left transition-colors hover:bg-emerald-100/60 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:hover:bg-emerald-900/40"
            >
              <p dir="rtl" className="font-serif text-2xl">
                {n.ar}
              </p>
              <p className="mt-1 font-semibold">{n.tr}</p>
              <p className="text-sm text-muted-foreground">{n.en}</p>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Arabic keyboard ---------- */
export function ArabicKeyboardTool({ t }: { t: T }) {
  const [text, setText] = useState("");
  const keys = "ابتثجحخدذرزسشصضطظعغفقكلمنهوي".split("");
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Arabic Keyboard</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          dir="rtl"
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="text-2xl"
          rows={3}
        />
        <div className="flex flex-wrap gap-2">
          {keys.map((k) => (
            <button
              key={k}
              onClick={() => setText((v) => v + k)}
              className="grid h-10 w-10 place-items-center rounded-lg border border-emerald-200/70 bg-emerald-50 text-xl transition-colors hover:bg-emerald-100 dark:border-emerald-900/60 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/50"
            >
              {k}
            </button>
          ))}
          <Button variant="outline" size="sm" onClick={() => setText("")}>
            {t("reset")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Faraid ---------- */
export function FaraidTool({ t }: { t: T }) {
  const [estate, setEstate] = useState(100000000);
  const [sons, setSons] = useState(1);
  const [daughters, setDaughters] = useState(1);
  const [spouse, setSpouse] = useState<"husband" | "wife" | "none">("wife");
  const [parents, setParents] = useState(false);

  let spouseShare = 0;
  if (spouse === "husband") spouseShare = 0.25;
  else if (spouse === "wife") spouseShare = 0.125;
  const parentShare = parents ? 0.1667 : 0;
  const remainder = Math.max(0, 1 - spouseShare - parentShare);
  const childUnits = sons * 2 + daughters;
  const perUnit = childUnits > 0 ? remainder / childUnits : 0;
  const sonShare = perUnit * 2;
  const daughterShare = perUnit;

  const fmt = (v: number) => `Rp ${Math.round(v).toLocaleString("id-ID")}`;

  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Inheritance Calculator (Faraid)</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>Estate Value (IDR)</Label>
          <Input
            type="number"
            value={estate}
            onChange={(e) => setEstate(Number(e.target.value) || 0)}
            className="mt-1.5 max-w-xs"
          />
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <div>
            <Label>Sons</Label>
            <Input
              type="number"
              min={0}
              value={sons}
              onChange={(e) => setSons(Number(e.target.value) || 0)}
              className="mt-1.5"
            />
          </div>
          <div>
            <Label>Daughters</Label>
            <Input
              type="number"
              min={0}
              value={daughters}
              onChange={(e) => setDaughters(Number(e.target.value) || 0)}
              className="mt-1.5"
            />
          </div>
          <div>
            <Label>Spouse</Label>
            <Select value={spouse} onValueChange={(v) => setSpouse(v as typeof spouse)}>
              <SelectTrigger className="mt-1.5">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="husband">Husband</SelectItem>
                <SelectItem value="wife">Wife</SelectItem>
                <SelectItem value="none">None</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={parents}
            onChange={(e) => setParents(e.target.checked)}
            className="h-4 w-4 rounded border-emerald-300"
          />
          Parents alive (combined 1/6)
        </label>
        <div className="space-y-2 rounded-xl border border-emerald-200/70 bg-emerald-50/60 p-5 dark:border-emerald-900/60 dark:bg-emerald-950/30">
          {spouse !== "none" && (
            <div className="flex justify-between">
              <span>Spouse</span>
              <span className="font-semibold">{fmt(estate * spouseShare)}</span>
            </div>
          )}
          {parents && (
            <div className="flex justify-between">
              <span>Parents</span>
              <span className="font-semibold">{fmt(estate * parentShare)}</span>
            </div>
          )}
          {sons > 0 && (
            <div className="flex justify-between">
              <span>Each son</span>
              <span className="font-semibold">{fmt(estate * sonShare)}</span>
            </div>
          )}
          {daughters > 0 && (
            <div className="flex justify-between">
              <span>Each daughter</span>
              <span className="font-semibold">{fmt(estate * daughterShare)}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Zakat al-Fitr ---------- */
export function FitrahTool({ t }: { t: T }) {
  const [people, setPeople] = useState(4);
  const [price, setPrice] = useState(15000);
  const total = people * price * 2.5;
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Zakat al-Fitr Calculator</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <Label>Number of People</Label>
            <Input
              type="number"
              min={1}
              value={people}
              onChange={(e) => setPeople(Number(e.target.value) || 1)}
              className="mt-1.5"
            />
          </div>
          <div>
            <Label>Price per kg (IDR)</Label>
            <Input
              type="number"
              min={0}
              value={price}
              onChange={(e) => setPrice(Number(e.target.value) || 0)}
              className="mt-1.5"
            />
          </div>
        </div>
        <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/60 p-5 dark:border-emerald-900/60 dark:bg-emerald-950/30">
          <p className="text-xs uppercase tracking-widest text-emerald-700/70 dark:text-emerald-300/60">
            {t("fitrah")} (2.5 kg {t("perPerson")})
          </p>
          <p className="mt-1 font-serif text-2xl font-bold">
            Rp {Math.round(total).toLocaleString("id-ID")}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Sadaqah tracker ---------- */
export function SadaqahTool({ t }: { t: T }) {
  const [items, setItems] = useState<{ note: string; amount: number }[]>([]);
  const [note, setNote] = useState("");
  const [amount, setAmount] = useState(0);
  const total = items.reduce((s, i) => s + i.amount, 0);
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Sadaqah Tracker</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <Label>Note</Label>
            <Input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="mt-1.5 w-48"
            />
          </div>
          <div>
            <Label>Amount (IDR)</Label>
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value) || 0)}
              className="mt-1.5 w-40"
            />
          </div>
          <Button
            onClick={() => {
              if (amount > 0) {
                setItems((v) => [...v, { note: note || "Sadaqah", amount }]);
                setNote("");
                setAmount(0);
              }
            }}
            className="gap-1.5 bg-emerald-700 hover:bg-emerald-800"
          >
            <Plus className="h-4 w-4" /> {t("add")}
          </Button>
        </div>
        <div className="space-y-2">
          {items.map((it, i) => (
            <div
              key={i}
              className="flex items-center justify-between rounded-xl border border-emerald-200/70 bg-emerald-50/50 px-4 py-2 dark:border-emerald-900/60 dark:bg-emerald-950/30"
            >
              <span>{it.note}</span>
              <span className="font-semibold">Rp {it.amount.toLocaleString("id-ID")}</span>
            </div>
          ))}
        </div>
        <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/60 p-5 dark:border-emerald-900/60 dark:bg-emerald-950/30">
          <p className="text-xs uppercase tracking-widest text-emerald-700/70 dark:text-emerald-300/60">
            {t("total")}
          </p>
          <p className="mt-1 font-serif text-2xl font-bold">
            Rp {total.toLocaleString("id-ID")}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Hajj savings planner ---------- */
export function HajjPlannerTool({ t }: { t: T }) {
  const [target, setTarget] = useState(50000000);
  const [monthly, setMonthly] = useState(2000000);
  const months = monthly > 0 ? Math.ceil(target / monthly) : 0;
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Hajj Savings Planner</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <Label>Target (IDR)</Label>
            <Input
              type="number"
              value={target}
              onChange={(e) => setTarget(Number(e.target.value) || 0)}
              className="mt-1.5"
            />
          </div>
          <div>
            <Label>Monthly Saving (IDR)</Label>
            <Input
              type="number"
              value={monthly}
              onChange={(e) => setMonthly(Number(e.target.value) || 0)}
              className="mt-1.5"
            />
          </div>
        </div>
        <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/60 p-5 dark:border-emerald-900/60 dark:bg-emerald-950/30">
          <p className="text-xs uppercase tracking-widest text-emerald-700/70 dark:text-emerald-300/60">
            {t("hajjPlanner")}
          </p>
          <p className="mt-1 font-serif text-2xl font-bold">
            {months} {t("months")}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Ramadan / Eid countdown ---------- */
export function CountdownTool({ t, kind }: { t: T; kind: "ramadan" | "eid" }) {
  const targetDate =
    kind === "ramadan" ? new Date("2026-02-18T00:00:00") : new Date("2026-03-20T00:00:00");
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);
  const diff = Math.max(0, targetDate.getTime() - now);
  const d = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  const cells = [
    { v: d, l: t("days") },
    { v: h, l: t("hours") },
    { v: m, l: t("minutes") },
    { v: s, l: t("seconds") },
  ];
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">
          {kind === "ramadan" ? "Ramadan Countdown" : "Eid Countdown"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-4 gap-3">
          {cells.map((c) => (
            <div
              key={c.l}
              className="rounded-xl bg-emerald-950 p-4 text-center"
            >
              <p className="font-serif text-3xl font-bold text-amber-300">{c.v}</p>
              <p className="text-xs text-emerald-200/70">{c.l}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Islamic events ---------- */
export function EventsTool({ t }: { t: T }) {
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Islamic Events Calendar</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {ISLAMIC_EVENTS.map((e) => (
          <div
            key={e.name}
            className="flex items-center justify-between rounded-xl border border-emerald-200/70 bg-emerald-50/50 px-4 py-3 dark:border-emerald-900/60 dark:bg-emerald-950/30"
          >
            <span className="font-medium">{e.name}</span>
            <Badge variant="secondary">{e.date}</Badge>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

/* ---------- Age in Hijri ---------- */
export function HijriAgeTool({ t }: { t: T }) {
  const [birth, setBirth] = useState("1995-01-01");
  const now = new Date();
  const b = new Date(birth);
  const days = Math.floor((now.getTime() - b.getTime()) / 86400000);
  const lunarYears = Math.floor(days / 354.367);
  const remDays = days - Math.floor(lunarYears * 354.367);
  const lunarMonths = Math.floor(remDays / 29.53);
  const lunarDays = Math.floor(remDays - lunarMonths * 29.53);
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Age in Hijri Calculator</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>Date of Birth</Label>
          <Input
            type="date"
            value={birth}
            onChange={(e) => setBirth(e.target.value)}
            className="mt-1.5 max-w-xs"
          />
        </div>
        <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/60 p-5 dark:border-emerald-900/60 dark:bg-emerald-950/30">
          <p className="text-xs uppercase tracking-widest text-emerald-700/70 dark:text-emerald-300/60">
            {t("age")}
          </p>
          <p className="mt-1 font-serif text-2xl font-bold">
            {lunarYears} {t("years")} {lunarMonths} {t("months")} {lunarDays} {t("days")}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Umrah guide ---------- */
export function UmrahTool({ t }: { t: T }) {
  const [step, setStep] = useState(0);
  const s = UMRAH_STEPS[step];
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Umrah Step-by-Step Guide</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          {UMRAH_STEPS.map((_, i) => (
            <span
              key={i}
              className={`h-2 flex-1 rounded-full ${
                i <= step ? "bg-emerald-600" : "bg-emerald-100 dark:bg-emerald-900/50"
              }`}
            />
          ))}
        </div>
        <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/60 p-5 dark:border-emerald-900/60 dark:bg-emerald-950/30">
          <p className="text-xs uppercase tracking-widest text-emerald-700/70 dark:text-emerald-300/60">
            {t("step")} {step + 1} {t("of")} {UMRAH_STEPS.length}
          </p>
          <p className="mt-1 font-serif text-xl font-bold">{s.title}</p>
          <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            disabled={step === 0}
            onClick={() => setStep((v) => Math.max(0, v - 1))}
          >
            {t("prevStep")}
          </Button>
          <Button
            disabled={step === UMRAH_STEPS.length - 1}
            onClick={() => setStep((v) => Math.min(UMRAH_STEPS.length - 1, v + 1))}
            className="bg-emerald-700 hover:bg-emerald-800"
          >
            {t("nextStep")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Packing checklist ---------- */
export function PackingTool({ t }: { t: T }) {
  const [checked, setChecked] = useState<Record<string, boolean>>({});
  const count = PACKING_ITEMS.filter((i) => checked[i]).length;
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Hajj &amp; Umrah Packing Checklist</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {PACKING_ITEMS.map((item) => (
          <button
            key={item}
            onClick={() => setChecked((c) => ({ ...c, [item]: !c[item] }))}
            className={`flex w-full items-center gap-3 rounded-xl border px-4 py-2.5 text-left transition-colors ${
              checked[item]
                ? "border-emerald-500 bg-emerald-100 dark:bg-emerald-900/50"
                : "border-emerald-200/70 bg-emerald-50/50 hover:bg-emerald-100/60 dark:border-emerald-900/60 dark:bg-emerald-950/30"
            }`}
          >
            <span
              className={`grid h-5 w-5 place-items-center rounded border-2 ${
                checked[item]
                  ? "border-emerald-600 bg-emerald-600 text-white"
                  : "border-emerald-300"
              }`}
            >
              {checked[item] && <Check className="h-3 w-3" />}
            </span>
            <span className="text-sm">{item}</span>
          </button>
        ))}
        <p className="text-sm text-muted-foreground">
          {count} / {PACKING_ITEMS.length} {t("completed")}
        </p>
      </CardContent>
    </Card>
  );
}

/* ---------- Name finder ---------- */
export function NameFinderTool({ t }: { t: T }) {
  const [q, setQ] = useState("");
  const [gender, setGender] = useState<"all" | "male" | "female">("all");
  const list = ISLAMIC_NAMES.filter(
    (n) =>
      (gender === "all" || n.gender === gender) &&
      (n.name.toLowerCase().includes(q.toLowerCase()) ||
        n.meaning.toLowerCase().includes(q.toLowerCase()))
  );
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Islamic Name Finder</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-3">
          <Input
            placeholder={t("searchNames")}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="max-w-xs"
          />
          <Select value={gender} onValueChange={(v) => setGender(v as typeof gender)}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("allCategories")}</SelectItem>
              <SelectItem value="male">{t("male")}</SelectItem>
              <SelectItem value="female">{t("female")}</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {list.map((n) => (
            <div
              key={n.name}
              className="rounded-xl border border-emerald-200/70 bg-emerald-50/50 p-4 dark:border-emerald-900/60 dark:bg-emerald-950/30"
            >
              <div className="flex items-center justify-between">
                <p className="font-semibold">{n.name}</p>
                <Badge variant="secondary">{n.gender}</Badge>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{n.meaning}</p>
              <p className="text-xs text-muted-foreground">
                {t("origin")}: {n.origin}
              </p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Halal checker ---------- */
export function HalalTool({ t }: { t: T }) {
  const [q, setQ] = useState("");
  const list = HALAL_ADDITIVES.filter(
    (a) =>
      a.code.toLowerCase().includes(q.toLowerCase()) ||
      a.name.toLowerCase().includes(q.toLowerCase())
  );
  const color = (s: string) =>
    s === "halal"
      ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300"
      : s === "haram"
      ? "bg-rose-100 text-rose-800 dark:bg-rose-900/50 dark:text-rose-300"
      : "bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300";
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Halal Food Additive Checker</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Input
          placeholder="E.g. E120, gelatin…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="max-w-xs"
        />
        <div className="space-y-2">
          {list.map((a) => (
            <div
              key={a.code}
              className="flex items-center justify-between rounded-xl border border-emerald-200/70 bg-emerald-50/50 px-4 py-3 dark:border-emerald-900/60 dark:bg-emerald-950/30"
            >
              <div>
                <p className="font-semibold">
                  {a.code} — {a.name}
                </p>
              </div>
              <span className={`rounded-full px-3 py-1 text-xs font-semibold ${color(a.status)}`}>
                {a.status}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Mosque finder ---------- */
export function MosqueTool({ t }: { t: T }) {
  const mosques = [
    { name: "Masjid Istiqlal", city: "Jakarta", lat: -6.1702, lng: 106.8314 },
    { name: "Masjid Nabawi", city: "Madinah", lat: 24.4686, lng: 39.6142 },
    { name: "Masjidil Haram", city: "Makkah", lat: 21.4225, lng: 39.8262 },
    { name: "Masjid Al-Aqsa", city: "Jerusalem", lat: 31.7784, lng: 35.2354 },
    { name: "Masjid Sultan Ahmed", city: "Istanbul", lat: 41.0054, lng: 28.9768 },
  ];
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">Mosque Finder</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {mosques.map((m) => (
          <div
            key={m.name}
            className="flex items-center justify-between rounded-xl border border-emerald-200/70 bg-emerald-50/50 px-4 py-3 dark:border-emerald-900/60 dark:bg-emerald-950/30"
          >
            <div>
              <p className="font-semibold">{m.name}</p>
              <p className="text-xs text-muted-foreground">{m.city}</p>
            </div>
            <a
              href={`https://www.google.com/maps?q=${m.lat},${m.lng}`}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800"
            >
              Map
            </a>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

/* ---------- CorelDRAW assets ---------- */
export function CorelTool({ t }: { t: T }) {
  const assets = [
    { name: "Arabic Calligraphy Vector Pack", size: "12 MB", type: "CDR" },
    { name: "Islamic Geometric Patterns", size: "8 MB", type: "CDR" },
    { name: "Ramadan Greeting Templates", size: "15 MB", type: "CDR" },
    { name: "Mosque Silhouette Collection", size: "6 MB", type: "CDR" },
  ];
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">CorelDRAW Arabic Assets</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {assets.map((a) => (
          <div
            key={a.name}
            className="flex items-center justify-between rounded-xl border border-emerald-200/70 bg-emerald-50/50 px-4 py-3 dark:border-emerald-900/60 dark:bg-emerald-950/30"
          >
            <div>
              <p className="font-semibold">{a.name}</p>
              <p className="text-xs text-muted-foreground">
                {a.type} · {a.size}
              </p>
            </div>
            <Button size="sm" variant="outline">
              Download
            </Button>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}