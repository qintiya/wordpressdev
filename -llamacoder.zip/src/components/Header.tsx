import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Moon, Sun, Search, Menu, X, Globe, BookOpen, Wrench, Home, Info } from "lucide-react";
import { LANGS, type Lang } from "@/lib/i18n";
import { CATEGORIES } from "@/data/content";

type Props = {
  t: (k: string) => string;
  lang: Lang;
  setLang: (l: Lang) => void;
  dark: boolean;
  setDark: (d: boolean) => void;
  section: string;
  go: (s: string) => void;
  query: string;
  setQuery: (q: string) => void;
};

export default function Header({ t, lang, setLang, dark, setDark, section, go, query, setQuery }: Props) {
  const [open, setOpen] = useState(false);

  const navItems = [
    { id: "home", label: t("home"), icon: Home },
    { id: "articles", label: t("articles"), icon: BookOpen },
    { id: "tools", label: t("tools"), icon: Wrench },
    { id: "about", label: t("about"), icon: Info },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-emerald-900/10 bg-emerald-950/95 backdrop-blur supports-[backdrop-filter]:bg-emerald-950/80">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:px-6">
        <button
          onClick={() => go("home")}
          className="flex items-center gap-2.5 transition-opacity hover:opacity-90"
        >
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-amber-400 to-emerald-500 text-lg font-bold text-emerald-950 shadow-md">
            ﷲ
          </span>
          <span className="text-left leading-tight">
            <span className="block font-serif text-lg font-bold tracking-wide text-amber-50">
              {t("brand")}
            </span>
            <span className="hidden text-[11px] text-emerald-200/70 sm:block">{t("tagline")}</span>
          </span>
        </button>

        <nav className="ml-4 hidden items-center gap-1 lg:flex">
          {navItems.map((n) => (
            <button
              key={n.id}
              onClick={() => go(n.id)}
              className={`rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                section === n.id
                  ? "bg-emerald-800/70 text-amber-50"
                  : "text-emerald-100/80 hover:bg-emerald-900/60 hover:text-amber-50"
              }`}
            >
              {n.label}
            </button>
          ))}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="rounded-lg px-3 py-2 text-sm font-medium text-emerald-100/80 transition-colors hover:bg-emerald-900/60 hover:text-amber-50">
                {t("categories")} ▾
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="max-h-80 w-64 overflow-y-auto">
              <DropdownMenuLabel>{t("allCategories")}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {CATEGORIES.map((c) => (
                <DropdownMenuItem key={c.id} onClick={() => go("articles")} className="justify-between">
                  <span>{c.name}</span>
                  <span className="text-xs text-muted-foreground">{c.count}</span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <div className="relative hidden md:block">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-200/60" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => go("articles")}
              placeholder={t("search")}
              className="w-56 border-emerald-800/60 bg-emerald-900/50 pl-9 text-amber-50 placeholder:text-emerald-200/50 focus-visible:ring-amber-400/40 lg:w-64"
            />
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="text-emerald-100 hover:bg-emerald-900/60 hover:text-amber-50"
                aria-label={t("language")}
              >
                <Globe className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuLabel>{t("language")}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {LANGS.map((l) => (
                <DropdownMenuItem
                  key={l.code}
                  onClick={() => setLang(l.code)}
                  className={lang === l.code ? "bg-accent font-semibold" : ""}
                >
                  <span className="mr-2">{l.flag}</span>
                  {l.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setDark(!dark)}
            className="text-emerald-100 hover:bg-emerald-900/60 hover:text-amber-50"
            aria-label={dark ? t("lightMode") : t("darkMode")}
          >
            {dark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="text-emerald-100 hover:bg-emerald-900/60 hover:text-amber-50 lg:hidden"
            onClick={() => setOpen(!open)}
            aria-label="Menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {open && (
        <div className="border-t border-emerald-900/40 bg-emerald-950 px-4 py-3 lg:hidden">
          <div className="relative mb-3">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-200/60" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t("search")}
              className="border-emerald-800/60 bg-emerald-900/50 pl-9 text-amber-50 placeholder:text-emerald-200/50"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            {navItems.map((n) => (
              <button
                key={n.id}
                onClick={() => {
                  go(n.id);
                  setOpen(false);
                }}
                className={`flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium ${
                  section === n.id ? "bg-emerald-800/70 text-amber-50" : "bg-emerald-900/40 text-emerald-100"
                }`}
              >
                <n.icon className="h-4 w-4" />
                {n.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}