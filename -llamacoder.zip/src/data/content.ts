export type Category = { id: string; name: string; count: number };

export type Article = {
  id: string; title: string; category: string; excerpt: string;
  author: string; date: string; readMin: number; views: number;
  tags: string[]; sections: { heading: string; body: string[] }[];
  faq: { q: string; a: string }[]; conclusion: string;
};

export type Tool = {
  id: string; name: string; desc: string; group: string; icon: string;
};

export const BACKLINKS = [
  "app.alhikmah.eu.org",
  "web.alhikmah.eu.org",
  "dev.alhikmah.eu.org",
  "alhikmah.my.id",
  "www.alhikmah.my.id",
  "www.alhikmah.eu.org",
  "meta.alhikmah.eu.org",
  "us.alhikmah.eu.org",
  "islamic.alhikmah.eu.org",
  "awdev.eu.org",
  "online.alhikmah.eu.org",
  "platfrom.alhikmah.eu.org",
  "website.alhikmah.eu.org",
  "mikrodinet.eu.org",
  "fastsong.eu.org",
  "awdev.my.id",
  "waumkm.xyz",
  "awdevglobal.blogspot.com",
  "enjhine.blogspot.com",
  "hosnic.blogspot.com",
  "www.paypal.com",
  "awdevmyid.github.io",
  "rumus-music.github.io",
  "mikrover.github.io",
  "waumkm.blogspot.com",
  "indoinves.netlify.app",
  "pawarta.github.io",
  "relmusic.github.io",
  "devfrok.github.io",
  "poindev.exblog.jp",
  "eeput.exblog.jp",
  "gifrok.exblog.jp",
  "pointdev.exblog.jp",
  "devfroka.exblog.jp",
  "flipe.exblog.jp",
  "catyzon.exblog.jp",
];

export const CATEGORIES: Category[] = [
  { id: "santri", name: "Santri Articles", count: 42 },
  { id: "blog", name: "Blog Series", count: 28 },
  { id: "scholar", name: "Scholar", count: 19 },
  { id: "book", name: "Download Book", count: 24 },
  { id: "fiqh", name: "Fiqh", count: 31 },
  { id: "tafsir", name: "Science of Interpretation", count: 17 },
  { id: "student", name: "Student Information", count: 12 },
  { id: "khutbah", name: "Friday Sermon", count: 15 },
  { id: "salihin", name: "The Story of Salihin", count: 22 },
  { id: "prayers", name: "Collection of Prayers", count: 26 },
  { id: "songs", name: "Islamic Songs", count: 9 },
  { id: "nahwu", name: "Nahwu", count: 14 },
  { id: "opinion", name: "Student Opinion", count: 11 },
  { id: "corner", name: "Student Corner", count: 8 },
  { id: "promo", name: "Promotional Post", count: 6 },
  { id: "ask", name: "Students Ask Questions", count: 13 },
  { id: "shorof", name: "Shorof", count: 10 },
  { id: "tajweed", name: "Tajweed and Tahsin of the Quran", count: 18 },
  { id: "sufism", name: "Sufism", count: 16 },
  { id: "tutorial", name: "Tutorial", count: 20 },
  { id: "quranic", name: "Quranic Insight", count: 23 },
  { id: "sunnah", name: "Sunnah Insight", count: 21 },
];

const AUTHORS = [
  "Ust. Ahmad Fauzi", "Ust. Muhammad Ridwan", "Ustadzah Nur Aisyah",
  "Ust. Hasan Basri", "Ust. Zainal Abidin", "Ust. Ibrahim Malik",
];

const TITLES: Record<string, string[]> = {
  santri: ["The Etiquette of a Santri Toward Their Teacher", "Living the Santri Life: Discipline, Devotion and Growth", "How Islamic Boarding Schools Shape Character"],
  blog: ["A Blog Series on Seeking Knowledge in the Digital Age", "Building a Consistent Islamic Reading Habit", "Reflections on Faith in Modern Life"],
  scholar: ["The Legacy of the Great Islamic Scholars", "Imam Al-Ghazali and the Revival of Religious Sciences", "How Scholars Preserved the Sunnah"],
  book: ["Free Islamic Books to Download This Month", "A Reading List for Every Muslim Student", "Classical Texts Every Beginner Should Read"],
  fiqh: ["The Fiqh of Purification: A Complete Guide", "Understanding the Rules of Prayer", "Fiqh of Transactions in Everyday Life"],
  tafsir: ["An Introduction to the Science of Tafsir", "How to Approach the Interpretation of the Quran", "The Schools of Quranic Exegesis"],
  student: ["Student Information: Preparing for the New Term", "Balancing Study and Worship", "A Guide for New Students of Knowledge"],
  khutbah: ["Friday Sermon: The Value of Gratitude", "Friday Sermon: Patience in Times of Trial", "Friday Sermon: The Rights of Neighbours"],
  salihin: ["The Story of Salihin: Lessons from the Righteous", "Stories of the Companions and Their Sacrifice", "Tales of Piety from the Early Generations"],
  prayers: ["A Collection of Daily Prayers and Dhikr", "Morning and Evening Adhkar Explained", "Duas for Every Occasion"],
  songs: ["Islamic Songs That Uplift the Soul", "The Tradition of Nasheed in Muslim Culture", "Poetry and Praise in Islamic Music"],
  nahwu: ["Nahwu for Beginners: Understanding Arabic Grammar", "The Role of I'rab in Quranic Reading", "Common Nahwu Mistakes and How to Fix Them"],
  opinion: ["Student Opinion: Faith and Modern Technology", "Why Young Muslims Should Study the Classical Sciences", "The Future of Islamic Education"],
  corner: ["Student Corner: Tips for Memorising the Quran", "Student Corner: Building a Study Routine", "Student Corner: Notes from the Classroom"],
  promo: ["Promotional Post: New Islamic Courses Available", "Announcing Our Latest Digital Tools", "Join Our Community of Learners"],
  ask: ["Students Ask Questions: On Prayer and Purity", "Students Ask Questions: About Zakat", "Students Ask Questions: On Family Life"],
  shorof: ["Shorof: The Morphology of Arabic Words", "Understanding Verb Patterns in Arabic", "Shorof Made Simple for Beginners"],
  tajweed: ["Tajweed and Tahsin: Perfecting Your Recitation", "The Rules of Noon and Meem", "A Beginner's Guide to Quranic Recitation"],
  sufism: ["Sufism: The Inner Dimension of Islam", "Purifying the Heart Through Remembrance", "The Path of Spiritual Refinement"],
  tutorial: ["Tutorial: Using Islamic Digital Tools Effectively", "Tutorial: How to Read the Quran Online", "Tutorial: Setting Up Your Prayer Tracker"],
  quranic: ["Quranic Insight: Reflections on Surah Al-Fatihah", "Quranic Insight: The Light of Ayat Al-Kursi", "Quranic Insight: Lessons from Surah Yasin"],
  sunnah: ["Sunnah Insight: The Prophet's Daily Habits", "Sunnah Insight: Kindness in Speech", "Sunnah Insight: The Etiquette of Eating"],
};

function buildSections(title: string, category: string) {
  return [
    { heading: "Introduction", body: [
      `This article, "${title}", explores the topic of ${category} from the perspective of the Quran and Sunnah. It is written to be accessible to every Muslim while remaining grounded in authentic sources.`,
      "We begin by establishing the foundations, then move through practical guidance, common questions, and a structured conclusion so that the reader leaves with clear, actionable understanding.",
      "The importance of this subject cannot be overstated. Throughout Islamic history, scholars have devoted their lives to clarifying these matters for the benefit of the ummah, and their works remain a source of guidance today.",
    ]},
    { heading: "Foundations and Sources", body: [
      "The primary sources of Islamic knowledge are the Quran and the authentic Sunnah. Every ruling and reflection in this article is traced back to these two foundations, supported by the understanding of the early generations.",
      "Scholars across the centuries have developed a rigorous methodology for deriving rulings. Understanding this methodology helps the reader distinguish between authentic practice and cultural custom.",
      "The science of hadith verification ensures that the narrations we rely upon are authentic. This rigorous process, developed over centuries, protects the religion from distortion and innovation.",
    ]},
    { heading: "Practical Guidance", body: [
      "Knowledge without action is incomplete. This section translates the theory into daily practice, offering steps that any reader can begin today regardless of their level of experience.",
      "Consistency matters more than intensity. Small, regular acts of worship and learning build a lasting foundation for a life of faith and service.",
      "Begin with what is obligatory, then gradually add the recommended acts. This approach, recommended by scholars, prevents burnout and builds sustainable habits.",
    ]},
    { heading: "Common Misconceptions", body: [
      "Many misunderstandings arise from incomplete knowledge or from relying on unverified sources. We address the most frequent questions and clarify them with evidence.",
      "It is always advisable to consult qualified scholars for personal circumstances, as each situation may carry specific considerations.",
      "The internet has made information widely available, but it has also spread misinformation. Always verify the source and check with qualified teachers.",
    ]},
    { heading: "Further Study", body: [
      "For those who wish to go deeper, we recommend studying the classical texts alongside modern commentaries, and joining a structured course with a qualified teacher.",
      "Our platform provides digital tools and a growing library of articles to support your journey of learning.",
      "May Allah grant us sincerity in seeking knowledge and the ability to act upon it. Ameen.",
    ]},
  ];
}

function buildFaq(title: string) {
  return [
    { q: `What is the main lesson of "${title}"?`, a: "The main lesson is to ground our understanding in the Quran and Sunnah, and to apply that knowledge with sincerity and consistency in daily life." },
    { q: "Are the sources used in this article authentic?", a: "Yes. We rely on the Quran, authentic hadith collections, and the works of recognised scholars. Every claim is referenced to a trusted source." },
    { q: "Can I share this article with others?", a: "Absolutely. Use the share buttons to send this article via WhatsApp, Facebook, Twitter/X, or Telegram, or copy the link directly." },
  ];
}

function makeArticle(catId: string, catName: string, title: string, index: number): Article {
  const seed = index + 1;
  return {
    id: `${catId}-${seed}`, title, category: catName,
    excerpt: `A detailed guide on ${catName.toLowerCase()} — grounded in the Quran and Sunnah, with practical steps and answers to common questions.`,
    author: AUTHORS[seed % AUTHORS.length],
    date: `2025-${String((seed % 12) + 1).padStart(2, "0")}-${String((seed % 27) + 1).padStart(2, "0")}`,
    readMin: 12 + (seed % 9), views: 1200 + seed * 137,
    tags: [catName, "Quran", "Sunnah", "Guidance"],
    sections: buildSections(title, catName),
    faq: buildFaq(title),
    conclusion: "In conclusion, this article has outlined the key principles, practical guidance, and common questions surrounding this topic. May Allah grant us beneficial knowledge and the ability to act upon it. We invite you to explore our other articles and digital tools to continue your journey of learning.",
  };
}

export const ARTICLES: Article[] = (() => {
  const out: Article[] = [];
  let i = 0;
  for (const cat of CATEGORIES) {
    const titles = TITLES[cat.id] ?? [`${cat.name}: A Complete Guide`];
    const target = Math.max(1, Math.round(cat.count / 3));
    for (let k = 0; k < target; k++) {
      const base = titles[k % titles.length];
      const title = k < titles.length ? base : `${base} (Part ${k + 1})`;
      out.push(makeArticle(cat.id, cat.name, title, i));
      i++;
    }
  }
  return out;
})();

export const TOOLS: Tool[] = [
  { id: "prayertimes", name: "Prayer Times", desc: "The five daily prayer times", group: "Worship & Daily Practice", icon: "🕌" },
  { id: "tasbeeh", name: "Tasbeeh", desc: "Count your dhikr", group: "Worship & Daily Practice", icon: "📿" },
  { id: "qibla", name: "Qibla Finder", desc: "Find the direction of the Kaaba", group: "Worship & Daily Practice", icon: "🧭" },
  { id: "salahtracker", name: "Salah Tracker", desc: "Log your daily prayers", group: "Worship & Daily Practice", icon: "✅" },
  { id: "fasting", name: "Fasting Tracker", desc: "Track your Ramadan fasts", group: "Worship & Daily Practice", icon: "🍽️" },
  { id: "dua", name: "Dua Library", desc: "Duas for every occasion", group: "Worship & Daily Practice", icon: "🤲" },
  { id: "asma", name: "99 Names of Allah", desc: "Learn the Asma ul-Husna", group: "Worship & Daily Practice", icon: "✨" },
  { id: "arabictext", name: "Arabic Keyboard", desc: "Type and preview Arabic text", group: "Worship & Daily Practice", icon: "⌨️" },
  { id: "calligraphy", name: "Arabic Calligraphy", desc: "6 calligraphy styles", group: "Worship & Daily Practice", icon: "✒️" },
  { id: "quran", name: "Digital Quran", desc: "114 surahs with translations", group: "Worship & Daily Practice", icon: "📖" },
  { id: "murotal", name: "Murotal 30 Juz", desc: "Complete Al-Quran audio player", group: "Worship & Daily Practice", icon: "🎧" },
  { id: "zakat", name: "Zakat Calculator", desc: "Calculate your 2.5% zakat", group: "Finance & Obligations", icon: "💰" },
  { id: "faraid", name: "Inheritance Calculator", desc: "Islamic inheritance shares (Faraid)", group: "Finance & Obligations", icon: "⚖️" },
  { id: "sadaqah", name: "Sadaqah Tracker", desc: "Track your charity", group: "Finance & Obligations", icon: "🎁" },
  { id: "fitrah", name: "Zakat al-Fitr Calculator", desc: "Work out Zakat al-Fitr", group: "Finance & Obligations", icon: "🌾" },
  { id: "hajjsave", name: "Hajj Savings Planner", desc: "Plan and save for Hajj", group: "Finance & Obligations", icon: "🏦" },
  { id: "hajjcost", name: "Hajj Cost Estimator", desc: "Estimate the cost of Hajj", group: "Finance & Obligations", icon: "💵" },
  { id: "hijri", name: "Hijri Date Converter", desc: "Convert Hijri and Gregorian dates", group: "Calendar & Dates", icon: "📅" },
  { id: "ramadan", name: "Ramadan Countdown", desc: "Countdown to Ramadan", group: "Calendar & Dates", icon: "🌙" },
  { id: "eid", name: "Eid Countdown", desc: "Countdown to Eid", group: "Calendar & Dates", icon: "🎉" },
  { id: "events", name: "Islamic Events Calendar", desc: "Key Islamic dates this year", group: "Calendar & Dates", icon: "🗓️" },
  { id: "hijriage", name: "Age in Hijri Calculator", desc: "Your age in the Hijri calendar", group: "Calendar & Dates", icon: "🎂" },
  { id: "umrah", name: "Umrah Step-by-Step Guide", desc: "A guided walkthrough of Umrah", group: "Hajj & Umrah", icon: "🚶" },
  { id: "packing", name: "Hajj & Umrah Packing Checklist", desc: "Everything to pack for the journey", group: "Hajj & Umrah", icon: "🧳" },
  { id: "names", name: "Islamic Name Finder", desc: "Find meaningful Muslim names", group: "Names & Text", icon: "👶" },
  { id: "pegon", name: "Arabic Pegon Converter", desc: "Latin Transliteration ↔ Arabic Pegon", group: "Names & Text", icon: "🔤" },
  { id: "translit", name: "Transliteration Tool", desc: "Arabic to Roman transliteration", group: "Names & Text", icon: "🔡" },
  { id: "halal", name: "Halal Food Additive Checker", desc: "Check E-numbers and additives", group: "Food", icon: "🥗" },
  { id: "mosque", name: "Mosque Finder", desc: "Find mosques near you", group: "Food", icon: "🕌" },
  { id: "corel", name: "CorelDRAW Arabic Assets", desc: "Ready-to-use design templates", group: "Names & Text", icon: "🎨" },
];

export const TOOL_GROUPS = Array.from(new Set(TOOLS.map((t) => t.group)));

export const NEWS = [
  { title: "ALHIKMAH launches new Arabic Pegon converter", date: "12 Jun 2025" },
  { title: "Ramadan preparation series now available", date: "08 Jun 2025" },
  { title: "New digital Quran reader with 114 surahs", date: "01 Jun 2025" },
  { title: "Community reaches 10,000 monthly readers", date: "24 May 2025" },
];

export const ARCHIVE = [
  { label: "June 2025", count: 18 }, { label: "May 2025", count: 24 },
  { label: "April 2025", count: 21 }, { label: "March 2025", count: 16 },
  { label: "February 2025", count: 19 },
];

export const SURAHS = [
  "Al-Fatihah","Al-Baqarah","Ali 'Imran","An-Nisa","Al-Ma'idah","Al-An'am","Al-A'raf","Al-Anfal","At-Tawbah","Yunus",
  "Hud","Yusuf","Ar-Ra'd","Ibrahim","Al-Hijr","An-Nahl","Al-Isra","Al-Kahf","Maryam","Ta-Ha",
  "Al-Anbiya","Al-Hajj","Al-Mu'minun","An-Nur","Al-Furqan","Ash-Shu'ara","An-Naml","Al-Qasas","Al-'Ankabut","Ar-Rum",
  "Luqman","As-Sajdah","Al-Ahzab","Saba","Fatir","Ya-Sin","As-Saffat","Sad","Az-Zumar","Ghafir",
  "Fussilat","Ash-Shura","Az-Zukhruf","Ad-Dukhan","Al-Jathiyah","Al-Ahqaf","Muhammad","Al-Fath","Al-Hujurat","Qaf",
  "Adh-Dhariyat","At-Tur","An-Najm","Al-Qamar","Ar-Rahman","Al-Waqi'ah","Al-Hadid","Al-Mujadila","Al-Hashr","Al-Mumtahanah",
  "As-Saff","Al-Jumu'ah","Al-Munafiqun","At-Taghabun","At-Talaq","At-Tahrim","Al-Mulk","Al-Qalam","Al-Haqqah","Al-Ma'arij",
  "Nuh","Al-Jinn","Al-Muzzammil","Al-Muddaththir","Al-Qiyamah","Al-Insan","Al-Mursalat","An-Naba","An-Nazi'at","'Abasa",
  "At-Takwir","Al-Infitar","Al-Mutaffifin","Al-Inshiqaq","Al-Buruj","At-Tariq","Al-A'la","Al-Ghashiyah","Al-Fajr","Al-Balad",
  "Ash-Shams","Al-Layl","Ad-Duha","Ash-Sharh","At-Tin","Al-'Alaq","Al-Qadr","Al-Bayyinah","Az-Zalzalah","Al-'Adiyat",
  "Al-Qari'ah","At-Takathur","Al-'Asr","Al-Humazah","Al-Fil","Quraysh","Al-Ma'un","Al-Kawthar","Al-Kafirun","An-Nasr",
  "Al-Masad","Al-Ikhlas","Al-Falaq","An-Nas",
];

export const CALLIGRAPHY_STYLES = ["Naskh", "Tsuluts", "Diwani", "Kufi", "Farisi", "Riq'ah"];

export const ASMA_NAMES = [
  { ar: "الرَّحْمَنُ", tr: "Ar-Rahman", en: "The Most Merciful" },
  { ar: "الرَّحِيمُ", tr: "Ar-Rahim", en: "The Most Compassionate" },
  { ar: "الْمَلِكُ", tr: "Al-Malik", en: "The King" },
  { ar: "الْقُدُّوسُ", tr: "Al-Quddus", en: "The Most Holy" },
  { ar: "السَّلَامُ", tr: "As-Salam", en: "The Source of Peace" },
  { ar: "الْمُؤْمِنُ", tr: "Al-Mu'min", en: "The Guarantor of Faith" },
  { ar: "الْعَزِيزُ", tr: "Al-Aziz", en: "The Almighty" },
  { ar: "الْجَبَّارُ", tr: "Al-Jabbar", en: "The Compeller" },
  { ar: "الْمُتَكَبِّرُ", tr: "Al-Mutakabbir", en: "The Supreme" },
  { ar: "الْخَالِقُ", tr: "Al-Khaliq", en: "The Creator" },
  { ar: "الْبَارِئُ", tr: "Al-Bari", en: "The Originator" },
  { ar: "الْمُصَوِّرُ", tr: "Al-Musawwir", en: "The Fashioner" },
  { ar: "الْغَفَّارُ", tr: "Al-Ghaffar", en: "The Ever-Forgiving" },
  { ar: "الْقَهَّارُ", tr: "Al-Qahhar", en: "The Subduer" },
  { ar: "الْوَهَّابُ", tr: "Al-Wahhab", en: "The Bestower" },
  { ar: "الرَّزَّاقُ", tr: "Ar-Razzaq", en: "The Provider" },
  { ar: "الْفَتَّاحُ", tr: "Al-Fattah", en: "The Opener" },
  { ar: "الْعَلِيمُ", tr: "Al-Alim", en: "The All-Knowing" },
  { ar: "الْقَابِضُ", tr: "Al-Qabid", en: "The Withholder" },
  { ar: "الْبَاسِطُ", tr: "Al-Basit", en: "The Extender" },
];

export const DUAS = [
  { ar: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", tr: "Bismillahir-Rahmanir-Rahim", en: "In the name of Allah, the Most Gracious, the Most Merciful" },
  { ar: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", tr: "Alhamdulillahi Rabbil-'Alamin", en: "All praise is due to Allah, Lord of the worlds" },
  { ar: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً", tr: "Rabbana atina fid-dunya hasanah wa fil-akhirati hasanah", en: "Our Lord, give us good in this world and good in the Hereafter" },
  { ar: "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ", tr: "Allahumma salli 'ala Muhammad", en: "O Allah, send blessings upon Muhammad" },
  { ar: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", tr: "Subhanallahi wa bihamdih", en: "Glory be to Allah and praise be to Him" },
  { ar: "لَا إِلَٰهَ إِلَّا اللَّهُ", tr: "La ilaha illallah", en: "There is no god but Allah" },
];

export const ISLAMIC_NAMES = [
  { name: "Ahmad", gender: "male", meaning: "Most commendable, praiseworthy", origin: "Arabic" },
  { name: "Fatimah", gender: "female", meaning: "Prophet's daughter; one who abstains", origin: "Arabic" },
  { name: "Muhammad", gender: "male", meaning: "The praised one", origin: "Arabic" },
  { name: "Aisyah", gender: "female", meaning: "Living, prosperous", origin: "Arabic" },
  { name: "Yusuf", gender: "male", meaning: "Allah increases", origin: "Hebrew" },
  { name: "Maryam", gender: "female", meaning: "Beloved, mother of Isa", origin: "Hebrew" },
  { name: "Ibrahim", gender: "male", meaning: "Father of many", origin: "Hebrew" },
  { name: "Khadijah", gender: "female", meaning: "Premature child; Prophet's wife", origin: "Arabic" },
  { name: "Ali", gender: "male", meaning: "Exalted, noble", origin: "Arabic" },
  { name: "Zainab", gender: "female", meaning: "Fragrant flower", origin: "Arabic" },
  { name: "Umar", gender: "male", meaning: "Flourishing, long-lived", origin: "Arabic" },
  { name: "Hafsah", gender: "female", meaning: "Lioness; wife of the Prophet", origin: "Arabic" },
  { name: "Hasan", gender: "male", meaning: "Handsome, good", origin: "Arabic" },
  { name: "Sumayyah", gender: "female", meaning: "High, elevated", origin: "Arabic" },
  { name: "Bilal", gender: "male", meaning: "Moisture, refreshment", origin: "Arabic" },
  { name: "Ruqayyah", gender: "female", meaning: "Elevation, ascent", origin: "Arabic" },
];

export const HALAL_ADDITIVES = [
  { code: "E100", name: "Curcumin", status: "halal" },
  { code: "E120", name: "Cochineal / Carmine", status: "haram" },
  { code: "E322", name: "Lecithin", status: "halal" },
  { code: "E441", name: "Gelatin", status: "doubtful" },
  { code: "E471", name: "Mono- and Diglycerides", status: "doubtful" },
  { code: "E542", name: "Bone Phosphate", status: "haram" },
  { code: "E631", name: "Sodium Inosinate", status: "doubtful" },
  { code: "E904", name: "Shellac", status: "halal" },
  { code: "E920", name: "L-Cysteine", status: "doubtful" },
];

export const UMRAH_STEPS = [
  { title: "Ihram", desc: "Enter the state of Ihram at the Miqat, wear the prescribed garments, and make the intention (niyyah) for Umrah." },
  { title: "Talbiyah", desc: "Recite the Talbiyah: Labbayk Allahumma Labbayk, repeatedly while travelling to Makkah." },
  { title: "Tawaf", desc: "Perform seven circuits around the Kaaba, starting from the Black Stone, keeping it on your left." },
  { title: "Sa'i", desc: "Walk seven times between Safa and Marwah, remembering Hajar's search for water." },
  { title: "Halq or Taqsir", desc: "Men shave or trim their hair; women trim a fingertip's length. This completes the Umrah." },
];

export const PACKING_ITEMS = [
  "Ihram garments (2 sets)", "Unscented soap & toiletries", "Comfortable walking sandals",
  "Prayer mat", "Pocket Quran / Dua book", "Medications & first-aid",
  "Power bank & adapters", "Lightweight clothing", "Umbrella / sun protection",
  "Small backpack for rituals", "Reusable water bottle", "Copies of travel documents",
];

export const ISLAMIC_EVENTS = [
  { name: "Islamic New Year (1 Muharram)", date: "26 Jun 2025" },
  { name: "Day of Ashura (10 Muharram)", date: "05 Jul 2025" },
  { name: "Mawlid an-Nabi (12 Rabi' al-Awwal)", date: "04 Sep 2025" },
  { name: "Isra & Mi'raj (27 Rajab)", date: "26 Jan 2026" },
  { name: "Start of Ramadan", date: "18 Feb 2026" },
  { name: "Laylat al-Qadr (27 Ramadan)", date: "16 Mar 2026" },
  { name: "Eid al-Fitr", date: "20 Mar 2026" },
  { name: "Day of Arafah (9 Dhul-Hijjah)", date: "26 May 2026" },
  { name: "Eid al-Adha", date: "27 May 2026" },
];