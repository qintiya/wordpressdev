import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Moon,
  Sun,
  Search,
  Menu,
  X,
  ChevronDown,
  Languages,
  BookOpen,
  Wrench,
  Home,
  Info,
} from "lucide-react";
import { LANGS, makeT, isRTL, type Lang } from "@/lib/i18n";
import {
  HomeSection,
  ArticlesSection,
  ArticleReader,
  ToolsSection,
  SponsorCard,
  AdSlot,
} from "@/components/Sections";
import { ARTICLES, CATEGORIES, type Article } from "@/data/content";

type Section = "home" | "articles" | "tools" | "about";

export default function App() {
  const [lang, setLang] = useState<Lang>("en");
  const [dark, setDark] = useState(false);
  const [section, setSection] = useState<Section>("home");
  const [article, setArticle] = useState<Article | null>(null);
  const [query, setQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [navOpen, setNavOpen] = useState(false);

  const t = useMemo(() => makeT(lang), [lang]);
  const rtl = isRTL(lang);

  useEffect(() => {
    const root = document.documentElement;
    if (dark) root.classList.add("dark");
    else root.classList.remove("dark");
  }, [dark]);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = rtl ? "rtl" : "ltr";
  }, [lang, rtl]);

  const go = (s: string) => {
    setSection(s as Section);
    setArticle(null);
    setMenuOpen(false);
    setNavOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const openArticle = (a: Article) => {
    setArticle(a);
    setSection("articles");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const navItems: { id: Section; label: string; icon: typeof Home }[] = [
    { id: "home", label: t("home"), icon: Home },
    { id: "articles", label: t("articles"), icon: BookOpen },
    { id: "tools", label: t("tools"), icon: Wrench },
    { id: "about", label: t("about"), icon: Info },
  ];

  return (
    <div className="min-h-screen bg-emerald-50/40 text-foreground dark:bg-emerald-950/20">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-emerald-200/70 bg-white/90 backdrop-blur dark:border-emerald-900/60 dark:bg-emerald-950/80">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:px-6">
          <button onClick={() => go("home")} className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-emerald-700 to-emerald-900 font-serif text-lg font-bold text-amber-300 shadow-sm">
              ح
            </span>
            <span className="font-serif text-xl font-bold tracking-tight">{t("brand")}</span>
          </button>

          <nav className="ml-4 hidden items-center gap-1 lg:flex">
            {navItems.map((n) => (
              <button
                key={n.id}
                onClick={() => go(n.id)}
                className={`rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  section === n.id && !article
                    ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300"
                    : "text-muted-foreground hover:bg-emerald-50 hover:text-emerald-800 dark:hover:bg-emerald-900/40"
                }`}
              >
                {n.label}
              </button>
            ))}
            <div className="relative">
              <button
                onClick={() => setNavOpen((v) => !v)}
                className="flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-emerald-50 hover:text-emerald-800 dark:hover:bg-emerald-900/40"
              >
                {t("categories")} <ChevronDown className="h-3.5 w-3.5" />
              </button>
              {navOpen && (
                <div className="absolute left-0 top-full mt-1 max-h-80 w-64 overflow-auto rounded-xl border border-emerald-200/70 bg-white p-2 shadow-lg dark:border-emerald-900/60 dark:bg-emerald-950">
                  {CATEGORIES.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => go("articles")}
                      className="block w-full rounded-lg px-3 py-2 text-left text-sm text-muted-foreground transition-colors hover:bg-emerald-50 hover:text-emerald-800 dark:hover:bg-emerald-900/40"
                    >
                      {c.name} <span className="text-xs">({c.count})</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <div className="relative hidden md:block">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  if (e.target.value) go("articles");
                }}
                placeholder={t("search")}
                className="w-56 pl-9"
              />
            </div>

            <Select value={lang} onValueChange={(v) => setLang(v as Lang)}>
              <SelectTrigger className="w-32 gap-1">
                <Languages className="h-4 w-4" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LANGS.map((l) => (
                  <SelectItem key={l.code} value={l.code}>
                    {l.flag} {l.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="icon"
              onClick={() => setDark((v) => !v)}
              aria-label="Toggle theme"
            >
              {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>

            <Button
              variant="outline"
              size="icon"
              className="lg:hidden"
              onClick={() => setMenuOpen((v) => !v)}
              aria-label="Menu"
            >
              {menuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {menuOpen && (
          <div className="border-t border-emerald-200/70 px-4 py-3 lg:hidden dark:border-emerald-900/60">
            <div className="mb-3 md:hidden">
              <Input
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  if (e.target.value) go("articles");
                }}
                placeholder={t("search")}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              {navItems.map((n) => (
                <Button
                  key={n.id}
                  variant={section === n.id && !article ? "default" : "outline"}
                  size="sm"
                  onClick={() => go(n.id)}
                  className={section === n.id && !article ? "bg-emerald-700 hover:bg-emerald-800" : ""}
                >
                  <n.icon className="mr-1.5 h-4 w-4" /> {n.label}
                </Button>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Top ad */}
      <div className="mx-auto max-w-7xl px-4 pt-4 sm:px-6">
        <AdSlot />
      </div>

      {/* Main */}
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {section === "home" && <HomeSection t={t} onOpen={openArticle} go={go} />}
        {section === "articles" &&
          (article ? (
            <ArticleReader
              t={t}
              article={article}
              onBack={() => setArticle(null)}
              onOpen={openArticle}
            />
          ) : (
            <ArticlesSection t={t} onOpen={openArticle} query={query} />
          ))}
        {section === "tools" && <ToolsSection t={t} />}
        {section === "about" && <AboutSection t={t} />}
      </main>

      {/* Footer */}
      <footer className="mt-12 border-t border-emerald-200/70 bg-emerald-950 text-emerald-100 dark:border-emerald-900/60">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
          <div className="grid gap-8 md:grid-cols-4">
            <div>
              <div className="flex items-center gap-2.5">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-800 font-serif text-lg font-bold text-amber-300">
                  ح
                </span>
                <span className="font-serif text-xl font-bold text-amber-50">{t("brand")}</span>
              </div>
              <p className="mt-3 text-sm text-emerald-200/70">{t("tagline")}</p>
            </div>
            <div>
              <p className="mb-3 font-semibold text-amber-200">{t("quickLinks")}</p>
              <ul className="space-y-1.5 text-sm text-emerald-200/70">
                {["Prayer Times", "99 Names of Allah", "Mosque Finder", "Qibla", "Quran", "Inheritance", "Zakat", "Ramadan"].map((x) => (
                  <li key={x}>
                    <button onClick={() => go("tools")} className="transition-colors hover:text-amber-200">
                      {x}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="mb-3 font-semibold text-amber-200">{t("legal")}</p>
              <ul className="space-y-1.5 text-sm text-emerald-200/70">
                {[t("privacy"), t("terms"), t("about"), t("contact"), t("cookies"), t("feedback")].map((x) => (
                  <li key={x}>
                    <span className="cursor-pointer transition-colors hover:text-amber-200">{x}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="mb-3 font-semibold text-amber-200">{t("programs")}</p>
              <ul className="space-y-1.5 text-sm text-emerald-200/70">
                {[t("donation"), t("mealSponsor"), t("sadaqah"), t("sponsorStudent"), t("bankDetails")].map((x) => (
                  <li key={x}>
                    <span className="cursor-pointer transition-colors hover:text-amber-200">{x}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div className="mt-8 border-t border-emerald-800/60 pt-6 text-center text-sm text-emerald-200/60">
            {t("footerRights")} · alhikmah.eu.org
          </div>
        </div>
      </footer>
    </div>
  );
}

function AboutSection({ t }: { t: (k: string) => string }) {
  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-emerald-200/70 bg-gradient-to-r from-emerald-50 to-amber-50 p-6 dark:border-emerald-900/60 dark:from-emerald-950/50 dark:to-amber-950/20">
        <h1 className="font-serif text-3xl font-bold">{t("about")}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{t("tagline")}</p>
      </div>
      <AdSlot />
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <p className="leading-relaxed text-foreground/90">
            ALHIKMAH is a trusted Islamic digital platform that provides high-quality content on
            Islamic education, history, social issues, and culture. Built with a modern architecture,
            it supports web apps, Android, and iOS within a single, integrated ecosystem.
          </p>
          <p className="leading-relaxed text-foreground/90">
            Our vision is to be a trusted Islamic portal that provides authentic content based on the
            Quran and Sunnah, easily accessible to all Muslims in Indonesia and the world.
          </p>
          <p className="leading-relaxed text-foreground/90">
            Our mission is to provide in-depth Islamic articles with SEO standards, present practical
            and useful Islamic digital tools, disseminate Islamic content through modern digital media,
            and maintain the authenticity of content based on trusted sources.
          </p>
        </div>
        <SponsorCard t={t} />
      </div>
    </div>
  );
}