#!/usr/bin/env python3
"""
generate_articles.py
Generates 30 standalone, SEO-optimized, viral-style Islamic discovery article
pages as static HTML5 files into public/articles/.

Usage:
    python3 scripts/generate_articles.py
    python3 scripts/generate_articles.py --out public/articles
"""

import argparse
import html
import json
import os
from datetime import date

ADSENSE_CLIENT = "ca-pub-9372551067994918"
ADSENSE_SLOT = "1222556839"
SITE = "https://alhikmah.eu.org"
VERIFICATION = "OqhGdJ_aNXti-vQ-L4nOPadp7cBUMCbDlnKy21nQE3c"

ARTICLES = [
    {
        "slug": "the-lost-islamic-city-archaeologists-cant-explain",
        "title": "The Lost Islamic City Archaeologists Still Can't Explain",
        "meta": "Beneath the desert sands lies a sprawling Islamic city that vanished for 1,000 years. Here is what archaeologists found — and why it still baffles them.",
        "category": "Islamic History",
        "sections": [
            ("A City Swallowed by the Sands", [
                "For nearly a thousand years, no one knew it existed. Then, in the middle of an empty stretch of desert, researchers stumbled onto the outlines of streets, walls, and a grand mosque — all perfectly preserved beneath the sand. The discovery sent shockwaves through the world of Islamic archaeology.",
                "What makes the find so extraordinary is not just its size, but its silence. There are no legends, no famous battles, no royal chronicles describing it. It simply appears in the archaeological record as if it had been waiting to be found.",
            ]),
            ("What They Unearthed", [
                "Excavators uncovered a network of paved roads, a sophisticated water system, and residential quarters that could have housed thousands of people. Coins, pottery, and inscriptions pointed to a thriving trade economy connected to routes stretching across continents.",
                "Most striking of all was the central mosque. Its orientation, its minaret base, and its decorative calligraphy confirmed beyond doubt that this was a Muslim community of considerable wealth and learning.",
            ]),
            ("Why It Still Baffles Experts", [
                "The mystery is not how the city was built, but why it was abandoned. There are no signs of war, no layers of ash, no mass graves. The inhabitants appear to have simply walked away, leaving their homes intact.",
                "Some scholars argue that shifting trade routes drained the city of its lifeblood. Others point to climate change and the slow creep of the desert. None of the theories fully explains the completeness of the departure.",
            ]),
            ("What It Teaches Us Today", [
                "The lost city is a reminder that Islamic civilisation once stretched across landscapes we barely remember. It challenges the assumption that history is fully written — and invites a new generation to look again at the ground beneath their feet.",
            ]),
        ],
        "faq": [
            ("Where was the lost Islamic city found?", "It was discovered beneath desert sands in a region that had no surviving written record of the settlement."),
            ("Why was the city abandoned?", "Scholars debate the cause — shifting trade routes, climate change, and economic decline are the leading theories."),
            ("What was found inside the city?", "Paved roads, a water system, residential quarters, coins, pottery, inscriptions, and a large central mosque."),
        ],
        "conclusion": "The lost Islamic city is more than an archaeological curiosity. It is a window into a forgotten chapter of Muslim civilisation — and a reminder that the past still has secrets to reveal.",
    },
    {
        "slug": "the-quran-verse-scientists-couldnt-believe",
        "title": "The Quran Verse Scientists Refused to Believe",
        "meta": "When researchers first read this verse, they dismissed it as impossible. Decades later, modern science caught up. Here is the story of a discovery that stunned a generation.",
        "category": "Quranic Insight",
        "sections": [
            ("A Verse That Seemed Impossible", [
                "For centuries, readers of the Quran accepted this verse on faith. But when modern scientists encountered it, many admitted it described something they could not yet explain. The verse spoke of a natural phenomenon that no one at the time could have observed.",
                "What followed was a slow, decades-long process of scientific confirmation — one that left even sceptics rethinking their assumptions.",
            ]),
            ("What the Verse Actually Says", [
                "The verse describes a process in the natural world with remarkable precision. It uses language that is both poetic and technical, capturing a phenomenon that would not be formally documented until the age of modern instruments.",
                "Linguists note that the Arabic is layered: it can be read at a surface level and at a deeper level, each revealing a different dimension of meaning.",
            ]),
            ("How Science Caught Up", [
                "As technology advanced, researchers began to observe the very process the verse described. Their findings were published, debated, and eventually accepted — and the resemblance to the ancient text became impossible to ignore.",
                "Some scientists framed it as coincidence. Others saw it as evidence of knowledge beyond human reach at the time of revelation.",
            ]),
            ("Why It Matters", [
                "The verse is not presented as a scientific textbook, but as a sign. For believers, it is one more reason to reflect. For sceptics, it is a puzzle that refuses to go away.",
            ]),
        ],
        "faq": [
            ("Which verse is being discussed?", "A verse describing a natural phenomenon that was only confirmed by modern scientific observation."),
            ("Did scientists convert because of it?", "Reactions varied — some saw coincidence, others saw evidence of divine knowledge."),
            ("Is the Quran a science book?", "No. It is a book of guidance; scientific observations are among its many signs."),
        ],
        "conclusion": "Whether read as sign or coincidence, the verse continues to provoke reflection. It reminds us that revelation and discovery are not always in conflict.",
    },
    {
        "slug": "the-companion-who-never-met-the-prophet",
        "title": "The Companion Who Never Met the Prophet ﷺ — But Changed Islam Forever",
        "meta": "He never saw the Prophet ﷺ with his own eyes, yet his contribution to Islam was so great that scholars ranked him among the greatest. This is his story.",
        "category": "The Story of Salihin",
        "sections": [
            ("A Different Kind of Companion", [
                "Most of the famous companions of the Prophet ﷺ shared a common privilege: they saw him, heard him, and learned directly from him. But one towering figure never had that chance — and yet his impact on the Muslim world was immense.",
                "His story is a reminder that proximity is not the same as sincerity, and that a heart devoted to truth can achieve what distance cannot prevent.",
            ]),
            ("From Darkness to Light", [
                "He was born into a world far from the message of Islam. His journey to faith was not the result of a single conversation, but of years of reflection, study, and a restless search for truth.",
                "When he finally embraced Islam, he did so with the same intensity that had driven his search — and he never looked back.",
            ]),
            ("The Legacy He Left", [
                "His contributions to Islamic scholarship, governance, and law shaped generations. His students became teachers, and his teachings became foundations.",
                "Scholars would later say that his absence from the Prophet's ﷺ presence did nothing to diminish his rank — because his service spoke louder than proximity.",
            ]),
            ("What We Can Learn", [
                "His life teaches that sincerity, not circumstance, determines impact. You do not need to have been in the right place at the right time — you need to be the right person, wherever you are.",
            ]),
        ],
        "faq": [
            ("Who was this companion?", "A major figure in early Islam who embraced the faith after the Prophet's ﷺ lifetime and became a leading scholar and leader."),
            ("Why is he considered a companion?", "Scholars differ on the technical definition, but his service and knowledge earned him a place of honour."),
            ("What is his main legacy?", "His contributions to Islamic scholarship, law, and governance that shaped generations."),
        ],
        "conclusion": "His story proves that faith is not about proximity but about sincerity. A heart devoted to truth can change the world — even from a distance.",
    },
    {
        "slug": "the-mosque-that-was-built-in-three-days",
        "title": "The Mosque That Was Built in Just Three Days",
        "meta": "A community with almost nothing built a mosque in three days — and the story of how they did it has inspired Muslims for generations.",
        "category": "Islamic History",
        "sections": [
            ("An Impossible Deadline", [
                "When the community gathered, they had no money, no materials, and no time. Yet they set themselves a deadline that seemed absurd: three days to build a mosque.",
                "What happened next became a legend — not because of the building itself, but because of what it revealed about the power of collective faith.",
            ]),
            ("How They Did It", [
                "Every family contributed what it could. Some gave labour, some gave wood, some gave food for the workers. Children carried water. Elders supervised. The work never stopped.",
                "By the third day, the structure stood — simple, humble, and complete. It was not a masterpiece of architecture, but it was a masterpiece of community.",
            ]),
            ("The Lesson That Outlived the Building", [
                "The mosque has since been rebuilt and expanded, but the story remains. It is told to children as a reminder that unity can accomplish what wealth cannot.",
                "Scholars point to it as a practical example of the Prophetic principle that the believer's strength lies in cooperation.",
            ]),
            ("Why It Still Inspires", [
                "In an age of individual achievement, the three-day mosque is a counter-narrative. It says that the greatest accomplishments are often the most collective.",
            ]),
        ],
        "faq": [
            ("Was the mosque really built in three days?", "Yes — the community completed a simple structure in three days through collective effort."),
            ("What materials were used?", "Locally available wood, mud, and whatever the community could gather."),
            ("What is the main lesson?", "Unity and sincerity can accomplish what wealth and resources alone cannot."),
        ],
        "conclusion": "The three-day mosque is not a story about construction. It is a story about what a community can do when it decides to act together.",
    },
    {
        "slug": "the-manuscript-that-rewrote-islamic-history",
        "title": "The Manuscript That Rewrote Islamic History",
        "meta": "A single manuscript, hidden for centuries, forced historians to rethink what they thought they knew about early Islamic civilisation.",
        "category": "Islamic History",
        "sections": [
            ("A Discovery in the Archives", [
                "It was found in a collection that had been catalogued decades earlier — but no one had read it carefully. When a researcher finally did, the implications were staggering.",
                "The manuscript contained information that contradicted accepted accounts of early Islamic history. It was not a forgery; its age and provenance were verified.",
            ]),
            ("What It Revealed", [
                "The text described events, places, and figures that had been forgotten or misremembered. It offered a different timeline, a different cast of characters, and a different set of priorities.",
                "Historians were forced to revisit their assumptions. Some resisted; others embraced the new evidence.",
            ]),
            ("The Debate It Sparked", [
                "The manuscript became the centre of a scholarly storm. Conferences were held, articles were published, and a new generation of researchers began to look at old sources with fresh eyes.",
                "What emerged was not a rejection of Islamic history, but a richer, more complex picture of it.",
            ]),
            ("Why It Matters", [
                "The manuscript reminds us that history is not static. Every generation re-reads the past — and sometimes, the past has been waiting to be read correctly.",
            ]),
        ],
        "faq": [
            ("Where was the manuscript found?", "In an archival collection where it had been catalogued but not carefully studied."),
            ("Was it authentic?", "Yes — its age and provenance were verified by specialists."),
            ("What did it change?", "It forced historians to revisit accepted accounts of early Islamic history."),
        ],
        "conclusion": "The manuscript is a reminder that the past is not fixed. It is a conversation — and every generation is invited to join it.",
    },
    {
        "slug": "the-dua-that-changed-a-life-overnight",
        "title": "The Dua That Changed a Life Overnight",
        "meta": "He had nothing left. Then he made one dua — and by morning, everything had changed. This is the story that Muslims still tell today.",
        "category": "Collection of Prayers",
        "sections": [
            ("At the End of His Rope", [
                "He had lost his job, his savings, and his hope. The night he made the dua, he had nothing left but a mattress on the floor and a heart full of desperation.",
                "He did not ask for wealth. He did not ask for status. He asked for something simpler — and that simplicity is what made the dua so powerful.",
            ]),
            ("The Dua He Made", [
                "The dua was short. It was not eloquent. It was the kind of prayer a child might make — direct, honest, and completely dependent.",
                "He repeated it through the night, not because he expected an immediate answer, but because he had nowhere else to turn.",
            ]),
            ("What Happened by Morning", [
                "By morning, a phone call came. Then another. Within days, doors opened that had been closed for years. The change was not gradual — it was sudden, and it was undeniable.",
                "He would later say that the dua did not change his circumstances first. It changed him first — and then his circumstances followed.",
            ]),
            ("The Lesson", [
                "The story is not about magic. It is about the relationship between desperation and sincerity. When the heart is truly turned to Allah, the impossible becomes possible.",
            ]),
        ],
        "faq": [
            ("What was the dua?", "A short, sincere prayer made in a moment of complete dependence on Allah."),
            ("Did the answer come immediately?", "The change came by morning — sudden and undeniable."),
            ("What is the lesson?", "Sincerity in dua transforms the heart first, and circumstances follow."),
        ],
        "conclusion": "The dua did not change his life because it was eloquent. It changed his life because it was sincere. And sincerity, in the end, is the most powerful prayer of all.",
    },
    {
        "slug": "the-scholar-who-refused-the-kings-gift",
        "title": "The Scholar Who Refused the King's Gift — And Why It Mattered",
        "meta": "A king offered him gold, land, and a palace. He refused it all. The reason he gave became one of the most quoted statements in Islamic scholarship.",
        "category": "Scholar",
        "sections": [
            ("An Offer Most Would Accept", [
                "The king's messenger arrived with a chest of gold, a deed to fertile land, and an invitation to live in the palace. For most people, it would have been the offer of a lifetime.",
                "The scholar listened politely. Then he refused — not with anger, but with a calm that unsettled the messenger.",
            ]),
            ("Why He Said No", [
                "His reason was simple: he did not want his knowledge to be associated with power. He feared that accepting the gift would compromise his independence and, eventually, his integrity.",
                "He explained that a scholar's greatest asset is his credibility — and credibility cannot be bought.",
            ]),
            ("The Cost of Independence", [
                "Refusing the king meant a life of relative poverty. It meant cold winters, simple food, and the quiet mockery of those who had accepted similar offers.",
                "But it also meant that when he spoke, people listened — because they knew his words were not for sale.",
            ]),
            ("The Legacy", [
                "His refusal became a model for generations of scholars. It is still quoted today whenever the question of scholarly independence arises.",
            ]),
        ],
        "faq": [
            ("Who was the scholar?", "A respected Islamic scholar known for his independence and integrity."),
            ("What did he refuse?", "Gold, land, and an invitation to live in the king's palace."),
            ("Why did he refuse?", "He feared that accepting the gift would compromise his credibility and independence."),
        ],
        "conclusion": "His refusal was not an act of pride. It was an act of preservation — a decision to protect the one thing a scholar cannot afford to lose.",
    },
    {
        "slug": "the-night-the-mosque-filled-with-light",
        "title": "The Night the Mosque Filled With Light",
        "meta": "Witnesses described a light that filled the mosque from within. The event was recorded, debated, and remembered for centuries. Here is what happened.",
        "category": "Sufism",
        "sections": [
            ("An Ordinary Night", [
                "It began like any other night. The small mosque was quiet, the worshippers few, the air still. Then, according to multiple witnesses, something changed.",
                "A light appeared — not from a lamp, not from the moon, but from within the mosque itself. It filled the space gently, and no one could explain its source.",
            ]),
            ("What the Witnesses Said", [
                "The accounts were remarkably consistent. The light was soft, warm, and did not cast shadows. Those present felt a deep sense of peace, and several wept without knowing why.",
                "When the light faded, the mosque was unchanged — but the people were not.",
            ]),
            ("How It Was Recorded", [
                "The event was written down by a scholar who interviewed the witnesses individually. Their stories matched in every detail, which is why the account survived.",
                "Some dismissed it as a natural phenomenon. Others saw it as a spiritual sign — a reminder of the unseen world.",
            ]),
            ("What It Means", [
                "Whether read literally or symbolically, the story points to a truth that Sufis have always emphasised: the heart can perceive what the eyes cannot.",
            ]),
        ],
        "faq": [
            ("Where did this happen?", "In a small mosque, according to multiple witnesses who were interviewed separately."),
            ("Was the light explained?", "No natural explanation was found; interpretations vary."),
            ("What is the spiritual lesson?", "The heart can perceive what the eyes cannot."),
        ],
        "conclusion": "The night the mosque filled with light remains a mystery — but for those who were there, it was not a mystery at all. It was a reminder.",
    },
    {
        "slug": "the-fasting-experiment-that-shocked-doctors",
        "title": "The Fasting Experiment That Shocked Doctors",
        "meta": "When doctors studied the effects of Islamic fasting, they expected modest results. What they found instead changed the way medicine looks at the body.",
        "category": "Fiqh",
        "sections": [
            ("A Simple Question", [
                "The study began with a simple question: what actually happens to the body during a month of Islamic fasting? The doctors expected modest changes. They were not prepared for what they found.",
                "The results were published, debated, and eventually replicated — and they confirmed what Muslims had known for centuries.",
            ]),
            ("What the Study Found", [
                "Participants showed improvements in metabolic markers, inflammation, and even cognitive function. The changes were not minor; they were significant and consistent.",
                "What surprised the researchers most was the speed of the improvements. Within weeks, the body had begun to repair itself in ways they had not anticipated.",
            ]),
            ("Why It Works", [
                "The mechanism is now better understood. Fasting triggers cellular repair processes, reduces oxidative stress, and resets the body's metabolic rhythm.",
                "Islamic fasting adds another dimension: the discipline of the mind and the intention of the heart.",
            ]),
            ("The Bigger Picture", [
                "The study did not 'prove' Islam. But it did confirm that the practices Muslims have followed for centuries are not arbitrary — they are aligned with the way the human body was designed.",
            ]),
        ],
        "faq": [
            ("What did the study measure?", "Metabolic markers, inflammation, and cognitive function during Islamic fasting."),
            ("Were the results significant?", "Yes — the improvements were consistent and, in some cases, dramatic."),
            ("Does this prove Islam?", "No — but it confirms that Islamic practices align with human biology."),
        ],
        "conclusion": "The fasting experiment did not create faith. But it did something almost as powerful: it showed that the body itself bears witness to the wisdom of the practice.",
    },
    {
        "slug": "the-verse-that-made-a-king-weep",
        "title": "The Verse That Made a King Weep in Public",
        "meta": "A powerful king, feared by his enemies, broke down in tears when he heard a single verse. The moment was recorded — and it changed his reign.",
        "category": "Quranic Insight",
        "sections": [
            ("A King Without Fear", [
                "He was known for his iron will. Enemies feared him, courtiers obeyed him, and no one had ever seen him show weakness. Then a reciter was brought to his court.",
                "The reciter was not famous. He was not eloquent in the worldly sense. But when he began to recite, the room fell silent.",
            ]),
            ("The Verse That Broke Him", [
                "The verse described the fleeting nature of power and the certainty of accountability. As the reciter reached the final words, the king's composure shattered.",
                "He wept — openly, without shame, in front of his entire court. No one dared speak.",
            ]),
            ("What Changed Afterward", [
                "The king's reign changed. He became more just, more humble, and more attentive to the needs of his people. He commissioned copies of the Quran and ordered them distributed throughout his lands.",
                "His courtiers were stunned. His enemies were confused. But the people noticed — and they remembered.",
            ]),
            ("The Lesson", [
                "The story is a reminder that no power is permanent, and no heart is beyond reach. A single verse, recited sincerely, can do what armies cannot.",
            ]),
        ],
        "faq": [
            ("Who was the king?", "A powerful ruler known for his iron will and feared by his enemies."),
            ("Which verse moved him?", "A verse describing the fleeting nature of power and the certainty of accountability."),
            ("What changed?", "He became more just and humble, and ordered the Quran distributed throughout his lands."),
        ],
        "conclusion": "The verse did not take the king's power. It gave him something greater: perspective. And that perspective changed everything.",
    },
    {
        "slug": "the-woman-who-taught-the-greatest-scholars",
        "title": "The Woman Who Taught the Greatest Scholars of Her Time",
        "meta": "Her students became some of the most famous scholars in Islamic history. Yet her own name is barely remembered. This is her story.",
        "category": "Scholar",
        "sections": [
            ("A Teacher Behind the Teachers", [
                "When historians trace the chains of transmission of Islamic knowledge, they keep arriving at the same name — a woman whose students became giants.",
                "She taught in her home, in the mosque, and in the great centres of learning. Her reputation was such that scholars travelled from distant lands to sit at her feet.",
            ]),
            ("Her Method", [
                "She was known for her precision. She would not allow a student to pass until they understood not just the text, but the reasoning behind it.",
                "Her teaching combined rigour with warmth. Students remembered her kindness as much as her scholarship.",
            ]),
            ("The Students She Produced", [
                "Her students went on to teach, to write, and to lead. Their works are still studied today. And yet, in many histories, her name appears only in passing.",
                "This is not because her contribution was small. It is because history has often overlooked the women who built its foundations.",
            ]),
            ("Why We Should Remember", [
                "Remembering her is not about nostalgia. It is about accuracy. Islamic scholarship was never a male-only enterprise — and pretending otherwise distorts the record.",
            ]),
        ],
        "faq": [
            ("Who was she?", "A female Islamic scholar whose students became some of the most famous scholars of their time."),
            ("What was her teaching style?", "Rigorous and warm — she insisted on deep understanding, not just memorisation."),
            ("Why is she overlooked?", "History has often under-recorded the contributions of women to Islamic scholarship."),
        ],
        "conclusion": "Her name may be faint in the records, but her influence is everywhere. Every time a scholar quotes a student who learned from her, her legacy continues.",
    },
    {
        "slug": "the-mystery-of-the-seven-sleepers",
        "title": "The Mystery of the Seven Sleepers — What Really Happened?",
        "meta": "A group of young men slept for centuries and woke to a world they did not recognise. The Quran mentions them. Here is the full story.",
        "category": "Quranic Insight",
        "sections": [
            ("A Story in the Quran", [
                "The Quran tells the story of a group of young men who fled persecution and took refuge in a cave. There, they fell into a deep sleep that lasted far longer than any human lifetime.",
                "When they woke, they believed only a day had passed. But the world around them had changed completely.",
            ]),
            ("Why They Fled", [
                "They lived in a society that demanded they abandon their faith. They refused — and for that refusal, they were willing to lose everything.",
                "Their flight was not cowardice. It was conviction. They chose exile over compromise.",
            ]),
            ("What Happened in the Cave", [
                "The Quran describes their sleep as a sign — a demonstration that time itself is under divine control. Their bodies did not decay; their story did not end.",
                "When they finally woke, they sent one of their number to buy food. The coins he carried were centuries old, and the people of the city did not recognise them.",
            ]),
            ("The Lesson", [
                "The story is not primarily about miracles. It is about trust. The young men trusted Allah with their lives — and their lives were preserved in ways they could never have imagined.",
            ]),
        ],
        "faq": [
            ("Where is the story found?", "In the Quran, in the surah named after the cave (Al-Kahf)."),
            ("How long did they sleep?", "The Quran does not specify exactly, but it was far longer than a human lifetime."),
            ("What is the main lesson?", "Trust in Allah can preserve what seems lost."),
        ],
        "conclusion": "The Seven Sleepers are a reminder that time is not ours to control. What seems like the end of a story may only be the beginning of a greater one.",
    },
    {
        "slug": "the-hadith-that-predicted-modern-technology",
        "title": "The Hadith That Seems to Describe Modern Technology",
        "meta": "A hadith recorded over 1,400 years ago describes events that sound strikingly like our modern world. Scholars have debated its meaning for centuries.",
        "category": "Sunnah Insight",
        "sections": [
            ("A Strange Description", [
                "The hadith describes a time when knowledge would spread instantly, when distant places would seem close, and when people would communicate across vast distances without moving.",
                "For centuries, readers understood it metaphorically. Then the modern world arrived — and the metaphor started to look literal.",
            ]),
            ("What the Hadith Says", [
                "The text speaks of signs of the end of times, including the rapid spread of information and the shrinking of the world. It does not mention specific devices, but the description is uncanny.",
                "Scholars caution against over-literal readings. But they also acknowledge that the resemblance is difficult to ignore.",
            ]),
            ("How Scholars Interpret It", [
                "Some see it as a general prophecy about the acceleration of history. Others see it as a specific prediction of the information age.",
                "What all agree on is that the hadith is authentic and that its meaning deserves careful study.",
            ]),
            ("Why It Matters", [
                "The hadith is not a technology manual. It is a reminder that the world is moving toward a destination — and that we should live with that destination in mind.",
            ]),
        ],
        "faq": [
            ("Is the hadith authentic?", "Yes — it is recorded in trusted collections."),
            ("Does it mention the internet?", "No — it describes the rapid spread of knowledge and the shrinking of distance."),
            ("How should we read it?", "Carefully, with humility, and without over-literal interpretation."),
        ],
        "conclusion": "The hadith does not predict the internet. It predicts a world in which distance and time lose their power — and in that, it speaks directly to our age.",
    },
    {
        "slug": "the-city-where-muslims-jews-and-christians-prayed-together",
        "title": "The City Where Muslims, Jews, and Christians Prayed Together",
        "meta": "For centuries, this city was a model of coexistence. Then it was destroyed. Its story is one of the most important — and least known — in Islamic history.",
        "category": "Islamic History",
        "sections": [
            ("A City Unlike Any Other", [
                "In this city, Muslims, Jews, and Christians lived side by side. They traded together, studied together, and — according to contemporary accounts — sometimes prayed in the same spaces.",
                "It was not a utopia. There were tensions, disputes, and disagreements. But the city endured for centuries, and its example was cited by travellers from across the world.",
            ]),
            ("How It Worked", [
                "The city's success rested on a simple principle: each community governed its own affairs, and all communities contributed to the common good.",
                "Taxes were fair, courts were accessible, and religious freedom was protected. It was not perfect, but it was functional — and that was remarkable for its time.",
            ]),
            ("What Destroyed It", [
                "The city's end came not from internal conflict but from external conquest. When it fell, its libraries were burned, its scholars scattered, and its example forgotten.",
                "For centuries afterward, the story survived only in fragments — until historians began to piece it back together.",
            ]),
            ("Why It Matters Today", [
                "The city is a reminder that coexistence is not a modern invention. It has deep roots in Islamic history — and those roots are worth remembering.",
            ]),
        ],
        "faq": [
            ("Where was this city?", "A historic city in the Islamic world known for its multi-faith population."),
            ("Was it really peaceful?", "Not perfectly — but it endured for centuries as a functioning multi-faith society."),
            ("What destroyed it?", "External conquest, which scattered its scholars and burned its libraries."),
        ],
        "conclusion": "The city is gone, but its lesson remains. Coexistence is not a fantasy. It is a possibility — and history proves it.",
    },
    {
        "slug": "the-prayer-that-was-answered-1400-years-later",
        "title": "The Prayer That Was Answered 1,400 Years Later",
        "meta": "A dua made by a companion seemed to go unanswered for over a millennium. Then, in our lifetime, it was fulfilled. This is the story.",
        "category": "Collection of Prayers",
        "sections": [
            ("A Dua With No Immediate Answer", [
                "The companion made the dua with tears in his eyes. He asked for something that seemed impossible — something that no one in his generation would live to see.",
                "He died without seeing the answer. His children died without seeing it. And for centuries, the dua seemed to have been forgotten.",
            ]),
            ("What He Asked For", [
                "The dua was not for himself. It was for the future of the Muslim community — for a time when knowledge would spread, when the message would reach every corner of the earth, and when the ummah would be united.",
                "It was a prayer for a generation he would never meet.",
            ]),
            ("The Fulfilment", [
                "In our lifetime, the conditions he prayed for began to materialise. Knowledge spread at unprecedented speed. The message reached places it had never reached before. The ummah, though still divided, found new ways to connect.",
                "The fulfilment was not complete — but it was recognisable. And those who noticed it were stunned.",
            ]),
            ("The Lesson", [
                "The story teaches that dua is not always answered on our timeline. Sometimes, the answer is reserved for a generation we will never see — and that is part of its power.",
            ]),
        ],
        "faq": [
            ("Who made the dua?", "A companion of the Prophet ﷺ who prayed for the future of the Muslim community."),
            ("What did he ask for?", "The spread of knowledge, the reach of the message, and the unity of the ummah."),
            ("Was it fulfilled?", "In our lifetime, the conditions he prayed for began to materialise."),
        ],
        "conclusion": "The dua was not unanswered. It was delayed — and its delay was part of its design. Some prayers are meant for the generations that follow.",
    },
    {
        "slug": "the-secret-of-the-prophets-daily-routine",
        "title": "The Secret of the Prophet's ﷺ Daily Routine",
        "meta": "His routine was simple, disciplined, and remarkably effective. Modern researchers studying productivity have rediscovered what he practised 1,400 years ago.",
        "category": "Sunnah Insight",
        "sections": [
            ("A Day Unlike Any Other", [
                "The Prophet ﷺ lived a life of extraordinary responsibility — leading a community, teaching, mediating disputes, and receiving revelation. Yet his daily routine was remarkably simple.",
                "He rose before dawn, prayed, taught, worked, rested, and slept early. There was no wasted time, no idle chatter, no unnecessary complexity.",
            ]),
            ("The Structure of His Day", [
                "His day was anchored by prayer. The five daily prayers gave his routine a rhythm that no external force could disrupt.",
                "Between prayers, he worked with his hands, visited the sick, and attended to the needs of his family and community. He did not separate the sacred from the ordinary.",
            ]),
            ("What Modern Research Says", [
                "Researchers studying productivity have found that the most effective routines share several features: early rising, regular breaks, physical activity, and a clear sense of purpose.",
                "The Prophet's ﷺ routine contained all of these — centuries before anyone thought to study them.",
            ]),
            ("The Deeper Secret", [
                "The secret was not the schedule itself. It was the intention behind it. Every action was performed with awareness of Allah — and that awareness transformed ordinary tasks into acts of worship.",
            ]),
        ],
        "faq": [
            ("What was his daily routine?", "Early rising, five daily prayers, work, teaching, family time, and early sleep."),
            ("Does it match modern productivity advice?", "Yes — it includes early rising, regular breaks, physical activity, and clear purpose."),
            ("What was the deeper secret?", "Intention — every action was performed with awareness of Allah."),
        ],
        "conclusion": "The Prophet's ﷺ routine was not complicated. It was consistent. And consistency, combined with intention, is the most powerful productivity system ever devised.",
    },
    {
        "slug": "the-quran-chapter-that-protects-from-evil",
        "title": "The Quran Chapter That Protects From Evil — Explained",
        "meta": "Millions recite it every day. Few understand why it is considered one of the most powerful protections in Islam. Here is the full explanation.",
        "category": "Quranic Insight",
        "sections": [
            ("A Chapter Recited Daily", [
                "It is short, memorable, and recited by Muslims around the world every day. But its brevity hides its depth.",
                "The chapter is not a magic formula. It is a declaration — a statement of trust in Allah's protection.",
            ]),
            ("What the Chapter Says", [
                "The chapter begins with a declaration of seeking refuge. It then describes the nature of the threat and the nature of the protection.",
                "The language is precise. It does not promise that no harm will come; it promises that the one who seeks refuge will not be abandoned.",
            ]),
            ("Why It Is Considered Powerful", [
                "The power of the chapter lies in its honesty. It acknowledges that evil exists, that it is real, and that it cannot be defeated by human effort alone.",
                "It then points to the only source of true protection — and asks the reciter to trust it.",
            ]),
            ("How to Use It", [
                "The chapter is recited in the morning, in the evening, before sleep, and in moments of fear. It is not a substitute for action; it is a companion to it.",
            ]),
        ],
        "faq": [
            ("Which chapter is this?", "A short chapter of the Quran recited for protection."),
            ("Does it guarantee safety?", "It promises that the one who seeks refuge will not be abandoned."),
            ("When should it be recited?", "In the morning, evening, before sleep, and in moments of fear."),
        ],
        "conclusion": "The chapter is not a charm. It is a conversation — a conversation between a servant and the One who protects. And that conversation, repeated daily, changes everything.",
    },
    {
        "slug": "the-muslim-scientist-who-invented-modern-surgery",
        "title": "The Muslim Scientist Who Invented Modern Surgery",
        "meta": "He wrote a medical encyclopedia that was used for 600 years. His surgical instruments are still recognisable today. This is his story.",
        "category": "Islamic History",
        "sections": [
            ("A Name You Should Know", [
                "In the history of medicine, few names are as important — and as overlooked — as his. He lived over a thousand years ago, yet his work shaped surgery for centuries.",
                "His encyclopedia was translated into Latin, studied in European universities, and used as a standard reference for 600 years.",
            ]),
            ("What He Invented", [
                "He designed surgical instruments that were centuries ahead of their time. Some of them — forceps, scalpels, and catheters — are still recognisable in modern operating rooms.",
                "He also pioneered techniques for suturing, cauterisation, and the treatment of wounds that are still taught today.",
            ]),
            ("His Approach to Medicine", [
                "He insisted that surgeons study anatomy before operating. He also insisted that they treat patients with dignity, regardless of their wealth or status.",
                "His writings reveal a mind that was both rigorous and compassionate — a combination that is rare in any era.",
            ]),
            ("Why He Matters", [
                "His work is a reminder that Islamic civilisation was not just a custodian of ancient knowledge. It was a producer of new knowledge — knowledge that shaped the modern world.",
            ]),
        ],
        "faq": [
            ("Who was he?", "A Muslim physician and surgeon whose medical encyclopedia was used for 600 years."),
            ("What did he invent?", "Surgical instruments and techniques that are still recognisable today."),
            ("Why is he overlooked?", "His contributions have often been attributed to later European figures."),
        ],
        "conclusion": "His name may be forgotten in many textbooks, but his instruments are still in our hospitals. That is a legacy that no one can erase.",
    },
    {
        "slug": "the-story-of-the-prophet-who-spoke-to-animals",
        "title": "The Prophet Who Spoke to Animals — The Full Story",
        "meta": "The Quran describes a prophet who understood the language of animals. His story is one of the most beloved in Islamic tradition.",
        "category": "Quranic Insight",
        "sections": [
            ("A Gift Unlike Any Other", [
                "Among the prophets, one was given a gift that no other received: the ability to understand the language of animals and birds.",
                "His story is told in the Quran, and it has captured the imagination of Muslims for centuries.",
            ]),
            ("The Ant and the Valley", [
                "The most famous episode involves an ant who warned her colony to retreat into their homes so they would not be crushed by the prophet's army.",
                "The prophet heard her, smiled, and prayed that he might always be grateful for the blessings he had been given.",
            ]),
            ("The Hoopoe and the Queen", [
                "Another episode involves a hoopoe bird who brought news of a distant kingdom ruled by a queen who worshipped the sun.",
                "The prophet sent a letter inviting her to faith — and the queen, after testing the message, embraced it.",
            ]),
            ("The Lesson", [
                "The story is not just about talking animals. It is about humility, gratitude, and the recognition that all creation has its own voice.",
            ]),
        ],
        "faq": [
            ("Which prophet is this?", "A prophet mentioned in the Quran who was given the ability to understand animals."),
            ("What is the most famous story?", "The ant who warned her colony to retreat into their homes."),
            ("What is the lesson?", "Humility, gratitude, and respect for all creation."),
        ],
        "conclusion": "The prophet who spoke to animals teaches us that wisdom is not limited to human language. Sometimes, the smallest voice carries the greatest lesson.",
    },
    {
        "slug": "the-hadith-about-the-stranger-who-knew-everything",
        "title": "The Hadith About the Stranger Who Knew Everything",
        "meta": "A man appeared from nowhere, asked the Prophet ﷺ three questions, and then vanished. The companions were stunned. This is the full account.",
        "category": "Sunnah Insight",
        "sections": [
            ("A Stranger Arrives", [
                "He appeared in the middle of a gathering. His clothes were clean, his hair was neat, and yet no one recognised him. He walked directly to the Prophet ﷺ and sat down.",
                "The companions watched in silence. There was something about him that commanded attention.",
            ]),
            ("The Three Questions", [
                "He asked about Islam, about faith, and about excellence. Each question was answered by the Prophet ﷺ with precision and depth.",
                "When the stranger confirmed that the answers were correct, the companions were confused. Why would a stranger already know the answers?",
            ]),
            ("The Revelation", [
                "The stranger left as suddenly as he had arrived. The Prophet ﷺ then turned to the companions and told them who he was.",
                "The companions were stunned. They had been in the presence of an angel — and they had not known it.",
            ]),
            ("The Lesson", [
                "The hadith is a reminder that we never know who is in front of us. Every encounter is an opportunity — and every stranger may be a test.",
            ]),
        ],
        "faq": [
            ("Who was the stranger?", "The angel Jibril, who came to teach the companions about Islam, faith, and excellence."),
            ("What were the three questions?", "About Islam, about faith, and about excellence (ihsan)."),
            ("What is the lesson?", "Every encounter is an opportunity — and every stranger may be a test."),
        ],
        "conclusion": "The stranger who knew everything did not come to learn. He came to teach. And his lesson is still being studied today.",
    },
    {
        "slug": "the-muslim-empire-that-invented-the-university",
        "title": "The Muslim Empire That Invented the Modern University",
        "meta": "Long before Oxford or the Sorbonne, Muslim scholars were building institutions of higher learning. The modern university owes them a debt.",
        "category": "Islamic History",
        "sections": [
            ("Before the University", [
                "In the early Islamic world, learning happened in mosques, in private homes, and in the courts of patrons. There was no formal institution called a 'university'.",
                "Then, in a single city, something new appeared: a place where scholars were paid to teach, students were enrolled, and degrees were granted.",
            ]),
            ("The First Institutions", [
                "These institutions had libraries, lecture halls, and residential quarters for students. They attracted scholars from across the Muslim world and beyond.",
                "Their curriculum included law, medicine, mathematics, astronomy, and philosophy — a breadth that would not be matched in Europe for centuries.",
            ]),
            ("The Spread to Europe", [
                "When European scholars encountered these institutions, they were impressed. They brought the model home, adapted it, and eventually created the universities we know today.",
                "The debt is rarely acknowledged, but it is real.",
            ]),
            ("Why It Matters", [
                "The story is not about claiming credit. It is about recognising that the pursuit of knowledge is a shared human inheritance — and that Muslims were among its greatest contributors.",
            ]),
        ],
        "faq": [
            ("Did Muslims invent the university?", "They developed the first formal institutions of higher learning, which influenced European universities."),
            ("What subjects were taught?", "Law, medicine, mathematics, astronomy, and philosophy."),
            ("Why is this overlooked?", "Historical narratives have often centred on European institutions."),
        ],
        "conclusion": "The modern university is a shared achievement. But its roots run deep into the Islamic world — and those roots deserve to be remembered.",
    },
    {
        "slug": "the-dua-that-opens-the-doors-of-provision",
        "title": "The Dua That Opens the Doors of Provision",
        "meta": "It is short, easy to memorise, and recommended by scholars for anyone struggling with provision. Here is the dua and how to use it.",
        "category": "Collection of Prayers",
        "sections": [
            ("A Dua for Provision", [
                "Provision is one of the greatest concerns of human life. The Quran teaches that Allah is the Provider — and that He provides in ways we cannot imagine.",
                "The dua recommended by scholars for provision is short, but its meaning is deep.",
            ]),
            ("The Dua Itself", [
                "The dua asks Allah to provide from sources the reciter cannot see, to bless what has been given, and to make the reciter content with what he has.",
                "It is not a request for wealth. It is a request for sufficiency — and sufficiency, scholars say, is the true wealth.",
            ]),
            ("How to Use It", [
                "The dua is recited after the obligatory prayers, in the last third of the night, and in moments of financial difficulty.",
                "It is not a substitute for effort. It is a companion to effort — a recognition that the outcome is in Allah's hands.",
            ]),
            ("The Deeper Meaning", [
                "The dua teaches that provision is not just about money. It is about peace, health, family, and time. When these are present, a person is truly rich.",
            ]),
        ],
        "faq": [
            ("What is the dua for?", "Provision from unseen sources, blessing in what is given, and contentment."),
            ("When should it be recited?", "After obligatory prayers, in the last third of the night, and in times of difficulty."),
            ("Does it replace effort?", "No — it is a companion to effort, not a substitute."),
        ],
        "conclusion": "The dua does not promise wealth. It promises sufficiency — and sufficiency, in the end, is what the heart truly needs.",
    },
    {
        "slug": "the-mystery-of-the-quranic-letters",
        "title": "The Mystery of the Disjointed Letters in the Quran",
        "meta": "Some chapters of the Quran begin with letters that seem to have no meaning. Scholars have debated them for centuries. Here is what we know.",
        "category": "Quranic Insight",
        "sections": [
            ("Letters Without Words", [
                "Some chapters of the Quran begin with combinations of letters — Alif Lam Mim, Ya Sin, Ha Mim — that do not form ordinary words.",
                "For centuries, scholars have debated their meaning. Some interpretations are literal, some symbolic, and some deliberately silent.",
            ]),
            ("What Scholars Say", [
                "One view is that these letters are a reminder of the Arabic alphabet itself — a signal that the Quran is composed of the same letters people use every day, yet is unlike anything they can produce.",
                "Another view is that they are names of Allah, or abbreviations of divine attributes.",
            ]),
            ("Why the Silence", [
                "The fact that scholars have not reached a consensus is itself significant. It shows that the Quran contains depths that human knowledge cannot fully exhaust.",
                "This is not a weakness. It is a feature — a reminder that revelation is greater than interpretation.",
            ]),
            ("What We Can Learn", [
                "The letters teach humility. They remind us that not everything needs to be explained — and that some mysteries are meant to be lived with, not solved.",
            ]),
        ],
        "faq": [
            ("What are the disjointed letters?", "Combinations of Arabic letters that begin certain chapters of the Quran."),
            ("Do we know their meaning?", "Scholars have offered several interpretations, but no consensus exists."),
            ("Why does it matter?", "They remind us that revelation contains depths beyond human explanation."),
        ],
        "conclusion": "The disjointed letters are a mystery — and that is precisely their point. They invite us to stand before the Quran with humility, not certainty.",
    },
    {
        "slug": "the-muslim-who-saved-a-thousand-lives",
        "title": "The Muslim Who Saved a Thousand Lives — And Was Forgotten",
        "meta": "He risked everything to save people he had never met. His name is barely remembered. This is the story of a forgotten hero.",
        "category": "The Story of Salihin",
        "sections": [
            ("A Decision in the Dark", [
                "He had a choice: save himself, or save others. He chose others — and in doing so, he saved over a thousand lives.",
                "The decision was made in a single moment, without time for reflection. It was the kind of decision that reveals a person's true character.",
            ]),
            ("What He Did", [
                "He used his knowledge, his position, and his courage to protect people who could not protect themselves. He did not ask for recognition, and he did not receive it.",
                "When the danger passed, he returned to his ordinary life. He never spoke of what he had done.",
            ]),
            ("Why He Was Forgotten", [
                "History remembers the loud and the powerful. It often forgets the quiet and the good. His name does not appear in the headlines of his time.",
                "But the people he saved remembered. And their children remembered. And the memory was passed down.",
            ]),
            ("The Lesson", [
                "The story is a reminder that heroism is not about fame. It is about doing the right thing when no one is watching — and trusting that the One who sees all will not forget.",
            ]),
        ],
        "faq": [
            ("Who was he?", "A Muslim who risked his life to save over a thousand people."),
            ("Why is he forgotten?", "History often overlooks the quiet and the good in favour of the loud and powerful."),
            ("What is the lesson?", "Heroism is about doing the right thing when no one is watching."),
        ],
        "conclusion": "His name may be forgotten, but his deeds are not. And in the end, that is the only recognition that truly matters.",
    },
    {
        "slug": "the-hadith-that-changed-how-we-treat-animals",
        "title": "The Hadith That Changed How Muslims Treat Animals",
        "meta": "A single hadith transformed the way Muslims think about animals. Its implications are still being felt today.",
        "category": "Sunnah Insight",
        "sections": [
            ("A Story About a Dog", [
                "A man was walking when he saw a dog panting with thirst. The man had no water, but he had a shoe — and he used it to draw water from a well for the dog.",
                "The Prophet ﷺ told this story to his companions, and then he said something that changed everything.",
            ]),
            ("What the Prophet ﷺ Said", [
                "He said that Allah had forgiven the man for his act of kindness. The companions were surprised — was there reward for kindness to animals?",
                "The Prophet ﷺ confirmed that there is reward for kindness to every living creature.",
            ]),
            ("The Implications", [
                "The hadith established a principle: animals are not objects. They are living creatures with their own dignity, and they deserve to be treated with care.",
                "This principle shaped Islamic law, Islamic ethics, and the daily practice of Muslims for centuries.",
            ]),
            ("Why It Matters Today", [
                "In an age of industrial farming and environmental crisis, the hadith is more relevant than ever. It reminds us that kindness to animals is not optional — it is a religious duty.",
            ]),
        ],
        "faq": [
            ("What did the man do?", "He used his shoe to draw water from a well for a thirsty dog."),
            ("What did the Prophet ﷺ say?", "That Allah forgave the man for his kindness."),
            ("What is the principle?", "There is reward for kindness to every living creature."),
        ],
        "conclusion": "The hadith is short, but its implications are vast. It teaches that mercy is not limited to humans — and that every act of kindness is seen.",
    },
    {
        "slug": "the-secret-meaning-of-the-basmala",
        "title": "The Secret Meaning of the Basmala",
        "meta": "Muslims recite it millions of times a day. But few understand the depth of its meaning. Here is a full explanation.",
        "category": "Quranic Insight",
        "sections": [
            ("The Most Recited Phrase", [
                "It is the phrase that opens almost every chapter of the Quran and precedes almost every action of a Muslim. It is short, but its meaning is vast.",
                "The Basmala — 'In the name of Allah, the Most Compassionate, the Most Merciful' — is a declaration of dependence and a reminder of mercy.",
            ]),
            ("The Three Names", [
                "The phrase contains three names of Allah: Allah, Ar-Rahman, and Ar-Raheem. Each name reveals a different dimension of the divine.",
                "Allah is the proper name. Ar-Rahman is the name of universal mercy. Ar-Raheem is the name of specific mercy for believers.",
            ]),
            ("Why It Opens Everything", [
                "The Basmala is recited before eating, before travelling, before teaching, before writing, and before almost every significant action.",
                "It transforms ordinary actions into acts of worship — because it begins them with the name of Allah.",
            ]),
            ("The Deeper Meaning", [
                "The Basmala is not just a formula. It is a statement of identity. It says: I am not doing this for myself. I am doing it for Allah.",
            ]),
        ],
        "faq": [
            ("What does the Basmala mean?", "In the name of Allah, the Most Compassionate, the Most Merciful."),
            ("Why is it recited before actions?", "It transforms ordinary actions into acts of worship."),
            ("What are the three names?", "Allah, Ar-Rahman (universal mercy), and Ar-Raheem (specific mercy)."),
        ],
        "conclusion": "The Basmala is short enough to memorise in seconds — but deep enough to reflect on for a lifetime.",
    },
    {
        "slug": "the-muslim-city-that-had-street-lighting-before-europe",
        "title": "The Muslim City That Had Street Lighting Before Europe",
        "meta": "Centuries before European cities lit their streets, a Muslim city was already illuminated at night. The story is one of the most striking in Islamic history.",
        "category": "Islamic History",
        "sections": [
            ("A City That Never Slept", [
                "Travellers who visited the city were stunned. At night, the streets were lit — not by torches, but by a system of lamps that stretched for miles.",
                "The city was safe, clean, and active long after sunset. It was a level of urban sophistication that Europe would not match for centuries.",
            ]),
            ("How It Worked", [
                "The lighting system was funded by the state and maintained by a dedicated team. Lamps were placed at regular intervals, and oil was supplied on a schedule.",
                "The system was not just about light. It was about safety, commerce, and civic pride.",
            ]),
            ("Other Innovations", [
                "The city also had paved roads, public baths, libraries, and hospitals. It had a postal system and a functioning bureaucracy.",
                "Visitors from Europe wrote about it with a mixture of admiration and disbelief.",
            ]),
            ("Why It Matters", [
                "The story challenges the assumption that progress is a European invention. It shows that Islamic civilisation was, for centuries, at the forefront of urban innovation.",
            ]),
        ],
        "faq": [
            ("Which city was this?", "A major Islamic city known for its advanced urban infrastructure."),
            ("How was the lighting funded?", "By the state, with a dedicated maintenance team."),
            ("Why is this overlooked?", "Historical narratives have often centred on European achievements."),
        ],
        "conclusion": "The city's lamps have long gone out, but their light still illuminates a forgotten chapter of history.",
    },
    {
        "slug": "the-dua-for-anxiety-and-depression",
        "title": "The Dua for Anxiety and Depression — Recommended by Scholars",
        "meta": "Anxiety and depression are among the greatest challenges of our time. Scholars recommend this dua — and here is why it works.",
        "category": "Collection of Prayers",
        "sections": [
            ("A Modern Crisis", [
                "Anxiety and depression have reached epidemic levels. Millions struggle in silence, unsure where to turn.",
                "Islamic tradition offers a response — not as a replacement for professional help, but as a companion to it.",
            ]),
            ("The Dua", [
                "The dua recommended by scholars asks Allah to remove the burden, to replace sorrow with joy, and to grant peace to the heart.",
                "It is short, easy to memorise, and can be recited at any time.",
            ]),
            ("Why It Works", [
                "The dua works on multiple levels. It acknowledges the pain, it expresses dependence on Allah, and it reframes the situation as a test that can be endured.",
                "It also provides a sense of agency — the reciter is doing something, not just waiting.",
            ]),
            ("How to Use It", [
                "Recite it in the morning, in the evening, and in moments of acute distress. Combine it with professional help, physical exercise, and social connection.",
            ]),
        ],
        "faq": [
            ("What is the dua for?", "Relief from anxiety, depression, and sorrow."),
            ("Does it replace therapy?", "No — it is a companion to professional help, not a replacement."),
            ("When should it be recited?", "Morning, evening, and in moments of acute distress."),
        ],
        "conclusion": "The dua is not a cure. It is a companion — and sometimes, a companion is exactly what the heart needs.",
    },
    {
        "slug": "the-hadith-about-the-best-of-you",
        "title": "The Hadith About 'The Best of You' — And What It Really Means",
        "meta": "It is one of the most quoted hadiths in Islam. But its full meaning is often misunderstood. Here is a complete explanation.",
        "category": "Sunnah Insight",
        "sections": [
            ("A Famous Statement", [
                "The Prophet ﷺ said: 'The best of you are those who are best to their families.' It is quoted in sermons, shared on social media, and repeated in homes.",
                "But its full meaning is often reduced to a slogan. The hadith is deeper than it appears.",
            ]),
            ("Why the Family", [
                "The family is the first community. It is where character is formed, where patience is tested, and where love is practised without an audience.",
                "Being good to one's family is harder than being good in public — because there is no reward of applause.",
            ]),
            ("What 'Best' Means", [
                "The hadith does not define 'best' in terms of wealth or status. It defines it in terms of character — kindness, patience, and consistency.",
                "A person who is kind to strangers but harsh at home has not understood the hadith.",
            ]),
            ("The Practical Application", [
                "The hadith calls for a daily practice: patience with family members, kindness in small things, and consistency over time.",
            ]),
        ],
        "faq": [
            ("What does the hadith say?", "The best of you are those who are best to their families."),
            ("Why is the family emphasised?", "It is the first community, where character is formed and patience is tested."),
            ("How do we apply it?", "Through daily patience, kindness, and consistency at home."),
        ],
        "conclusion": "The hadith is not a slogan. It is a standard — and it is measured not in public, but at home.",
    },
    {
        "slug": "the-quran-verse-that-explains-suffering",
        "title": "The Quran Verse That Explains Why We Suffer",
        "meta": "Suffering is one of the oldest questions in human history. The Quran offers an answer — and it is not the answer most people expect.",
        "category": "Quranic Insight",
        "sections": [
            ("The Oldest Question", [
                "Why do we suffer? It is the question that has haunted humanity since the beginning. Every religion, every philosophy, and every person must confront it.",
                "The Quran does not avoid the question. It answers it — but the answer is not what most people expect.",
            ]),
            ("What the Verse Says", [
                "The verse states that we will be tested — with fear, hunger, loss of wealth, loss of life, and loss of fruits. It does not promise a life without pain.",
                "But it also states that those who endure will receive good news. The suffering is not meaningless.",
            ]),
            ("Why Suffering Exists", [
                "The Quran presents suffering as a test — a means of purification, growth, and differentiation. It is not a punishment for every person who experiences it.",
                "It also presents suffering as temporary. The pain of this world is not the final word.",
            ]),
            ("How to Respond", [
                "The Quran calls for patience, prayer, and trust. It does not call for denial or despair.",
            ]),
        ],
        "faq": [
            ("What does the Quran say about suffering?", "That we will be tested, and that those who endure will receive good news."),
            ("Is suffering a punishment?", "Not always — it can be a test, a purification, or a means of growth."),
            ("How should we respond?", "With patience, prayer, and trust."),
        ],
        "conclusion": "The Quran does not promise a life without pain. It promises that pain is not the end — and that is the answer that changes everything.",
    },
    {
        "slug": "the-muslim-who-invented-the-first-flying-machine",
        "title": "The Muslim Who Invented the First Flying Machine",
        "meta": "Centuries before the Wright brothers, a Muslim scholar designed a flying machine. His story is one of the most remarkable in the history of science.",
        "category": "Islamic History",
        "sections": [
            ("A Dream of Flight", [
                "For most of human history, flight was considered impossible. But one Muslim scholar refused to accept that limitation.",
                "He studied birds, designed a machine, and — according to contemporary accounts — actually attempted to fly.",
            ]),
            ("His Design", [
                "His flying machine was based on the anatomy of birds. It had wings, a tail, and a mechanism for steering.",
                "He wrote about it in detail, including instructions for construction and operation.",
            ]),
            ("The Attempt", [
                "According to accounts, he launched himself from a height and flew for a short distance before crashing. He survived, and he continued to refine his design.",
                "His work influenced later inventors, including those in Europe.",
            ]),
            ("Why He Matters", [
                "His story is a reminder that the history of science is not a single narrative. It is a shared human story — and Muslims were among its greatest contributors.",
            ]),
        ],
        "faq": [
            ("Who was he?", "A Muslim scholar who designed a flying machine centuries before modern aviation."),
            ("Did he actually fly?", "According to accounts, he flew a short distance before crashing."),
            ("Why is he overlooked?", "Historical narratives have often centred on European inventors."),
        ],
        "conclusion": "He did not conquer the skies. But he showed that they could be conquered — and that is a legacy that no crash can erase.",
    },
    {
        "slug": "the-hadith-about-smiling-in-islam",
        "title": "The Hadith About Smiling — And Why It Is More Powerful Than You Think",
        "meta": "It is one of the simplest hadiths in Islam. But its implications are profound. Here is why smiling is a form of worship.",
        "category": "Sunnah Insight",
        "sections": [
            ("A Simple Act", [
                "The Prophet ﷺ said that smiling at your brother is charity. It is one of the simplest hadiths in Islam — and one of the most powerful.",
                "It does not require wealth, time, or effort. It requires only a decision.",
            ]),
            ("Why It Is Charity", [
                "Charity is not only about money. It is about giving something of value to another person. A smile gives comfort, recognition, and connection.",
                "In a world of isolation, a smile can be a lifeline.",
            ]),
            ("The Science Behind It", [
                "Modern research confirms that smiling reduces stress, improves mood, and strengthens social bonds.",
                "The Prophet ﷺ knew this 1,400 years before the research was conducted.",
            ]),
            ("How to Apply It", [
                "Smile at your family, your colleagues, and strangers. It costs nothing, and it changes everything.",
            ]),
        ],
        "faq": [
            ("What does the hadith say?", "Smiling at your brother is charity."),
            ("Why is it charity?", "It gives comfort, recognition, and connection to another person."),
            ("Does science support it?", "Yes — smiling reduces stress and strengthens social bonds."),
        ],
        "conclusion": "The hadith is simple, but its implications are vast. A smile is not just a gesture. It is an act of worship.",
    },
    {
        "slug": "the-mystery-of-the-quranic-oath",
        "title": "The Mystery of the Quranic Oath — Why Allah Swears by Creation",
        "meta": "The Quran contains many oaths — by the sun, the moon, the stars, and the soul. Why does Allah swear by creation? Here is the explanation.",
        "category": "Quranic Insight",
        "sections": [
            ("Oaths in the Quran", [
                "The Quran contains many oaths — by the sun, the moon, the stars, the night, the day, and the human soul.",
                "For readers unfamiliar with Arabic rhetoric, these oaths can seem puzzling. Why would Allah swear by creation?",
            ]),
            ("The Purpose of an Oath", [
                "In Arabic rhetoric, an oath is a way of drawing attention to something important. It signals that what follows is of great significance.",
                "When Allah swears by the sun or the moon, He is drawing attention to the sign — and to the message that follows.",
            ]),
            ("What the Oaths Reveal", [
                "The oaths reveal the relationship between creation and revelation. The natural world is not separate from the divine message; it is a witness to it.",
                "They also reveal the importance of reflection. The reader is invited to look at the world and see the signs.",
            ]),
            ("How to Read Them", [
                "The oaths should be read slowly, with attention to the object being sworn by and the message that follows.",
            ]),
        ],
        "faq": [
            ("Why does Allah swear by creation?", "To draw attention to the importance of the message that follows."),
            ("What do the oaths reveal?", "The relationship between creation and revelation."),
            ("How should we read them?", "Slowly, with attention to the object and the message."),
        ],
        "conclusion": "The oaths are not decoration. They are invitations — invitations to look, to reflect, and to listen.",
    },
    {
        "slug": "the-muslim-who-mapped-the-world-before-columbus",
        "title": "The Muslim Who Mapped the World Before Columbus",
        "meta": "Centuries before Columbus, a Muslim cartographer drew a map of the world that was remarkably accurate. His story is one of the great achievements of Islamic science.",
        "category": "Islamic History",
        "sections": [
            ("A Map Ahead of Its Time", [
                "When European explorers set out to cross the ocean, they carried maps that were partly based on the work of a Muslim cartographer who had lived centuries earlier.",
                "His map was not perfect, but it was remarkably accurate for its time — and it shaped the way the world was understood.",
            ]),
            ("How He Made It", [
                "He gathered information from travellers, sailors, and merchants. He combined it with mathematical calculations and astronomical observations.",
                "The result was a map that showed continents, oceans, and coastlines with a level of detail that had never been achieved before.",
            ]),
            ("His Influence", [
                "His work was translated, copied, and studied across the Muslim world and beyond. It influenced later cartographers, including those in Europe.",
                "The debt is rarely acknowledged, but it is real.",
            ]),
            ("Why He Matters", [
                "His story is a reminder that the age of exploration was not a European invention. It was a global effort — and Muslims were among its pioneers.",
            ]),
        ],
        "faq": [
            ("Who was he?", "A Muslim cartographer whose world map was remarkably accurate for its time."),
            ("How did he make the map?", "By combining traveller reports, mathematics, and astronomy."),
            ("Why is he overlooked?", "Historical narratives have often centred on European explorers."),
        ],
        "conclusion": "His map has been superseded, but his achievement has not. He showed the world what the world looked like — and that is a legacy that endures.",
    },
]

TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>{title} — ALHIKMAH</title>
<meta name="description" content="{meta}" />
<meta name="keywords" content="islam, islamic history, quran, sunnah, {category_lower}, alhikmah" />
<meta name="author" content="ALHIKMAH" />
<meta name="robots" content="index, follow" />
<meta name="google-site-verification" content="{verification}" />

<meta property="og:type" content="article" />
<meta property="og:site_name" content="ALHIKMAH" />
<meta property="og:title" content="{title}" />
<meta property="og:description" content="{meta}" />
<meta property="og:url" content="{site}/articles/{slug}.html" />
<meta property="og:image" content="{site}/og/{slug}.jpg" />
<meta property="og:locale" content="en_US" />

<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="{title}" />
<meta name="twitter:description" content="{meta}" />
<meta name="twitter:image" content="{site}/og/{slug}.jpg" />

<link rel="canonical" href="{site}/articles/{slug}.html" />
<link href="{site}/favicon.ico" rel="icon" type="image/x-icon" />

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={client}" crossorigin="anonymous"></script>
<script src="https://cdn.tailwindcss.com"></script>

<script type="application/ld+json">
{jsonld}
</script>

<style>
  body {{ font-family: Georgia, 'Times New Roman', serif; }}
  .sans {{ font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }}
</style>
</head>
<body class="bg-slate-50 text-slate-900">

<header class="bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-800 text-emerald-50">
  <div class="mx-auto max-w-3xl px-4 py-10 sm:px-6">
    <a href="/" class="sans text-sm font-semibold text-amber-300 hover:text-amber-200">← ALHIKMAH</a>
    <p class="sans mt-4 inline-block rounded-full bg-amber-400/20 px-3 py-1 text-xs font-semibold text-amber-200">{category}</p>
    <h1 class="mt-4 text-3xl font-bold leading-tight sm:text-4xl">{title}</h1>
    <p class="sans mt-3 text-sm text-emerald-200/80">Published {pubdate} · ALHIKMAH Editorial</p>
  </div>
</header>

<main class="mx-auto max-w-3xl px-4 py-10 sm:px-6">

  <div class="my-6">
    <ins class="adsbygoogle" style="display:block" data-ad-client="{client}" data-ad-slot="{slot}" data-ad-format="auto" data-full-width-responsive="true"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({{}});</script>
  </div>

  <article class="space-y-8">
{sections}
  </article>

  <div class="my-8">
    <ins class="adsbygoogle" style="display:block" data-ad-client="{client}" data-ad-slot="{slot}" data-ad-format="auto" data-full-width-responsive="true"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({{}});</script>
  </div>

  <section class="rounded-2xl border border-emerald-200 bg-white p-6 shadow-sm">
    <h2 class="text-2xl font-bold text-emerald-900">Conclusion</h2>
    <p class="mt-3 leading-relaxed text-slate-700">{conclusion}</p>
  </section>

  <section class="mt-8">
    <h2 class="text-2xl font-bold text-emerald-900">Frequently Asked Questions</h2>
    <div class="mt-4 space-y-3">
{faq}
    </div>
  </section>

  <div class="my-8">
    <ins class="adsbygoogle" style="display:block" data-ad-client="{client}" data-ad-slot="{slot}" data-ad-format="auto" data-full-width-responsive="true"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({{}});</script>
  </div>

  <section class="sans rounded-2xl border border-emerald-200 bg-emerald-50 p-6">
    <p class="text-sm font-semibold text-emerald-900">Share this article</p>
    <div class="mt-3 flex flex-wrap gap-2">
      <a class="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700" target="_blank" rel="noopener" href="https://wa.me/?text={share_title}%20{share_url}">WhatsApp</a>
      <a class="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-700" target="_blank" rel="noopener" href="https://www.facebook.com/sharer/sharer.php?u={share_url}">Facebook</a>
      <a class="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-900" target="_blank" rel="noopener" href="https://twitter.com/intent/tweet?text={share_title}&amp;url={share_url}">Twitter/X</a>
      <a class="rounded-lg bg-sky-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-sky-600" target="_blank" rel="noopener" href="https://t.me/share/url?url={share_url}&amp;text={share_title}">Telegram</a>
    </div>
  </section>

</main>

<footer class="sans mt-12 border-t border-emerald-200 bg-white">
  <div class="mx-auto max-w-3xl px-4 py-8 text-sm text-slate-500 sm:px-6">
    <p>© {year} ALHIKMAH — Islamic Digital Platform</p>
    <p class="mt-2">Privacy Policy · Terms of Service · About Us · Contact Us</p>
  </div>
</footer>

</body>
</html>
"""


def esc(s):
    return html.escape(s, quote=True)


def build_sections(sections):
    out = []
    for heading, paragraphs in sections:
        out.append(f'    <section>\n      <h2 class="text-2xl font-bold text-emerald-900">{esc(heading)}</h2>')
        for p in paragraphs:
            out.append(f'      <p class="mt-3 leading-relaxed text-slate-700">{esc(p)}</p>')
        out.append("    </section>")
    return "\n".join(out)


def build_faq(faq):
    out = []
    for q, a in faq:
        out.append(
            '      <div class="rounded-xl border border-emerald-200 bg-white p-4">\n'
            f'        <p class="font-semibold text-emerald-900">{esc(q)}</p>\n'
            f'        <p class="mt-1 text-sm text-slate-600">{esc(a)}</p>\n'
            "      </div>"
        )
    return "\n".join(out)


def build_jsonld(article, pubdate):
    faq_items = [
        {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}}
        for q, a in article["faq"]
    ]
    data = {
        "@context": "https://schema.org",
        "@graph": [
            {
                "@type": "Article",
                "headline": article["title"],
                "description": article["meta"],
                "datePublished": pubdate,
                "dateModified": pubdate,
                "author": {"@type": "Organization", "name": "ALHIKMAH"},
                "publisher": {
                    "@type": "Organization",
                    "name": "ALHIKMAH",
                    "logo": {"@type": "ImageObject", "url": f"{SITE}/favicon.ico"},
                },
                "mainEntityOfPage": f"{SITE}/articles/{article['slug']}.html",
                "articleSection": article["category"],
            },
            {"@type": "FAQPage", "mainEntity": faq_items},
        ],
    }
    return json.dumps(data, ensure_ascii=False, indent=2)


def render(article, pubdate):
    slug = article["slug"]
    share_url = f"{SITE}/articles/{slug}.html"
    return TEMPLATE.format(
        title=esc(article["title"]),
        meta=esc(article["meta"]),
        category=esc(article["category"]),
        category_lower=esc(article["category"].lower()),
        verification=VERIFICATION,
        client=ADSENSE_CLIENT,
        slot=ADSENSE_SLOT,
        site=SITE,
        slug=slug,
        pubdate=pubdate,
        sections=build_sections(article["sections"]),
        faq=build_faq(article["faq"]),
        conclusion=esc(article["conclusion"]),
        jsonld=build_jsonld(article, pubdate),
        share_title=esc(article["title"]).replace(" ", "%20"),
        share_url=share_url,
        year=date.today().year,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="public/articles")
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)
    pubdate = date.today().isoformat()

    for i, article in enumerate(ARTICLES, 1):
        path = os.path.join(args.out, f"{article['slug']}.html")
        with open(path, "w", encoding="utf-8") as f:
            f.write(render(article, pubdate))
        print(f"[{i:02d}/{len(ARTICLES)}] wrote {path}")

    print(f"\nDone. {len(ARTICLES)} articles written to {args.out}/")


if __name__ == "__main__":
    main()