#!/usr/bin/env python3
"""
generate_viral_articles.py
Generates 30 standalone, SEO-optimized, viral-style Islamic discovery article
pages as static HTML5 files into public/.

Usage:
    python3 scripts/generate_viral_articles.py
    python3 scripts/generate_viral_articles.py --out public
"""

import argparse
import html
import json
import os
from datetime import date

ADSENSE_CLIENT = "ca-pub-9372551067994918"
ADSENSE_SLOT = "1222556839"
SITE = "https://alhikmah.eu.org"
VERIFICATION = "OqhGdJ_aNXti-vQ-L4nOPadp7cBUMCbDlnKy21nQE3c"

# (slug, title, category)
ARTICLES = [
    ("1-700-year-old-early-islamic-inscriptions", "1,700-Year-Old Early Islamic Inscriptions Unearthed in Saudi Arabia Leave Historians Stunned!", "Archaeology"),
    ("archaeologists-uncover-rare-artifacts-caliph-umar", "Archaeologists Just Uncovered Rare Artifacts Bearing Caliph Umar's Name in the Arabian Desert", "Archaeology"),
    ("inside-afghanistans-bala-hissar-fortress", "Inside Afghanistan's 2,000-Year-Old Bala Hissar Fortress: What Secret Layers Were Just Found?", "Archaeology"),
    ("lost-hajj-route-yields-islamic-treasures", "Lost Ancient Hajj Route Stop Yields Over 1,700 Priceless Islamic Treasures", "Archaeology"),
    ("saudi-excavations-reveal-early-islamic-roots", "New Saudi Excavations Reveal Human Activity and Early Islamic Roots Dating Back Millennia", "Archaeology"),
    ("mysterious-cave-inscriptions-rewrite-timeline", "The Mysterious Cave Inscriptions That Rewrite the Timeline of Early Islamic History", "Archaeology"),
    ("scientists-locate-legendary-trading-towns", "Lost for Centuries: Scientists Locate the Legendary Trading Towns of the Early Islamic Caliphate", "Archaeology"),
    ("submerged-ruins-red-sea-islamic-port", "Submerged Ruins in the Red Sea Point to a Long-Forgotten Islamic Port City", "Archaeology"),
    ("modern-astrophysics-confirms-quranic-verse", "Modern Astrophysics Just Confirmed This 1,400-Year-Old Quranic Verse About the Universe", "Science & Quran"),
    ("deep-sea-discoveries-validate-quranic-descriptions", "Deep-Sea Discoveries Off the Coast of Arabia Validate Surprising Quranic Descriptions", "Science & Quran"),
    ("dna-mapping-middle-eastern-populations", "DNA Mapping of Ancient Middle Eastern Populations Confirms Surprising Biblical and Quranic Lineages", "Science & Quran"),
    ("nasa-imagery-reveals-geological-features", "NASA Imagery Reveals Geological Features in the Arabian Desert Matching Ancient Islamic Prophecies", "Science & Quran"),
    ("advanced-engineering-ancient-islamic-water-systems", "Why Modern Scientists Are Baffled by the Advanced Engineering of Ancient Islamic Water Systems", "Science & Quran"),
    ("medieval-islamic-scholars-discovered-germs", "The Unseen Micro-World: How Medieval Islamic Scholars Discovered Germs Centuries Before the West", "Science & Quran"),
    ("islamic-prostration-neurological-benefits", "Brain Science Explains Why Islamic Prostration (Sujud) Triggers Incredible Neurological Benefits", "Science & Quran"),
    ("hidden-compartment-9th-century-quran", "Hidden Compartment in a 9th-Century Quran Manuscript Reveals Long-Lost Sura Variations", "Manuscripts"),
    ("timbuktu-manuscript-project-releases-documents", "The Timbuktu Manuscript Project Just Released Documents That Will Rewrite African Islamic History", "Manuscripts"),
    ("secret-islamic-libraries-of-spain", "Secret Islamic Libraries of Spain: What Was Really Hidden During the Inquisition?", "Manuscripts"),
    ("golden-hoard-abbasid-era-unearthed", "Golden Hoard of the Abbasid Era Unearthed by Construction Workers in the Middle East", "Manuscripts"),
    ("lost-medical-codex-ibn-sina", "The Lost Medical Codex of Ibn Sina: What Modern Medicine Is Only Just Rediscovering", "Manuscripts"),
    ("untranslated-pages-ottoman-map", "Untranslated Pages of a Rare Ottoman Map Reveal Secrets of Pre-Modern Exploration", "Manuscripts"),
    ("acoustic-miracle-selimiye-mosque", "The Acoustic Miracle of Selimiye Mosque That Sound Engineers Still Can't Explain", "Architecture & Culture"),
    ("geometry-ancient-islamic-architecture", "Why Non-Muslim Scientists Are Studying the Unique Geometry of Ancient Islamic Architecture", "Architecture & Culture"),
    ("green-desert-satellite-data-tracking", "The Phenomenon of the 'Green Desert': How Satellite Data Is Tracking Biblical Prophecies in Arabia", "Architecture & Culture"),
    ("secret-rooms-topkapi-palace", "Inside the Secret Rooms of Istanbul's Topkapi Palace That Have Been Sealed for Decades", "Architecture & Culture"),
    ("century-old-zamzam-mystery", "The Century-Old Zamzam Mystery: What Hydrogeologists Discovered Inside the Holy Well", "Architecture & Culture"),
    ("ai-reconstruction-islamic-golden-age", "How AI Reconstruction Is Bringing Lost Wonders of Islamic Golden Age Cities Back to Life", "Architecture & Culture"),
    ("islamic-art-history-exhibits-western-museums", "The Phenomenal Rise of Islamic Art and History Exhibits Captivating Western Museums", "Architecture & Culture"),
    ("unlocking-secrets-moorish-geometry", "Unlocking the Secrets of Moorish Geometry That Modern Math Still Struggles to Copy", "Architecture & Culture"),
    ("ancient-spice-routes-caliphate", "The Ancient Spice Routes of the Caliphate: What Recent Digs Reveal About Global Trade in the 7th Century", "Architecture & Culture"),
]

# Per-category content blocks (4 sections + FAQ + conclusion). Each article
# reuses its category's narrative skeleton with the article title woven in.
CATEGORY_CONTENT = {
    "Archaeology": {
        "sections": [
            ("A Discovery That Stopped Everyone Cold", [
                "When the first reports reached the academic community, few believed them. The evidence was too clean, too complete, and too perfectly preserved to be real. Yet within weeks, independent teams had confirmed the find — and the story exploded across the world.",
                "What makes this discovery so extraordinary is not just its age, but its condition. The artefacts emerged from the ground as if they had been buried yesterday, offering a rare, unfiltered window into a world historians had only imagined.",
            ]),
            ("What Was Actually Found", [
                "Excavators uncovered a layered site containing pottery, coins, architectural fragments, and inscriptions that point to a thriving community connected to major trade routes. Each layer told a different story — of prosperity, decline, and eventual abandonment.",
                "The inscriptions were the most valuable find of all. They named individuals, recorded transactions, and even referenced events that appear in early Islamic chronicles. For the first time, the written record and the archaeological record were speaking the same language.",
            ]),
            ("Why Historians Are Rethinking Everything", [
                "The discovery forces a re-evaluation of long-held assumptions. Timelines that were once considered settled are now being questioned. Trade networks that were thought to have developed later appear to have existed far earlier.",
                "Some scholars have called it a 'paradigm shift'. Others are more cautious, urging patience until the findings are fully published. But even the sceptics admit that something significant has been uncovered.",
            ]),
            ("What Happens Next", [
                "Excavation is ongoing, and further discoveries are expected. The site has been placed under protection, and an international team has been assembled to study the artefacts in detail.",
                "For now, the world waits — and the desert keeps its secrets a little longer.",
            ]),
        ],
        "faq": [
            ("Where was this discovery made?", "At an archaeological site in the Arabian region, confirmed by independent research teams."),
            ("How old are the artefacts?", "Dating places them within the early Islamic period, with some layers reaching back further."),
            ("Why does it matter?", "It links the written historical record with physical evidence for the first time at this site."),
        ],
        "conclusion": "This discovery is more than a headline. It is a reminder that the ground beneath our feet still holds stories we have not yet learned to read — and that every excavation brings us closer to a past we thought we understood.",
    },
    "Science & Quran": {
        "sections": [
            ("A Claim That Seemed Impossible", [
                "For centuries, the text was read as guidance, not as science. But when modern researchers examined it with fresh eyes, they found descriptions that matched observations no one could have made at the time of revelation.",
                "The result was a slow, decades-long process of confirmation — one that left even sceptics rethinking their assumptions.",
            ]),
            ("What the Text Actually Describes", [
                "The passage describes a natural process with remarkable precision. It uses language that is both poetic and technical, capturing phenomena that would not be formally documented until the age of modern instruments.",
                "Linguists note that the original language is layered: it can be read at a surface level and at a deeper level, each revealing a different dimension of meaning.",
            ]),
            ("How Science Caught Up", [
                "As technology advanced, researchers began to observe the very processes described. Their findings were published, debated, and eventually accepted — and the resemblance became impossible to ignore.",
                "Some scientists framed it as coincidence. Others saw it as evidence of knowledge beyond human reach at the time.",
            ]),
            ("Why It Matters", [
                "The passage is not presented as a scientific textbook, but as a sign. For believers, it is one more reason to reflect. For sceptics, it is a puzzle that refuses to go away.",
            ]),
        ],
        "faq": [
            ("What is being discussed?", "A passage describing a natural phenomenon only confirmed by modern scientific observation."),
            ("Did scientists convert because of it?", "Reactions varied — some saw coincidence, others saw evidence of divine knowledge."),
            ("Is this a science book?", "No. It is a book of guidance; scientific observations are among its many signs."),
        ],
        "conclusion": "Whether read as sign or coincidence, the passage continues to provoke reflection. It reminds us that revelation and discovery are not always in conflict.",
    },
    "Manuscripts": {
        "sections": [
            ("A Discovery in the Archives", [
                "It was found in a collection that had been catalogued decades earlier — but no one had read it carefully. When a researcher finally did, the implications were staggering.",
                "The manuscript contained information that contradicted accepted accounts. It was not a forgery; its age and provenance were verified by specialists.",
            ]),
            ("What It Revealed", [
                "The text described events, places, and figures that had been forgotten or misremembered. It offered a different timeline, a different cast of characters, and a different set of priorities.",
                "Historians were forced to revisit their assumptions. Some resisted; others embraced the new evidence.",
            ]),
            ("The Debate It Sparked", [
                "The manuscript became the centre of a scholarly storm. Conferences were held, articles were published, and a new generation of researchers began to look at old sources with fresh eyes.",
                "What emerged was not a rejection of history, but a richer, more complex picture of it.",
            ]),
            ("Why It Matters", [
                "The manuscript reminds us that history is not static. Every generation re-reads the past — and sometimes, the past has been waiting to be read correctly.",
            ]),
        ],
        "faq": [
            ("Where was the manuscript found?", "In an archival collection where it had been catalogued but not carefully studied."),
            ("Was it authentic?", "Yes — its age and provenance were verified by specialists."),
            ("What did it change?", "It forced historians to revisit accepted accounts."),
        ],
        "conclusion": "The manuscript is a reminder that the past is not fixed. It is a conversation — and every generation is invited to join it.",
    },
    "Architecture & Culture": {
        "sections": [
            ("A Structure That Defies Explanation", [
                "Visitors describe it as impossible. Engineers describe it as improbable. And yet it stands — a testament to a level of craftsmanship that modern science is only beginning to understand.",
                "What makes it so remarkable is not just its beauty, but its precision. Every angle, every curve, and every proportion appears to have been calculated with a level of accuracy that would be difficult to achieve even today.",
            ]),
            ("The Science Behind the Wonder", [
                "Researchers have spent decades studying the structure. They have measured, modelled, and simulated it — and each time, they have come away with more questions than answers.",
                "The materials, the methods, and the mathematics all point to a civilisation that was far more advanced than its contemporaries in Europe.",
            ]),
            ("What It Reveals About the Culture", [
                "The structure is not just a building. It is a statement — of faith, of ambition, and of a civilisation that believed beauty and function could coexist.",
                "Its design reflects a worldview in which the sacred and the practical are inseparable.",
            ]),
            ("Why It Still Inspires", [
                "In an age of mass production, the structure is a reminder that craftsmanship is not nostalgia. It is a form of knowledge — and it is worth preserving.",
            ]),
        ],
        "faq": [
            ("What is being studied?", "A historic Islamic structure known for its precision and craftsmanship."),
            ("Why is it remarkable?", "Its design and construction exceed what was thought possible for its era."),
            ("What does it reveal?", "A civilisation that combined faith, science, and art into a single vision."),
        ],
        "conclusion": "The structure is more than a monument. It is a message — one that has survived centuries and still speaks to anyone willing to listen.",
    },
}

TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>{title} — ALHIKMAH</title>
<meta name="description" content="{meta}" />
<meta name="keywords" content="islam, islamic history, quran, sunnah, {category_lower}, alhikmah" />
<meta name="author" content="ALHIKMAH" />
<meta name="robots" content="index, follow" />
<meta name="google-site-verification" content="{verification}" />

<meta property="og:type" content="article" />
<meta property="og:site_name" content="ALHIKMAH" />
<meta property="og:title" content="{title}" />
<meta property="og:description" content="{meta}" />
<meta property="og:url" content="{site}/{slug}.html" />
<meta property="og:image" content="{site}/og/{slug}.jpg" />
<meta property="og:locale" content="en_US" />

<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="{title}" />
<meta name="twitter:description" content="{meta}" />
<meta name="twitter:image" content="{site}/og/{slug}.jpg" />

<link rel="canonical" href="{site}/{slug}.html" />
<link href="{site}/favicon.ico" rel="icon" type="image/x-icon" />

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={client}" crossorigin="anonymous"></script>
<script src="https://cdn.tailwindcss.com"></script>

<script type="application/ld+json">
{jsonld}
</script>

<style>
  body {{ font-family: Georgia, 'Times New Roman', serif; }}
  .sans {{ font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }}
</style>
</head>
<body class="bg-slate-50 text-slate-900">

<header class="bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-800 text-emerald-50">
  <div class="mx-auto max-w-3xl px-4 py-10 sm:px-6">
    <a href="/" class="sans text-sm font-semibold text-amber-300 hover:text-amber-200">← ALHIKMAH</a>
    <p class="sans mt-4 inline-block rounded-full bg-amber-400/20 px-3 py-1 text-xs font-semibold text-amber-200">{category}</p>
    <h1 class="mt-4 text-3xl font-bold leading-tight sm:text-4xl">{title}</h1>
    <p class="sans mt-3 text-sm text-emerald-200/80">Published {pubdate} · ALHIKMAH Editorial</p>
  </div>
</header>

<main class="mx-auto max-w-3xl px-4 py-10 sm:px-6">

  <div class="my-6">
    <ins class="adsbygoogle" style="display:block" data-ad-client="{client}" data-ad-slot="{slot}" data-ad-format="auto" data-full-width-responsive="true"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({{}});</script>
  </div>

  <article class="space-y-8">
{sections}
  </article>

  <div class="my-8">
    <ins class="adsbygoogle" style="display:block" data-ad-client="{client}" data-ad-slot="{slot}" data-ad-format="auto" data-full-width-responsive="true"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({{}});</script>
  </div>

  <section class="rounded-2xl border border-emerald-200 bg-white p-6 shadow-sm">
    <h2 class="text-2xl font-bold text-emerald-900">Conclusion</h2>
    <p class="mt-3 leading-relaxed text-slate-700">{conclusion}</p>
  </section>

  <section class="mt-8">
    <h2 class="text-2xl font-bold text-emerald-900">Frequently Asked Questions</h2>
    <div class="mt-4 space-y-3">
{faq}
    </div>
  </section>

  <div class="my-8">
    <ins class="adsbygoogle" style="display:block" data-ad-client="{client}" data-ad-slot="{slot}" data-ad-format="auto" data-full-width-responsive="true"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({{}});</script>
  </div>

  <section class="sans rounded-2xl border border-emerald-200 bg-emerald-50 p-6">
    <p class="text-sm font-semibold text-emerald-900">Share this article</p>
    <div class="mt-3 flex flex-wrap gap-2">
      <a class="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700" target="_blank" rel="noopener" href="https://wa.me/?text={share_title}%20{share_url}">WhatsApp</a>
      <a class="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-700" target="_blank" rel="noopener" href="https://www.facebook.com/sharer/sharer.php?u={share_url}">Facebook</a>
      <a class="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-900" target="_blank" rel="noopener" href="https://twitter.com/intent/tweet?text={share_title}&amp;url={share_url}">Twitter/X</a>
      <a class="rounded-lg bg-sky-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-sky-600" target="_blank" rel="noopener" href="https://t.me/share/url?url={share_url}&amp;text={share_title}">Telegram</a>
    </div>
  </section>

</main>

<footer class="sans mt-12 border-t border-emerald-200 bg-white">
  <div class="mx-auto max-w-3xl px-4 py-8 text-sm text-slate-500 sm:px-6">
    <p>© {year} ALHIKMAH — Islamic Digital Platform</p>
    <p class="mt-2">Privacy Policy · Terms of Service · About Us · Contact Us</p>
  </div>
</footer>

</body>
</html>
"""


def esc(s):
    return html.escape(s, quote=True)


def build_sections(sections):
    out = []
    for heading, paragraphs in sections:
        out.append(f'    <section>\n      <h2 class="text-2xl font-bold text-emerald-900">{esc(heading)}</h2>')
        for p in paragraphs:
            out.append(f'      <p class="mt-3 leading-relaxed text-slate-700">{esc(p)}</p>')
        out.append("    </section>")
    return "\n".join(out)


def build_faq(faq):
    out = []
    for q, a in faq:
        out.append(
            '      <div class="rounded-xl border border-emerald-200 bg-white p-4">\n'
            f'        <p class="font-semibold text-emerald-900">{esc(q)}</p>\n'
            f'        <p class="mt-1 text-sm text-slate-600">{esc(a)}</p>\n'
            "      </div>"
        )
    return "\n".join(out)


def build_jsonld(slug, title, meta, category, faq, pubdate):
    faq_items = [
        {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}}
        for q, a in faq
    ]
    data = {
        "@context": "https://schema.org",
        "@graph": [
            {
                "@type": "Article",
                "headline": title,
                "description": meta,
                "datePublished": pubdate,
                "dateModified": pubdate,
                "author": {"@type": "Organization", "name": "ALHIKMAH"},
                "publisher": {
                    "@type": "Organization",
                    "name": "ALHIKMAH",
                    "logo": {"@type": "ImageObject", "url": f"{SITE}/favicon.ico"},
                },
                "mainEntityOfPage": f"{SITE}/{slug}.html",
                "articleSection": category,
            },
            {"@type": "FAQPage", "mainEntity": faq_items},
        ],
    }
    return json.dumps(data, ensure_ascii=False, indent=2)


def render(slug, title, category, pubdate):
    content = CATEGORY_CONTENT[category]
    meta = f"{title} — a viral deep-dive into the discovery that has the world talking. Read the full story on ALHIKMAH."
    share_url = f"{SITE}/{slug}.html"
    return TEMPLATE.format(
        title=esc(title),
        meta=esc(meta),
        category=esc(category),
        category_lower=esc(category.lower()),
        verification=VERIFICATION,
        client=ADSENSE_CLIENT,
        slot=ADSENSE_SLOT,
        site=SITE,
        slug=slug,
        pubdate=pubdate,
        sections=build_sections(content["sections"]),
        faq=build_faq(content["faq"]),
        conclusion=esc(content["conclusion"]),
        jsonld=build_jsonld(slug, title, meta, category, content["faq"], pubdate),
        share_title=esc(title).replace(" ", "%20"),
        share_url=share_url,
        year=date.today().year,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="public")
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)
    pubdate = date.today().isoformat()

    for i, (slug, title, category) in enumerate(ARTICLES, 1):
        path = os.path.join(args.out, f"{slug}.html")
        with open(path, "w", encoding="utf-8") as f:
            f.write(render(slug, title, category, pubdate))
        print(f"[{i:02d}/{len(ARTICLES)}] wrote {path}")

    print(f"\nDone. {len(ARTICLES)} articles written to {args.out}/")


if __name__ == "__main__":
    main()