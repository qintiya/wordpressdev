npm install
npm run build      # pastikan SUKSES tanpa error
ls dist            # harus ada index.html + assets/