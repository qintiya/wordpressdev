python scripts/generate_articles.py   # output → public/*.html
git add public/*.html && git commit -m "Regenerate articles"
git push                              # Cloudflare auto-rebuild