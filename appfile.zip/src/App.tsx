import { useCallback, useEffect, useMemo, useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import {
  HomeSection,
  ArticlesSection,
  ArticleReader,
  ToolsSection,
  AdSlot,
} from "@/components/Sections";
import { ARTICLES, type Article } from "@/data/content";
import { makeT, type Lang } from "@/lib/i18n";

export type Route =
  | { name: "home" }
  | { name: "articles" }
  | { name: "tools" }
  | { name: "article"; article: Article }
  | { name: "about" }
  | { name: "contact" };

export default function App() {
  const [lang, setLang] = useState<Lang>("en");
  const [dark, setDark] = useState(false);
  const [query, setQuery] = useState("");
  const [route, setRoute] = useState<Route>({ name: "home" });

  const t = useMemo(() => makeT(lang), [lang]);

  useEffect(() => {
    const root = document.documentElement;
    if (dark) root.classList.add("dark");
    else root.classList.remove("dark");
  }, [dark]);

  const go = useCallback((name: string) => {
    if (name === "home") setRoute({ name: "home" });
    else if (name === "articles") setRoute({ name: "articles" });
    else if (name === "tools") setRoute({ name: "tools" });
    else if (name === "about") setRoute({ name: "about" });
    else if (name === "contact") setRoute({ name: "contact" });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const openArticle = useCallback((article: Article) => {
    setRoute({ name: "article", article });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const search = useCallback((q: string) => {
    setQuery(q);
    setRoute({ name: "articles" });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-emerald-950 dark:text-emerald-50">
      <Header
        t={t}
        lang={lang}
        setLang={setLang}
        dark={dark}
        setDark={setDark}
        route={route}
        go={go}
        onSearch={search}
      />

      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        {route.name === "home" && <HomeSection t={t} onOpen={openArticle} go={go} />}

        {route.name === "articles" && (
          <ArticlesSection t={t} onOpen={openArticle} query={query} />
        )}

        {route.name === "tools" && <ToolsSection t={t} />}

        {route.name === "article" && (
          <ArticleReader
            t={t}
            article={route.article}
            onBack={() => go("articles")}
            onOpen={openArticle}
          />
        )}

        {route.name === "about" && <AboutSection t={t} go={go} />}

        {route.name === "contact" && <ContactSection t={t} />}
      </main>

      <Footer t={t} go={go} onOpen={openArticle} />
    </div>
  );
}

function AboutSection({ t, go }: { t: (k: string) => string; go: (s: string) => void }) {
  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-emerald-200/70 bg-gradient-to-r from-emerald-50 to-amber-50 p-8 dark:border-emerald-900/60 dark:from-emerald-950/50 dark:to-amber-950/20">
        <h1 className="font-serif text-3xl font-bold">{t("aboutUs")}</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          ALHIKMAH is a trusted Islamic digital platform providing high-quality content on Islamic
          education, history, social issues, and culture.
        </p>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-2xl border border-emerald-200/70 bg-white p-6 shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
          <h2 className="font-serif text-xl font-bold">{t("vision")}</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            To be a trusted Islamic portal that provides authentic content based on the Quran and
            Sunnah, easily accessible to all Muslims in Indonesia and the world.
          </p>
        </div>
        <div className="rounded-2xl border border-emerald-200/70 bg-white p-6 shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
          <h2 className="font-serif text-xl font-bold">{t("mission")}</h2>
          <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
            <li>• In-depth Islamic articles with SEO standards (min. 3000 words)</li>
            <li>• Practical and useful Islamic digital tools</li>
            <li>• Disseminating Islamic content through modern digital media</li>
            <li>• Maintaining authenticity based on trusted sources</li>
          </ul>
        </div>
      </div>
      <button
        onClick={() => go("articles")}
        className="rounded-lg bg-emerald-700 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-emerald-800"
      >
        {t("readArticles")}
      </button>
    </div>
  );
}

function ContactSection({ t }: { t: (k: string) => string }) {
  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-emerald-200/70 bg-gradient-to-r from-emerald-50 to-amber-50 p-8 dark:border-emerald-900/60 dark:from-emerald-950/50 dark:to-amber-950/20">
        <h1 className="font-serif text-3xl font-bold">{t("contactUs")}</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          We would love to hear from you. Reach out for feedback, suggestions, or collaboration.
        </p>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { label: "Email", value: "salam@alhikmah.eu.org", href: "mailto:salam@alhikmah.eu.org" },
          { label: "Website", value: "alhikmah.eu.org", href: "https://alhikmah.eu.org" },
          {
            label: "GitHub",
            value: "alhikmah-my-id",
            href: "https://github.com/sponsors/alhikmah-my-id",
          },
        ].map((c) => (
          <a
            key={c.label}
            href={c.href}
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-2xl border border-emerald-200/70 bg-white p-5 shadow-sm transition-shadow hover:shadow-md dark:border-emerald-900/60 dark:bg-emerald-950/40"
          >
            <p className="text-xs uppercase tracking-wide text-muted-foreground">{c.label}</p>
            <p className="mt-1 font-semibold text-emerald-800 dark:text-emerald-300">{c.value}</p>
          </a>
        ))}
      </div>
      <AdSlot />
    </div>
  );
}