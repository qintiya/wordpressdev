import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  BookOpen,
  Wrench,
  Home,
  Info,
  Mail,
  Search,
  Moon,
  Sun,
  Globe,
  Menu,
  X,
  ChevronDown,
} from "lucide-react";
import type { Lang } from "@/lib/i18n";
import type { Route } from "@/App";

const LANGS: { code: Lang; label: string; flag: string }[] = [
  { code: "en", label: "English", flag: "🇬🇧" },
  { code: "id", label: "Indonesia", flag: "🇮🇩" },
  { code: "ar", label: "العربية", flag: "🇸🇦" },
  { code: "ja", label: "日本語", flag: "🇯🇵" },
  { code: "ru", label: "Русский", flag: "🇷🇺" },
  { code: "de", label: "Deutsch", flag: "🇩🇪" },
  { code: "hi", label: "हिन्दी", flag: "🇮🇳" },
];

export function Header({
  t,
  lang,
  setLang,
  dark,
  setDark,
  route,
  go,
  onSearch,
}: {
  t: (k: string) => string;
  lang: Lang;
  setLang: (l: Lang) => void;
  dark: boolean;
  setDark: (d: boolean) => void;
  route: Route;
  go: (s: string) => void;
  onSearch: (q: string) => void;
}) {
  const [q, setQ] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { id: "home", label: t("home"), icon: Home },
    { id: "articles", label: t("articles"), icon: BookOpen },
    { id: "tools", label: t("tools"), icon: Wrench },
    { id: "about", label: t("aboutUs"), icon: Info },
    { id: "contact", label: t("contactUs"), icon: Mail },
  ];

  const activeId = route.name === "article" ? "articles" : route.name;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(q);
    setMobileOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-emerald-900/20 bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-800 text-emerald-50 shadow-md">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
        <button
          onClick={() => go("home")}
          className="flex items-center gap-2.5 transition-opacity hover:opacity-90"
          aria-label="ALHIKMAH home"
        >
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-amber-400 font-serif text-xl font-bold text-emerald-950 shadow-sm">
            ﷲ
          </span>
          <span className="hidden flex-col leading-none sm:flex">
            <span className="font-serif text-lg font-bold tracking-wide text-amber-50">
              ALHIKMAH
            </span>
            <span className="text-[10px] uppercase tracking-widest text-emerald-300/80">
              Islamic Digital Platform
            </span>
          </span>
        </button>

        <nav className="ml-4 hidden items-center gap-1 lg:flex">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeId === item.id;
            return (
              <button
                key={item.id}
                onClick={() => go(item.id)}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  active
                    ? "bg-emerald-800/70 text-amber-200"
                    : "text-emerald-100/90 hover:bg-emerald-800/50 hover:text-amber-100"
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </button>
            );
          })}
        </nav>

        <form onSubmit={submit} className="ml-auto hidden items-center md:flex">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-300/70" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("search")}
              className="w-48 border-emerald-700/50 bg-emerald-900/50 pl-9 text-emerald-50 placeholder:text-emerald-300/60 focus-visible:ring-amber-400 lg:w-64"
            />
          </div>
        </form>

        <div className="ml-auto flex items-center gap-1.5 md:ml-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="gap-1.5 text-emerald-100 hover:bg-emerald-800/60 hover:text-amber-100"
              >
                <Globe className="h-4 w-4" />
                <span className="hidden sm:inline">{LANGS.find((l) => l.code === lang)?.flag}</span>
                <ChevronDown className="h-3.5 w-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuLabel>{t("language")}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {LANGS.map((l) => (
                <DropdownMenuItem
                  key={l.code}
                  onClick={() => setLang(l.code)}
                  className={lang === l.code ? "bg-emerald-50 font-semibold dark:bg-emerald-900/40" : ""}
                >
                  <span className="mr-2">{l.flag}</span>
                  {l.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setDark(!dark)}
            className="text-emerald-100 hover:bg-emerald-800/60 hover:text-amber-100"
            aria-label="Toggle theme"
          >
            {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setMobileOpen((v) => !v)}
            className="text-emerald-100 hover:bg-emerald-800/60 lg:hidden"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {mobileOpen && (
        <div className="border-t border-emerald-800/50 bg-emerald-950/95 px-4 py-3 lg:hidden">
          <form onSubmit={submit} className="mb-3 md:hidden">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-300/70" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t("search")}
                className="w-full border-emerald-700/50 bg-emerald-900/50 pl-9 text-emerald-50 placeholder:text-emerald-300/60"
              />
            </div>
          </form>
          <nav className="grid gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = activeId === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    go(item.id);
                    setMobileOpen(false);
                  }}
                  className={`inline-flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                    active
                      ? "bg-emerald-800/70 text-amber-200"
                      : "text-emerald-100/90 hover:bg-emerald-800/50"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>
      )}
    </header>
  );
}