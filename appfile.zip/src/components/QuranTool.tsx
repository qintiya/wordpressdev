import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Play,
  Pause,
  Search,
  ChevronLeft,
  ChevronRight,
  BookOpen,
  Volume2,
  Loader2,
  SkipBack,
  SkipForward,
} from "lucide-react";
import {
  SURAHS,
  RECITERS,
  surahAudioUrl,
  surahTextApi,
  type Surah,
} from "@/data/quran";

type T = (k: string) => string;

interface Ayah {
  number: number;
  arab: string;
  latin?: string;
  translation: string;
}

export function QuranTool({ t, audio }: { t: T; audio?: boolean }) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "Makkiyah" | "Madaniyah">("all");
  const [selected, setSelected] = useState<Surah | null>(null);
  const [reciter, setReciter] = useState(RECITERS[0].id);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [ayahs, setAyahs] = useState<Ayah[]>([]);
  const [error, setError] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const filtered = useMemo(() => {
    let list = SURAHS;
    if (filter !== "all") list = list.filter((s) => s.revelation === filter);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          s.arabic.includes(query) ||
          s.meaning.toLowerCase().includes(q) ||
          String(s.number) === query.trim()
      );
    }
    return list;
  }, [query, filter]);

  // Muat teks surah saat dipilih
  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    setAyahs([]);

    fetch(surahTextApi(selected.number))
      .then((r) => r.json())
      .then((data) => {
        if (cancelled) return;
        const editions = data?.data ?? [];
        const arab = editions.find((e: any) => e.edition?.identifier === "quran-uthmani");
        const en = editions.find((e: any) => e.edition?.identifier === "en.asad");
        const id = editions.find((e: any) => e.edition?.identifier === "id.indonesian");
        const base = arab ?? editions[0];
        const list: Ayah[] = (base?.ayahs ?? []).map((a: any, i: number) => ({
          number: a.numberInSurah ?? i + 1,
          arab: a.text ?? "",
          translation: id?.ayahs?.[i]?.text ?? en?.ayahs?.[i]?.text ?? "",
        }));
        setAyahs(list);
      })
      .catch(() => {
        if (!cancelled) setError("Gagal memuat teks surah. Periksa koneksi internet Anda.");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [selected]);

  // Kontrol audio
  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;
    if (playing) {
      el.play().catch(() => setPlaying(false));
    } else {
      el.pause();
    }
  }, [playing, selected, reciter]);

  const playSurah = (s: Surah) => {
    setSelected(s);
    setPlaying(true);
  };

  const togglePlay = () => setPlaying((p) => !p);

  const goSurah = (dir: -1 | 1) => {
    if (!selected) return;
    const idx = SURAHS.findIndex((s) => s.number === selected.number);
    const next = SURAHS[idx + dir];
    if (next) {
      setSelected(next);
      setPlaying(true);
    }
  };

  /* ---------- Tampilan daftar 114 surah ---------- */
  if (!selected) {
    return (
      <div className="space-y-5">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-64">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t("searchSurah")}
              className="pl-9"
            />
          </div>
          <Select value={filter} onValueChange={(v) => setFilter(v as any)}>
            <SelectTrigger className="w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("allSurahs")}</SelectItem>
              <SelectItem value="Makkiyah">Makkiyah</SelectItem>
              <SelectItem value="Madaniyah">Madaniyah</SelectItem>
            </SelectContent>
          </Select>
          <Badge variant="secondary">{filtered.length} / 114</Badge>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((s) => (
            <Card
              key={s.number}
              className="group cursor-pointer border-emerald-200/70 bg-white shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md dark:border-emerald-900/60 dark:bg-emerald-950/40"
              onClick={() => setSelected(s)}
            >
              <CardContent className="flex items-center gap-3 pt-5">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-emerald-100 text-sm font-bold text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300">
                  {s.number}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate font-semibold transition-colors group-hover:text-emerald-700 dark:group-hover:text-emerald-400">
                      {s.name}
                    </p>
                    <span className="font-serif text-lg text-emerald-800 dark:text-emerald-300" dir="rtl">
                      {s.arabic}
                    </span>
                  </div>
                  <p className="truncate text-xs text-muted-foreground">
                    {s.meaning} · {s.ayahs} {t("ayahs")} · {s.revelation}
                  </p>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="shrink-0 text-emerald-700 hover:bg-emerald-50 dark:text-emerald-400 dark:hover:bg-emerald-900/40"
                  onClick={(e) => {
                    e.stopPropagation();
                    playSurah(s);
                  }}
                  aria-label="Play"
                >
                  <Play className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filtered.length === 0 && (
          <Card className="border-dashed">
            <CardContent className="py-16 text-center text-muted-foreground">
              {t("noResults")}
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  /* ---------- Tampilan detail surah + pemutar ---------- */
  return (
    <div className="space-y-5">
      <Button variant="ghost" size="sm" onClick={() => { setSelected(null); setPlaying(false); }} className="gap-1.5">
        <ChevronLeft className="h-4 w-4" /> {t("allSurahs")}
      </Button>

      <Card className="overflow-hidden border-emerald-200/70 bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-800 shadow-lg dark:border-emerald-900/60">
        <CardContent className="pt-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-3">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-amber-400/20 text-lg font-bold text-amber-300">
                  {selected.number}
                </span>
                <div>
                  <h2 className="font-serif text-2xl font-bold text-amber-50">{selected.name}</h2>
                  <p className="text-sm text-emerald-200/80">
                    {selected.meaning} · {selected.ayahs} {t("ayahs")} · {selected.revelation}
                  </p>
                </div>
              </div>
              <p className="mt-3 font-serif text-3xl text-amber-200" dir="rtl">
                {selected.arabic}
              </p>
            </div>
            <div className="flex flex-col items-end gap-3">
              <Select value={reciter} onValueChange={setReciter}>
                <SelectTrigger className="w-56 border-emerald-700/50 bg-emerald-900/40 text-amber-50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {RECITERS.map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex items-center gap-2">
                <Button
                  size="icon"
                  variant="outline"
                  onClick={() => goSurah(-1)}
                  className="border-emerald-700/50 bg-emerald-900/40 text-amber-50 hover:bg-emerald-800/60"
                  aria-label="Previous surah"
                >
                  <SkipBack className="h-4 w-4" />
                </Button>
                <Button
                  onClick={togglePlay}
                  className="gap-2 bg-amber-400 text-emerald-950 hover:bg-amber-300"
                >
                  {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  {playing ? t("pause") : t("play")}
                </Button>
                <Button
                  size="icon"
                  variant="outline"
                  onClick={() => goSurah(1)}
                  className="border-emerald-700/50 bg-emerald-900/40 text-amber-50 hover:bg-emerald-800/60"
                  aria-label="Next surah"
                >
                  <SkipForward className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <audio
            ref={audioRef}
            src={surahAudioUrl(selected.number, reciter)}
            onEnded={() => goSurah(1)}
            onPlay={() => setPlaying(true)}
            onPause={() => setPlaying(false)}
            controls
            className="mt-5 w-full"
          />
        </CardContent>
      </Card>

      {loading && (
        <div className="flex items-center justify-center gap-2 py-10 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" /> {t("loading")}
        </div>
      )}

      {error && (
        <Card className="border-dashed border-rose-300 bg-rose-50/50 dark:border-rose-900/60 dark:bg-rose-950/20">
          <CardContent className="py-6 text-center text-sm text-rose-700 dark:text-rose-300">
            {error}
          </CardContent>
        </Card>
      )}

      {!loading && ayahs.length > 0 && (
        <div className="space-y-3">
          {selected.number !== 1 && selected.number !== 9 && (
            <p className="text-center font-serif text-xl text-emerald-800 dark:text-emerald-300" dir="rtl">
              بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
            </p>
          )}
          {ayahs.map((a) => (
            <Card
              key={a.number}
              className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40"
            >
              <CardContent className="pt-5">
                <div className="mb-3 flex items-center justify-between">
                  <span className="grid h-7 w-7 place-items-center rounded-lg bg-emerald-100 text-xs font-bold text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300">
                    {a.number}
                  </span>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="text-emerald-700 hover:bg-emerald-50 dark:text-emerald-400 dark:hover:bg-emerald-900/40"
                    onClick={() => {
                      const u = new SpeechSynthesisUtterance(a.arab);
                      u.lang = "ar-SA";
                      window.speechSynthesis.cancel();
                      window.speechSynthesis.speak(u);
                    }}
                    aria-label="Listen ayah"
                  >
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-right font-serif text-2xl leading-loose text-foreground" dir="rtl">
                  {a.arab}
                </p>
                {a.translation && (
                  <p className="mt-3 border-t border-emerald-100 pt-3 text-sm leading-relaxed text-muted-foreground dark:border-emerald-900/60">
                    {a.translation}
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between pt-2">
        <Button variant="outline" onClick={() => goSurah(-1)} disabled={selected.number === 1} className="gap-1.5">
          <ChevronLeft className="h-4 w-4" /> {t("prev")}
        </Button>
        <span className="text-sm text-muted-foreground">
          {selected.number} / 114
        </span>
        <Button variant="outline" onClick={() => goSurah(1)} disabled={selected.number === 114} className="gap-1.5">
          {t("next")} <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}