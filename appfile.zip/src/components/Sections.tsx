import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BookOpen,
  Wrench,
  Share2,
  Copy,
  ChevronLeft,
  ChevronRight,
  Volume2,
  Square,
  Eye,
  Clock,
  Sparkles,
  Target,
  Layers,
  Smartphone,
  Check,
  Search,
} from "lucide-react";
import {
  ARTICLES,
  CATEGORIES,
  TOOLS,
  TOOL_GROUPS,
  NEWS,
  ARCHIVE,
  type Article,
} from "@/data/content";
import { ToolBody } from "@/components/Tools";

type T = (k: string) => string;

/* ---------------- Ad slot ---------------- */
export function AdSlot({ label = "Advertisement" }: { label?: string }) {
  return (
    <div className="my-6 overflow-hidden rounded-xl border border-dashed border-emerald-300/60 bg-emerald-50/60 p-4 text-center dark:border-emerald-800/60 dark:bg-emerald-950/30">
      <p className="text-[11px] uppercase tracking-widest text-emerald-700/70 dark:text-emerald-300/60">
        {label}
      </p>
      <ins
        className="adsbygoogle"
        style={{ display: "block" }}
        data-ad-client="ca-pub-9372551067994918"
        data-ad-slot="1222556839"
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
      <p className="mt-2 text-xs text-muted-foreground">
        Google AdSense · ca-pub-9372551067994918
      </p>
    </div>
  );
}

/* ---------------- Share bar ---------------- */
function ShareBar({ t, title }: { t: T; title: string }) {
  const [copied, setCopied] = useState(false);
  const url = typeof window !== "undefined" ? window.location.href : "https://alhikmah.eu.org";
  const enc = encodeURIComponent;
  const links = [
    { name: "WhatsApp", href: `https://wa.me/?text=${enc(title + " " + url)}`, color: "bg-emerald-600 hover:bg-emerald-700" },
    { name: "Facebook", href: `https://www.facebook.com/sharer/sharer.php?u=${enc(url)}`, color: "bg-blue-600 hover:bg-blue-700" },
    { name: "Twitter/X", href: `https://twitter.com/intent/tweet?text=${enc(title)}&url=${enc(url)}`, color: "bg-slate-800 hover:bg-slate-900" },
    { name: "Telegram", href: `https://t.me/share/url?url=${enc(url)}&text=${enc(title)}`, color: "bg-sky-500 hover:bg-sky-600" },
  ];
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="mr-1 inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground">
        <Share2 className="h-4 w-4" /> {t("share")}
      </span>
      {links.map((l) => (
        <a
          key={l.name}
          href={l.href}
          target="_blank"
          rel="noopener noreferrer"
          className={`rounded-lg px-3 py-1.5 text-xs font-semibold text-white transition-colors ${l.color}`}
        >
          {l.name}
        </a>
      ))}
      <Button
        size="sm"
        variant="outline"
        onClick={() => {
          navigator.clipboard?.writeText(url);
          setCopied(true);
          setTimeout(() => setCopied(false), 1800);
        }}
        className="gap-1.5"
      >
        {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
        {copied ? t("copied") : t("copyLink")}
      </Button>
    </div>
  );
}

/* ---------------- Sidebar ---------------- */
function Sidebar({ t, onOpen }: { t: T; onOpen: (a: Article) => void }) {
  const popular = useMemo(() => [...ARTICLES].sort((a, b) => b.views - a.views).slice(0, 5), []);
  return (
    <aside className="space-y-6">
      <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <span className="grid h-7 w-7 place-items-center rounded-lg bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300">
              📰
            </span>
            {t("newsUpdate")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {NEWS.map((n) => (
            <div key={n.title} className="group cursor-pointer">
              <p className="text-sm font-medium leading-snug text-foreground transition-colors group-hover:text-emerald-700 dark:group-hover:text-emerald-400">
                {n.title}
              </p>
              <p className="text-xs text-muted-foreground">{n.date}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <span className="grid h-7 w-7 place-items-center rounded-lg bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">
              🔥
            </span>
            {t("popularPosts")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {popular.map((a, i) => (
            <button
              key={a.id}
              onClick={() => onOpen(a)}
              className="flex w-full gap-3 text-left transition-opacity hover:opacity-80"
            >
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-emerald-950 text-xs font-bold text-amber-300">
                {i + 1}
              </span>
              <span>
                <span className="block text-sm font-medium leading-snug">{a.title}</span>
                <span className="text-xs text-muted-foreground">
                  {a.views.toLocaleString()} {t("views")}
                </span>
              </span>
            </button>
          ))}
        </CardContent>
      </Card>

      <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <span className="grid h-7 w-7 place-items-center rounded-lg bg-sky-100 text-sky-700 dark:bg-sky-900/40 dark:text-sky-300">
              🗂️
            </span>
            {t("archive")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {ARCHIVE.map((a) => (
            <div key={a.label} className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">{a.label}</span>
              <Badge variant="secondary">{a.count}</Badge>
            </div>
          ))}
        </CardContent>
      </Card>

      <SponsorCard t={t} />
    </aside>
  );
}

/* ---------------- Sponsor ---------------- */
export function SponsorCard({ t }: { t: T }) {
  return (
    <Card className="overflow-hidden border-amber-300/70 bg-gradient-to-br from-amber-50 to-emerald-50 shadow-sm dark:border-amber-900/50 dark:from-emerald-950/60 dark:to-amber-950/30">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <span className="grid h-7 w-7 place-items-center rounded-lg bg-amber-200 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300">
            💳
          </span>
          {t("sponsor")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">{t("sponsorText")}</p>
        <div className="rounded-xl border border-amber-200/70 bg-white/70 p-3 dark:border-amber-900/40 dark:bg-emerald-950/40">
          <div className="mb-2 flex items-center justify-between text-xs font-medium">
            <span className="inline-flex items-center gap-1.5">
              <Target className="h-3.5 w-3.5 text-amber-600" /> 0 / 250 {t("monthlyTarget")}
            </span>
            <span className="text-muted-foreground">0%</span>
          </div>
          <Progress value={0} className="h-2" />
        </div>
        <div className="flex flex-wrap gap-2">
          <a
            href="https://github.com/sponsors/alhikmah-my-id"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-lg bg-emerald-700 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-emerald-800"
          >
            <Sparkles className="h-4 w-4" /> GitHub Sponsors
          </a>
          <a
            href="https://github.com/sponsors/alhikmah-my-id"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-lg border border-emerald-300 bg-white px-4 py-2 text-sm font-semibold text-emerald-800 transition-colors hover:bg-emerald-50 dark:border-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-200"
          >
            ❤️ Sponsor
          </a>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------------- Article card ---------------- */
function ArticleCard({ a, t, onOpen }: { a: Article; t: T; onOpen: (a: Article) => void }) {
  return (
    <Card className="group flex flex-col overflow-hidden border-emerald-200/70 bg-white shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <div className="h-1.5 w-full bg-gradient-to-r from-emerald-600 via-emerald-500 to-amber-400" />
      <CardHeader className="pb-2">
        <div className="mb-1 flex items-center gap-2">
          <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100 dark:bg-emerald-900/50 dark:text-emerald-300">
            {a.category}
          </Badge>
        </div>
        <CardTitle className="cursor-pointer text-lg leading-snug transition-colors group-hover:text-emerald-700 dark:group-hover:text-emerald-400">
          <button onClick={() => onOpen(a)} className="text-left">
            {a.title}
          </button>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col">
        <p className="mb-4 line-clamp-3 text-sm text-muted-foreground">{a.excerpt}</p>
        <div className="mt-auto flex items-center justify-between text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" /> {a.readMin} {t("minRead")}
          </span>
          <span className="inline-flex items-center gap-1">
            <Eye className="h-3.5 w-3.5" /> {a.views.toLocaleString()}
          </span>
        </div>
        <Button
          onClick={() => onOpen(a)}
          className="mt-4 w-full bg-emerald-700 hover:bg-emerald-800"
        >
          {t("readMore")}
        </Button>
      </CardContent>
    </Card>
  );
}

/* ---------------- Home ---------------- */
export function HomeSection({
  t,
  onOpen,
  go,
}: {
  t: T;
  onOpen: (a: Article) => void;
  go: (s: string) => void;
}) {
  const featured = ARTICLES.slice(0, 6);
  return (
    <div className="space-y-10">
      <section className="relative overflow-hidden rounded-2xl border border-emerald-900/20 bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-800 p-8 shadow-lg sm:p-12">
        <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-amber-400/20 blur-3xl" />
        <div className="absolute -bottom-20 -left-10 h-56 w-56 rounded-full bg-emerald-400/20 blur-3xl" />
        <div className="relative max-w-3xl">
          <Badge className="mb-4 bg-amber-400/20 text-amber-200 hover:bg-amber-400/20">
            ✨ {t("tagline")}
          </Badge>
          <h1 className="font-serif text-3xl font-bold leading-tight text-amber-50 sm:text-5xl">
            {t("brand")}
          </h1>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-emerald-100/90 sm:text-lg">
            {t("tagline")} — high-quality content on Islamic education, history, social issues and
            culture, built with a modern architecture across web, Android and iOS.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button onClick={() => go("articles")} className="bg-amber-400 text-emerald-950 hover:bg-amber-300">
              <BookOpen className="mr-2 h-4 w-4" /> {t("articles")}
            </Button>
            <Button
              onClick={() => go("tools")}
              variant="outline"
              className="border-emerald-300/40 bg-emerald-900/40 text-amber-50 hover:bg-emerald-800/60"
            >
              <Wrench className="mr-2 h-4 w-4" /> {t("tools")}
            </Button>
          </div>
          <div className="mt-8 grid max-w-lg grid-cols-3 gap-4">
            {[
              { n: "300+", l: t("articles") },
              { n: "29", l: t("tools") },
              { n: "114", l: "Surah" },
            ].map((s) => (
              <div key={s.l} className="rounded-xl border border-emerald-700/40 bg-emerald-900/40 p-3 text-center">
                <p className="font-serif text-2xl font-bold text-amber-300">{s.n}</p>
                <p className="text-xs text-emerald-200/80">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <AdSlot />

      <section className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-serif text-2xl font-bold">{t("latestArticles")}</h2>
            <Button variant="ghost" size="sm" onClick={() => go("articles")}>
              {t("allCategories")} <ChevronRight className="ml-1 h-4 w-4" />
            </Button>
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            {featured.map((a) => (
              <ArticleCard key={a.id} a={a} t={t} onOpen={onOpen} />
            ))}
          </div>
        </div>
        <Sidebar t={t} onOpen={onOpen} />
      </section>

      <section className="grid gap-6 md:grid-cols-3">
        <Card className="border-emerald-200/70 bg-emerald-50/70 shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Target className="h-5 w-5 text-emerald-700 dark:text-emerald-400" /> {t("vision")}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            To be a trusted Islamic portal that provides authentic content based on the Quran and
            Sunnah, easily accessible to all Muslims in Indonesia and the world.
          </CardContent>
        </Card>
        <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Layers className="h-5 w-5 text-emerald-700 dark:text-emerald-400" /> {t("mission")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>• In-depth Islamic articles with SEO standards (min. 3000 words)</p>
            <p>• Practical and useful Islamic digital tools</p>
            <p>• Disseminating Islamic content through modern digital media</p>
            <p>• Maintaining authenticity based on trusted sources</p>
          </CardContent>
        </Card>
        <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Smartphone className="h-5 w-5 text-emerald-700 dark:text-emerald-400" /> {t("multiPlatform")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>• Web App — React 19 + TypeScript + Tailwind CSS</p>
            <p>• Android — Kotlin &amp; Java (min SDK 21)</p>
            <p>• iOS — Swift (min iOS 14)</p>
            <p>• PWA — Installable, offline-ready, manifest.json</p>
          </CardContent>
        </Card>
      </section>

      <section>
        <h2 className="mb-4 font-serif text-2xl font-bold">{t("keyFeatures")}</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { i: "📚", t: "SEO-Ready Articles", d: "Min. 3000 words, h1–h6 structure" },
            { i: "🧭", t: "Interactive TOC", d: "Auto-scroll table of contents" },
            { i: "❓", t: "FAQ + JSON-LD", d: "Rich snippets for search" },
            { i: "🔗", t: "Media Share", d: "WhatsApp, FB, X, Telegram, Copy" },
            { i: "🔤", t: "Pegon Converter", d: "Latin ↔ Arabic Pegon" },
            { i: "📅", t: "Hijri Calendar", d: "Gregorian → Hijri" },
            { i: "⏱️", t: "Timer & Stopwatch", d: "For worship and study" },
            { i: "✒️", t: "Calligraphy", d: "6 Arabic calligraphy styles" },
          ].map((f) => (
            <Card key={f.t} className="border-emerald-200/70 bg-white shadow-sm transition-shadow hover:shadow-md dark:border-emerald-900/60 dark:bg-emerald-950/40">
              <CardContent className="pt-6">
                <span className="mb-3 grid h-10 w-10 place-items-center rounded-xl bg-emerald-100 text-xl dark:bg-emerald-900/50">
                  {f.i}
                </span>
                <p className="font-semibold">{f.t}</p>
                <p className="mt-1 text-sm text-muted-foreground">{f.d}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}

/* ---------------- Articles list ---------------- */
export function ArticlesSection({
  t,
  onOpen,
  query,
}: {
  t: T;
  onOpen: (a: Article) => void;
  query: string;
}) {
  const [cat, setCat] = useState<string>("all");
  const [page, setPage] = useState(1);
  const perPage = 9;

  const filtered = useMemo(() => {
    let list = ARTICLES;
    if (cat !== "all") list = list.filter((a) => a.category === CATEGORIES.find((c) => c.id === cat)?.name);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (a) => a.title.toLowerCase().includes(q) || a.category.toLowerCase().includes(q) || a.excerpt.toLowerCase().includes(q)
      );
    }
    return list;
  }, [cat, query]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const current = Math.min(page, totalPages);
  const slice = filtered.slice((current - 1) * perPage, current * perPage);

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-emerald-200/70 bg-gradient-to-r from-emerald-50 to-amber-50 p-6 dark:border-emerald-900/60 dark:from-emerald-950/50 dark:to-amber-950/20">
        <h1 className="font-serif text-3xl font-bold">{t("articles")}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {filtered.length} {t("articles")} · {CATEGORIES.length} {t("categories")}
        </p>
      </div>

      <AdSlot />

      <div className="flex flex-wrap items-center gap-3">
        <Select value={cat} onValueChange={(v) => { setCat(v); setPage(1); }}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder={t("allCategories")} />
          </SelectTrigger>
          <SelectContent className="max-h-72">
            <SelectItem value="all">{t("allCategories")}</SelectItem>
            {CATEGORIES.map((c) => (
              <SelectItem key={c.id} value={c.id}>
                {c.name} ({c.count})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {query && (
          <Badge variant="secondary" className="gap-1">
            <Search className="h-3 w-3" /> {query}
          </Badge>
        )}
      </div>

      {slice.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-16 text-center">
            <p className="text-lg font-medium">{t("noResults")}</p>
            <p className="mt-1 text-sm text-muted-foreground">Try a different keyword or category.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {slice.map((a) => (
            <ArticleCard key={a.id} a={a} t={t} onOpen={onOpen} />
          ))}
        </div>
      )}

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 pt-2">
          <Button variant="outline" size="sm" disabled={current === 1} onClick={() => setPage(current - 1)}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm text-muted-foreground">
            {current} / {totalPages}
          </span>
          <Button variant="outline" size="sm" disabled={current === totalPages} onClick={() => setPage(current + 1)}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  );
}

/* ---------------- Article reader ---------------- */
export function ArticleReader({
  t,
  article,
  onBack,
  onOpen,
}: {
  t: T;
  article: Article;
  onBack: () => void;
  onOpen: (a: Article) => void;
}) {
  const [speaking, setSpeaking] = useState(false);
  const idx = ARTICLES.findIndex((a) => a.id === article.id);
  const prev = idx > 0 ? ARTICLES[idx - 1] : null;
  const next = idx < ARTICLES.length - 1 ? ARTICLES[idx + 1] : null;

  const speak = () => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    const text = `${article.title}. ${article.sections.map((s) => s.heading + ". " + s.body.join(" ")).join(" ")} ${article.conclusion}`;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "en-US";
    u.onend = () => setSpeaking(false);
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
    setSpeaking(true);
  };

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="grid gap-8 lg:grid-cols-3">
      <article className="lg:col-span-2">
        <Button variant="ghost" size="sm" onClick={onBack} className="mb-4 gap-1.5">
          <ChevronLeft className="h-4 w-4" /> {t("back")}
        </Button>

        <Badge className="mb-3 bg-emerald-100 text-emerald-800 hover:bg-emerald-100 dark:bg-emerald-900/50 dark:text-emerald-300">
          {article.category}
        </Badge>
        <h1 className="font-serif text-3xl font-bold leading-tight sm:text-4xl">{article.title}</h1>
        <div className="mt-3 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
          <span>{article.author}</span>
          <span>{article.date}</span>
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" /> {article.readMin} {t("minRead")}
          </span>
          <span className="inline-flex items-center gap-1">
            <Eye className="h-3.5 w-3.5" /> {article.views.toLocaleString()} {t("views")}
          </span>
        </div>

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <Button onClick={speak} className="gap-2 bg-emerald-700 hover:bg-emerald-800">
            {speaking ? <Square className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            {speaking ? t("stop") : t("listen")}
          </Button>
          <ShareBar t={t} title={article.title} />
        </div>

        <Separator className="my-6" />

        <AdSlot />

        <div className="prose prose-emerald max-w-none dark:prose-invert">
          {article.sections.map((s, i) => (
            <section key={i} id={`sec-${i}`} className="scroll-mt-24">
              <h2 className="mt-8 font-serif text-2xl font-bold">{s.heading}</h2>
              {s.body.map((p, j) => (
                <p key={j} className="mt-3 leading-relaxed text-foreground/90">
                  {p}
                </p>
              ))}
            </section>
          ))}

          <h2 className="mt-8 font-serif text-2xl font-bold">{t("conclusion")}</h2>
          <p className="mt-3 leading-relaxed text-foreground/90">{article.conclusion}</p>

          <h2 className="mt-8 font-serif text-2xl font-bold">{t("faq")}</h2>
          <div className="mt-3 space-y-3">
            {article.faq.map((f, i) => (
              <div key={i} className="rounded-xl border border-emerald-200/70 bg-emerald-50/50 p-4 dark:border-emerald-900/60 dark:bg-emerald-950/30">
                <p className="font-semibold">{f.q}</p>
                <p className="mt-1 text-sm text-muted-foreground">{f.a}</p>
              </div>
            ))}
          </div>
        </div>

        <AdSlot />

        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-between">
          {prev ? (
            <Button variant="outline" onClick={() => onOpen(prev)} className="h-auto justify-start py-3 text-left">
              <ChevronLeft className="mr-2 h-4 w-4 shrink-0" />
              <span>
                <span className="block text-xs text-muted-foreground">{t("prev")}</span>
                <span className="block max-w-xs truncate text-sm font-medium">{prev.title}</span>
              </span>
            </Button>
          ) : (
            <span />
          )}
          {next && (
            <Button variant="outline" onClick={() => onOpen(next)} className="h-auto justify-end py-3 text-right">
              <span>
                <span className="block text-xs text-muted-foreground">{t("next")}</span>
                <span className="block max-w-xs truncate text-sm font-medium">{next.title}</span>
              </span>
              <ChevronRight className="ml-2 h-4 w-4 shrink-0" />
            </Button>
          )}
        </div>
      </article>

      <aside className="space-y-6">
        <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">{t("tableOfContents")}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {article.sections.map((s, i) => (
              <button
                key={i}
                onClick={() => scrollTo(`sec-${i}`)}
                className="block w-full rounded-lg px-2 py-1.5 text-left text-sm text-muted-foreground transition-colors hover:bg-emerald-50 hover:text-emerald-800 dark:hover:bg-emerald-900/40 dark:hover:text-emerald-300"
              >
                {i + 1}. {s.heading}
              </button>
            ))}
            <button
              onClick={() => scrollTo("sec-0")}
              className="block w-full rounded-lg px-2 py-1.5 text-left text-sm text-muted-foreground transition-colors hover:bg-emerald-50 hover:text-emerald-800 dark:hover:bg-emerald-900/40"
            >
              {t("conclusion")}
            </button>
          </CardContent>
        </Card>
        <SponsorCard t={t} />
      </aside>
    </div>
  );
}

/* ---------------- Tools ---------------- */
export function ToolsSection({ t }: { t: T }) {
  const [active, setActive] = useState<string | null>(null);
  const [group, setGroup] = useState("all");

  const groups = ["all", ...TOOL_GROUPS];
  const list = group === "all" ? TOOLS : TOOLS.filter((x) => x.group === group);

  if (active) {
    return <ToolRunner id={active} t={t} onBack={() => setActive(null)} />;
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-emerald-200/70 bg-gradient-to-r from-emerald-50 to-amber-50 p-6 dark:border-emerald-900/60 dark:from-emerald-950/50 dark:to-amber-950/20">
        <h1 className="font-serif text-3xl font-bold">{t("toolsTitle")}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{t("toolsSubtitle")}</p>
      </div>

      <AdSlot />

      <div className="flex flex-wrap gap-2">
        {groups.map((g) => (
          <button
            key={g}
            onClick={() => setGroup(g)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
              group === g
                ? "bg-emerald-700 text-white"
                : "bg-emerald-50 text-emerald-800 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-300 dark:hover:bg-emerald-900/60"
            }`}
          >
            {g === "all" ? t("allCategories") : g}
          </button>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((tool) => (
          <Card
            key={tool.id}
            className="group cursor-pointer border-emerald-200/70 bg-white shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md dark:border-emerald-900/60 dark:bg-emerald-950/40"
            onClick={() => setActive(tool.id)}
          >
            <CardContent className="flex items-start gap-4 pt-6">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-emerald-100 text-xl dark:bg-emerald-900/50">
                {tool.icon}
              </span>
              <div className="min-w-0">
                <p className="font-semibold leading-snug transition-colors group-hover:text-emerald-700 dark:group-hover:text-emerald-400">
                  {tool.name}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">{tool.desc}</p>
                <p className="mt-2 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                  {t("openTool")} →
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Tool runner ---------------- */
function ToolRunner({ id, t, onBack }: { id: string; t: T; onBack: () => void }) {
  const tool = TOOLS.find((x) => x.id === id);
  return (
    <div className="space-y-6">
      <Button variant="ghost" size="sm" onClick={onBack} className="gap-1.5">
        <ChevronLeft className="h-4 w-4" /> {t("back")}
      </Button>
      <div className="rounded-2xl border border-emerald-200/70 bg-gradient-to-r from-emerald-50 to-amber-50 p-6 dark:border-emerald-900/60 dark:from-emerald-950/50 dark:to-amber-950/20">
        <h1 className="flex items-center gap-3 font-serif text-2xl font-bold">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-white text-xl shadow-sm dark:bg-emerald-900/60">
            {tool?.icon}
          </span>
          {tool?.name}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">{tool?.desc}</p>
      </div>
      <AdSlot />
      <ToolBody id={id} t={t} />
      <AdSlot />
    </div>
  );
}