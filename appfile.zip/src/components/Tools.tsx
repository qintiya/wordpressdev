import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CALLIGRAPHY_STYLES } from "@/data/content";
import { QuranTool } from "@/components/QuranTool";

type T = (k: string) => string;

/* ---------------- Pegon Converter ---------------- */
export function PegonTool({ t }: { t: T }) {
  const [text, setText] = useState("");
  const map: Record<string, string> = {
    a: "ا", b: "ب", t: "ت", ts: "ث", j: "ج", h: "ح", kh: "خ", d: "د", dz: "ذ",
    r: "ر", z: "ز", s: "س", sy: "ش", sh: "ص", dh: "ض", th: "ط", zh: "ظ",
    "'": "ع", g: "غ", f: "ف", q: "ق", k: "ك", l: "ل", m: "م", n: "ن",
    w: "و", y: "ي",
  };
  const convert = (s: string) =>
    s
      .toLowerCase()
      .split("")
      .map((c) => map[c] ?? c)
      .join("");
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">{t("pegonTitle")}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>{t("latinText")}</Label>
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Tulisan latin..."
            className="mt-1.5"
            rows={4}
          />
        </div>
        <div>
          <Label>{t("pegonResult")}</Label>
          <div
            className="mt-1.5 min-h-24 rounded-lg border border-emerald-200/70 bg-emerald-50/50 p-4 text-right font-serif text-2xl leading-loose dark:border-emerald-900/60 dark:bg-emerald-950/30"
            dir="rtl"
          >
            {convert(text) || <span className="text-muted-foreground">—</span>}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------------- Hijri Converter ---------------- */
export function HijriTool({ t }: { t: T }) {
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [result, setResult] = useState<string | null>(null);
  const convert = () => {
    try {
      const d = new Date(date);
      const fmt = new Intl.DateTimeFormat("id-ID-u-ca-islamic-umalqura", {
        day: "numeric",
        month: "long",
        year: "numeric",
      });
      setResult(fmt.format(d));
    } catch {
      setResult("—");
    }
  };
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">{t("hijriTitle")}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>{t("gregorianDate")}</Label>
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="mt-1.5" />
        </div>
        <Button onClick={convert} className="bg-emerald-700 hover:bg-emerald-800">
          {t("convert")}
        </Button>
        {result && (
          <div className="rounded-lg border border-emerald-200/70 bg-emerald-50/50 p-4 text-center dark:border-emerald-900/60 dark:bg-emerald-950/30">
            <p className="text-xs text-muted-foreground">{t("hijriDate")}</p>
            <p className="mt-1 font-serif text-2xl font-bold text-emerald-800 dark:text-emerald-300">
              {result}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ---------------- Timer & Stopwatch ---------------- */
export function TimerTool({ t }: { t: T }) {
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);
  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, [running]);
  const fmt = (s: number) =>
    `${String(Math.floor(s / 3600)).padStart(2, "0")}:${String(
      Math.floor((s % 3600) / 60)
    ).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardContent className="space-y-5 pt-6 text-center">
        <p className="font-serif text-5xl font-bold tabular-nums text-emerald-800 dark:text-emerald-300">
          {fmt(seconds)}
        </p>
        <div className="flex justify-center gap-3">
          <Button onClick={() => setRunning((r) => !r)} className="bg-emerald-700 hover:bg-emerald-800">
            {running ? t("pause") : t("play")}
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              setRunning(false);
              setSeconds(0);
            }}
          >
            {t("reset")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------------- Calligraphy ---------------- */
export function CalligraphyTool({ t }: { t: T }) {
  const [text, setText] = useState("بسم الله");
  const [style, setStyle] = useState(CALLIGRAPHY_STYLES[0]);
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">{t("calligraphyTitle")}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>{t("arabicText")}</Label>
          <Input
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="mt-1.5 text-right font-serif text-xl"
            dir="rtl"
          />
        </div>
        <div>
          <Label>{t("style")}</Label>
          <Select value={style} onValueChange={setStyle}>
            <SelectTrigger className="mt-1.5">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CALLIGRAPHY_STYLES.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="rounded-xl border border-emerald-200/70 bg-gradient-to-br from-emerald-50 to-amber-50 p-8 text-center dark:border-emerald-900/60 dark:from-emerald-950/40 dark:to-amber-950/20">
          <p className="font-serif text-5xl leading-loose text-emerald-900 dark:text-emerald-200" dir="rtl">
            {text}
          </p>
          <p className="mt-3 text-xs text-muted-foreground">{style}</p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------------- Zakat Calculator ---------------- */
export function ZakatTool({ t }: { t: T }) {
  const [wealth, setWealth] = useState("");
  const n = parseFloat(wealth) || 0;
  const zakat = n * 0.025;
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">{t("zakatTitle")}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>{t("totalWealth")}</Label>
          <Input
            type="number"
            value={wealth}
            onChange={(e) => setWealth(e.target.value)}
            placeholder="0"
            className="mt-1.5"
          />
        </div>
        <div className="rounded-lg border border-emerald-200/70 bg-emerald-50/50 p-4 text-center dark:border-emerald-900/60 dark:bg-emerald-950/30">
          <p className="text-xs text-muted-foreground">{t("zakatDue")} (2.5%)</p>
          <p className="mt-1 font-serif text-2xl font-bold text-emerald-800 dark:text-emerald-300">
            {zakat.toLocaleString("id-ID", { maximumFractionDigits: 0 })}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------------- Tasbeeh Counter ---------------- */
export function TasbeehTool({ t }: { t: T }) {
  const [count, setCount] = useState(0);
  const [target, setTarget] = useState(33);
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">{t("tasbeehTitle")}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-5 text-center">
        <p className="font-serif text-6xl font-bold tabular-nums text-emerald-800 dark:text-emerald-300">
          {count}
        </p>
        <p className="text-sm text-muted-foreground">
          {t("target")}: {target}
        </p>
        <div className="flex flex-wrap justify-center gap-3">
          <Button
            onClick={() => setCount((c) => c + 1)}
            className="bg-emerald-700 px-8 hover:bg-emerald-800"
          >
            +1
          </Button>
          <Button variant="outline" onClick={() => setCount(0)}>
            {t("reset")}
          </Button>
        </div>
        <div className="flex justify-center gap-2">
          {[33, 99, 100].map((n) => (
            <button
              key={n}
              onClick={() => setTarget(n)}
              className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
                target === n
                  ? "bg-emerald-700 text-white"
                  : "bg-emerald-50 text-emerald-800 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-300"
              }`}
            >
              {n}
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------------- Prayer Times ---------------- */
export function PrayerTimesTool({ t }: { t: T }) {
  const [city, setCity] = useState("Jakarta");
  const times = [
    { name: "Subuh", time: "04:35" },
    { name: "Dzuhur", time: "11:58" },
    { name: "Ashar", time: "15:18" },
    { name: "Maghrib", time: "18:05" },
    { name: "Isya", time: "19:18" },
  ];
  return (
    <Card className="border-emerald-200/70 bg-white shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/40">
      <CardHeader>
        <CardTitle className="text-lg">{t("prayerTimesTitle")}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>{t("city")}</Label>
          <Input value={city} onChange={(e) => setCity(e.target.value)} className="mt-1.5" />
        </div>
        <div className="grid gap-2">
          {times.map((p) => (
            <div
              key={p.name}
              className="flex items-center justify-between rounded-lg border border-emerald-200/70 bg-emerald-50/50 px-4 py-2.5 dark:border-emerald-900/60 dark:bg-emerald-950/30"
            >
              <span className="font-medium">{p.name}</span>
              <span className="font-serif text-lg font-bold text-emerald-800 dark:text-emerald-300">
                {p.time}
              </span>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground">
          {t("prayerNote")} — {city}
        </p>
      </CardContent>
    </Card>
  );
}

/* ---------------- Generic fallback ---------------- */
export function GenericTool({ t }: { t: T }) {
  return (
    <Card className="border-dashed border-emerald-300/70 bg-emerald-50/40 dark:border-emerald-900/60 dark:bg-emerald-950/30">
      <CardContent className="py-16 text-center">
        <p className="text-lg font-medium">{t("comingSoon")}</p>
        <p className="mt-1 text-sm text-muted-foreground">{t("comingSoonDesc")}</p>
      </CardContent>
    </Card>
  );
}

/* ---------------- Dispatcher ---------------- */
export function ToolBody({ id, t }: { id: string; t: T }) {
  switch (id) {
    case "pegon":
      return <PegonTool t={t} />;
    case "hijri":
      return <HijriTool t={t} />;
    case "timer":
      return <TimerTool t={t} />;
    case "calligraphy":
      return <CalligraphyTool t={t} />;
    case "quran":
    case "murotal":
      return <QuranTool t={t} audio={id === "murotal"} />;
    case "zakat":
      return <ZakatTool t={t} />;
    case "tasbeeh":
      return <TasbeehTool t={t} />;
    case "prayertimes":
      return <PrayerTimesTool t={t} />;
    default:
      return <GenericTool t={t} />;
  }
}