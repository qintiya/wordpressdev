import { ARTICLES, type Article } from "@/data/content";

export function Footer({
  t,
  go,
  onOpen,
}: {
  t: (k: string) => string;
  go: (s: string) => void;
  onOpen: (a: Article) => void;
}) {
  const quick = [
    { label: t("prayerTimes"), id: "tools" },
    { label: "99 Names of Allah", id: "tools" },
    { label: t("mosqueFinder"), id: "tools" },
    { label: t("qibla"), id: "tools" },
    { label: t("quran"), id: "tools" },
    { label: t("zakat"), id: "tools" },
    { label: t("ramadan"), id: "tools" },
  ];

  const popular = [...ARTICLES].sort((a, b) => b.views - a.views).slice(0, 5);

  return (
    <footer className="mt-12 border-t border-emerald-900/20 bg-gradient-to-b from-emerald-950 to-emerald-900 text-emerald-100">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-amber-400 font-serif text-xl font-bold text-emerald-950">
              ﷲ
            </span>
            <span className="font-serif text-lg font-bold text-amber-50">ALHIKMAH</span>
          </div>
          <p className="mt-3 max-w-md text-sm text-emerald-200/80">
            A trusted Islamic digital platform providing high-quality content on Islamic education,
            history, social issues, and culture — across web, Android, and iOS.
          </p>
          <p className="mt-4 text-sm text-emerald-300/70">
            Made with ❤️ for the ALHIKMAH
          </p>
        </div>

        <div>
          <h3 className="font-serif text-base font-bold text-amber-200">{t("quickLinks")}</h3>
          <ul className="mt-3 space-y-2 text-sm">
            {quick.map((l) => (
              <li key={l.label}>
                <button
                  onClick={() => go(l.id)}
                  className="text-emerald-200/80 transition-colors hover:text-amber-200"
                >
                  {l.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-serif text-base font-bold text-amber-200">{t("popularPosts")}</h3>
          <ul className="mt-3 space-y-2 text-sm">
            {popular.map((a) => (
              <li key={a.id}>
                <button
                  onClick={() => onOpen(a)}
                  className="line-clamp-2 text-left text-emerald-200/80 transition-colors hover:text-amber-200"
                >
                  {a.title}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-emerald-800/50">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-6 text-xs text-emerald-300/70 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p>© {new Date().getFullYear()} ALHIKMAH — Islamic Digital Platform</p>
          <div className="flex flex-wrap gap-4">
            <button onClick={() => go("about")} className="transition-colors hover:text-amber-200">
              {t("privacy")}
            </button>
            <button onClick={() => go("about")} className="transition-colors hover:text-amber-200">
              {t("terms")}
            </button>
            <button onClick={() => go("about")} className="transition-colors hover:text-amber-200">
              {t("aboutUs")}
            </button>
            <button onClick={() => go("contact")} className="transition-colors hover:text-amber-200">
              {t("contactUs")}
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}