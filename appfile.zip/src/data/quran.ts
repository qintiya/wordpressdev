export interface Surah {
  number: number;
  name: string;        // Nama latin
  arabic: string;      // Nama Arab
  meaning: string;     // Arti
  ayahs: number;       // Jumlah ayat
  revelation: "Makkiyah" | "Madaniyah";
}

// Data lengkap 114 surah Al-Quran
export const SURAHS: Surah[] = [
  { number: 1, name: "Al-Fatihah", arabic: "الفاتحة", meaning: "Pembukaan", ayahs: 7, revelation: "Makkiyah" },
  { number: 2, name: "Al-Baqarah", arabic: "البقرة", meaning: "Sapi Betina", ayahs: 286, revelation: "Madaniyah" },
  { number: 3, name: "Ali 'Imran", arabic: "آل عمران", meaning: "Keluarga Imran", ayahs: 200, revelation: "Madaniyah" },
  { number: 4, name: "An-Nisa'", arabic: "النساء", meaning: "Perempuan", ayahs: 176, revelation: "Madaniyah" },
  { number: 5, name: "Al-Ma'idah", arabic: "المائدة", meaning: "Jamuan Hidangan", ayahs: 120, revelation: "Madaniyah" },
  { number: 6, name: "Al-An'am", arabic: "الأنعام", meaning: "Binatang Ternak", ayahs: 165, revelation: "Makkiyah" },
  { number: 7, name: "Al-A'raf", arabic: "الأعراف", meaning: "Tempat Tertinggi", ayahs: 206, revelation: "Makkiyah" },
  { number: 8, name: "Al-Anfal", arabic: "الأنفال", meaning: "Harta Rampasan Perang", ayahs: 75, revelation: "Madaniyah" },
  { number: 9, name: "At-Taubah", arabic: "التوبة", meaning: "Pengampunan", ayahs: 129, revelation: "Madaniyah" },
  { number: 10, name: "Yunus", arabic: "يونس", meaning: "Nabi Yunus", ayahs: 109, revelation: "Makkiyah" },
  { number: 11, name: "Hud", arabic: "هود", meaning: "Nabi Hud", ayahs: 123, revelation: "Makkiyah" },
  { number: 12, name: "Yusuf", arabic: "يوسف", meaning: "Nabi Yusuf", ayahs: 111, revelation: "Makkiyah" },
  { number: 13, name: "Ar-Ra'd", arabic: "الرعد", meaning: "Guruh", ayahs: 43, revelation: "Madaniyah" },
  { number: 14, name: "Ibrahim", arabic: "إبراهيم", meaning: "Nabi Ibrahim", ayahs: 52, revelation: "Makkiyah" },
  { number: 15, name: "Al-Hijr", arabic: "الحجر", meaning: "Bukit Berbatu", ayahs: 99, revelation: "Makkiyah" },
  { number: 16, name: "An-Nahl", arabic: "النحل", meaning: "Lebah", ayahs: 128, revelation: "Makkiyah" },
  { number: 17, name: "Al-Isra'", arabic: "الإسراء", meaning: "Perjalanan Malam", ayahs: 111, revelation: "Makkiyah" },
  { number: 18, name: "Al-Kahf", arabic: "الكهف", meaning: "Gua", ayahs: 110, revelation: "Makkiyah" },
  { number: 19, name: "Maryam", arabic: "مريم", meaning: "Maryam", ayahs: 98, revelation: "Makkiyah" },
  { number: 20, name: "Taha", arabic: "طه", meaning: "Ta Ha", ayahs: 135, revelation: "Makkiyah" },
  { number: 21, name: "Al-Anbiya'", arabic: "الأنبياء", meaning: "Para Nabi", ayahs: 112, revelation: "Makkiyah" },
  { number: 22, name: "Al-Hajj", arabic: "الحج", meaning: "Haji", ayahs: 78, revelation: "Madaniyah" },
  { number: 23, name: "Al-Mu'minun", arabic: "المؤمنون", meaning: "Orang-orang Mukmin", ayahs: 118, revelation: "Makkiyah" },
  { number: 24, name: "An-Nur", arabic: "النور", meaning: "Cahaya", ayahs: 64, revelation: "Madaniyah" },
  { number: 25, name: "Al-Furqan", arabic: "الفرقان", meaning: "Pembeda", ayahs: 77, revelation: "Makkiyah" },
  { number: 26, name: "Asy-Syu'ara'", arabic: "الشعراء", meaning: "Para Penyair", ayahs: 227, revelation: "Makkiyah" },
  { number: 27, name: "An-Naml", arabic: "النمل", meaning: "Semut", ayahs: 93, revelation: "Makkiyah" },
  { number: 28, name: "Al-Qasas", arabic: "القصص", meaning: "Kisah-kisah", ayahs: 88, revelation: "Makkiyah" },
  { number: 29, name: "Al-'Ankabut", arabic: "العنكبوت", meaning: "Laba-laba", ayahs: 69, revelation: "Makkiyah" },
  { number: 30, name: "Ar-Rum", arabic: "الروم", meaning: "Bangsa Romawi", ayahs: 60, revelation: "Makkiyah" },
  { number: 31, name: "Luqman", arabic: "لقمان", meaning: "Luqman", ayahs: 34, revelation: "Makkiyah" },
  { number: 32, name: "As-Sajdah", arabic: "السجدة", meaning: "Sujud", ayahs: 30, revelation: "Makkiyah" },
  { number: 33, name: "Al-Ahzab", arabic: "الأحزاب", meaning: "Golongan Bersekutu", ayahs: 73, revelation: "Madaniyah" },
  { number: 34, name: "Saba'", arabic: "سبأ", meaning: "Kaum Saba'", ayahs: 54, revelation: "Makkiyah" },
  { number: 35, name: "Fatir", arabic: "فاطر", meaning: "Pencipta", ayahs: 45, revelation: "Makkiyah" },
  { number: 36, name: "Yasin", arabic: "يس", meaning: "Ya Sin", ayahs: 83, revelation: "Makkiyah" },
  { number: 37, name: "As-Saffat", arabic: "الصافات", meaning: "Barisan-barisan", ayahs: 182, revelation: "Makkiyah" },
  { number: 38, name: "Sad", arabic: "ص", meaning: "Sad", ayahs: 88, revelation: "Makkiyah" },
  { number: 39, name: "Az-Zumar", arabic: "الزمر", meaning: "Rombongan", ayahs: 75, revelation: "Makkiyah" },
  { number: 40, name: "Gafir", arabic: "غافر", meaning: "Yang Mengampuni", ayahs: 85, revelation: "Makkiyah" },
  { number: 41, name: "Fussilat", arabic: "فصلت", meaning: "Yang Dijelaskan", ayahs: 54, revelation: "Makkiyah" },
  { number: 42, name: "Asy-Syura", arabic: "الشورى", meaning: "Musyawarah", ayahs: 53, revelation: "Makkiyah" },
  { number: 43, name: "Az-Zukhruf", arabic: "الزخرف", meaning: "Perhiasan", ayahs: 89, revelation: "Makkiyah" },
  { number: 44, name: "Ad-Dukhan", arabic: "الدخان", meaning: "Kabut", ayahs: 59, revelation: "Makkiyah" },
  { number: 45, name: "Al-Jasiyah", arabic: "الجاثية", meaning: "Yang Berlutut", ayahs: 37, revelation: "Makkiyah" },
  { number: 46, name: "Al-Ahqaf", arabic: "الأحقاف", meaning: "Bukit-bukit Pasir", ayahs: 35, revelation: "Makkiyah" },
  { number: 47, name: "Muhammad", arabic: "محمد", meaning: "Nabi Muhammad", ayahs: 38, revelation: "Madaniyah" },
  { number: 48, name: "Al-Fath", arabic: "الفتح", meaning: "Kemenangan", ayahs: 29, revelation: "Madaniyah" },
  { number: 49, name: "Al-Hujurat", arabic: "الحجرات", meaning: "Kamar-kamar", ayahs: 18, revelation: "Madaniyah" },
  { number: 50, name: "Qaf", arabic: "ق", meaning: "Qaf", ayahs: 45, revelation: "Makkiyah" },
  { number: 51, name: "Az-Zariyat", arabic: "الذاريات", meaning: "Angin yang Menerbangkan", ayahs: 60, revelation: "Makkiyah" },
  { number: 52, name: "At-Tur", arabic: "الطور", meaning: "Bukit Tursina", ayahs: 49, revelation: "Makkiyah" },
  { number: 53, name: "An-Najm", arabic: "النجم", meaning: "Bintang", ayahs: 62, revelation: "Makkiyah" },
  { number: 54, name: "Al-Qamar", arabic: "القمر", meaning: "Bulan", ayahs: 55, revelation: "Makkiyah" },
  { number: 55, name: "Ar-Rahman", arabic: "الرحمن", meaning: "Yang Maha Pemurah", ayahs: 78, revelation: "Madaniyah" },
  { number: 56, name: "Al-Waqi'ah", arabic: "الواقعة", meaning: "Hari Kiamat", ayahs: 96, revelation: "Makkiyah" },
  { number: 57, name: "Al-Hadid", arabic: "الحديد", meaning: "Besi", ayahs: 29, revelation: "Madaniyah" },
  { number: 58, name: "Al-Mujadilah", arabic: "المجادلة", meaning: "Wanita yang Menggugat", ayahs: 22, revelation: "Madaniyah" },
  { number: 59, name: "Al-Hasyr", arabic: "الحشر", meaning: "Pengusiran", ayahs: 24, revelation: "Madaniyah" },
  { number: 60, name: "Al-Mumtahanah", arabic: "الممتحنة", meaning: "Wanita yang Diuji", ayahs: 13, revelation: "Madaniyah" },
  { number: 61, name: "As-Saff", arabic: "الصف", meaning: "Barisan", ayahs: 14, revelation: "Madaniyah" },
  { number: 62, name: "Al-Jumu'ah", arabic: "الجمعة", meaning: "Hari Jumat", ayahs: 11, revelation: "Madaniyah" },
  { number: 63, name: "Al-Munafiqun", arabic: "المنافقون", meaning: "Orang Munafik", ayahs: 11, revelation: "Madaniyah" },
  { number: 64, name: "At-Tagabun", arabic: "التغابن", meaning: "Hari Ditampakkan Kesalahan", ayahs: 18, revelation: "Madaniyah" },
  { number: 65, name: "At-Talaq", arabic: "الطلاق", meaning: "Talak", ayahs: 12, revelation: "Madaniyah" },
  { number: 66, name: "At-Tahrim", arabic: "التحريم", meaning: "Pengharaman", ayahs: 12, revelation: "Madaniyah" },
  { number: 67, name: "Al-Mulk", arabic: "الملك", meaning: "Kerajaan", ayahs: 30, revelation: "Makkiyah" },
  { number: 68, name: "Al-Qalam", arabic: "القلم", meaning: "Pena", ayahs: 52, revelation: "Makkiyah" },
  { number: 69, name: "Al-Haqqah", arabic: "الحاقة", meaning: "Hari Kiamat", ayahs: 52, revelation: "Makkiyah" },
  { number: 70, name: "Al-Ma'arij", arabic: "المعارج", meaning: "Tempat Naik", ayahs: 44, revelation: "Makkiyah" },
  { number: 71, name: "Nuh", arabic: "نوح", meaning: "Nabi Nuh", ayahs: 28, revelation: "Makkiyah" },
  { number: 72, name: "Al-Jinn", arabic: "الجن", meaning: "Jin", ayahs: 28, revelation: "Makkiyah" },
  { number: 73, name: "Al-Muzzammil", arabic: "المزمل", meaning: "Orang Berselimut", ayahs: 20, revelation: "Makkiyah" },
  { number: 74, name: "Al-Muddassir", arabic: "المدثر", meaning: "Orang Berkemul", ayahs: 56, revelation: "Makkiyah" },
  { number: 75, name: "Al-Qiyamah", arabic: "القيامة", meaning: "Hari Kiamat", ayahs: 40, revelation: "Makkiyah" },
  { number: 76, name: "Al-Insan", arabic: "الإنسان", meaning: "Manusia", ayahs: 31, revelation: "Madaniyah" },
  { number: 77, name: "Al-Mursalat", arabic: "المرسلات", meaning: "Malaikat yang Diutus", ayahs: 50, revelation: "Makkiyah" },
  { number: 78, name: "An-Naba'", arabic: "النبأ", meaning: "Berita Besar", ayahs: 40, revelation: "Makkiyah" },
  { number: 79, name: "An-Nazi'at", arabic: "النازعات", meaning: "Malaikat Pencabut Nyawa", ayahs: 46, revelation: "Makkiyah" },
  { number: 80, name: "'Abasa", arabic: "عبس", meaning: "Bermuka Masam", ayahs: 42, revelation: "Makkiyah" },
  { number: 81, name: "At-Takwir", arabic: "التكوير", meaning: "Menggulung", ayahs: 29, revelation: "Makkiyah" },
  { number: 82, name: "Al-Infitar", arabic: "الإنفطار", meaning: "Terbelah", ayahs: 19, revelation: "Makkiyah" },
  { number: 83, name: "Al-Mutaffifin", arabic: "المطففين", meaning: "Orang yang Curang", ayahs: 36, revelation: "Makkiyah" },
  { number: 84, name: "Al-Insyiqaq", arabic: "الإنشقاق", meaning: "Terbelah", ayahs: 25, revelation: "Makkiyah" },
  { number: 85, name: "Al-Buruj", arabic: "البروج", meaning: "Gugusan Bintang", ayahs: 22, revelation: "Makkiyah" },
  { number: 86, name: "At-Tariq", arabic: "الطارق", meaning: "Yang Datang di Malam Hari", ayahs: 17, revelation: "Makkiyah" },
  { number: 87, name: "Al-A'la", arabic: "الأعلى", meaning: "Yang Maha Tinggi", ayahs: 19, revelation: "Makkiyah" },
  { number: 88, name: "Al-Gasyiyah", arabic: "الغاشية", meaning: "Hari Kiamat", ayahs: 26, revelation: "Makkiyah" },
  { number: 89, name: "Al-Fajr", arabic: "الفجر", meaning: "Fajar", ayahs: 30, revelation: "Makkiyah" },
  { number: 90, name: "Al-Balad", arabic: "البلد", meaning: "Negeri", ayahs: 20, revelation: "Makkiyah" },
  { number: 91, name: "Asy-Syams", arabic: "الشمس", meaning: "Matahari", ayahs: 15, revelation: "Makkiyah" },
  { number: 92, name: "Al-Lail", arabic: "الليل", meaning: "Malam", ayahs: 21, revelation: "Makkiyah" },
  { number: 93, name: "Ad-Duha", arabic: "الضحى", meaning: "Waktu Duha", ayahs: 11, revelation: "Makkiyah" },
  { number: 94, name: "Asy-Syarh", arabic: "الشرح", meaning: "Melapangkan", ayahs: 8, revelation: "Makkiyah" },
  { number: 95, name: "At-Tin", arabic: "التين", meaning: "Buah Tin", ayahs: 8, revelation: "Makkiyah" },
  { number: 96, name: "Al-'Alaq", arabic: "العلق", meaning: "Segumpal Darah", ayahs: 19, revelation: "Makkiyah" },
  { number: 97, name: "Al-Qadr", arabic: "القدر", meaning: "Kemuliaan", ayahs: 5, revelation: "Makkiyah" },
  { number: 98, name: "Al-Bayyinah", arabic: "البينة", meaning: "Bukti Nyata", ayahs: 8, revelation: "Madaniyah" },
  { number: 99, name: "Az-Zalzalah", arabic: "الزلزلة", meaning: "Kegoncangan", ayahs: 8, revelation: "Madaniyah" },
  { number: 100, name: "Al-'Adiyat", arabic: "العاديات", meaning: "Kuda Perang", ayahs: 11, revelation: "Makkiyah" },
  { number: 101, name: "Al-Qari'ah", arabic: "القارعة", meaning: "Hari Kiamat", ayahs: 11, revelation: "Makkiyah" },
  { number: 102, name: "At-Takasur", arabic: "التكاثر", meaning: "Bermegah-megahan", ayahs: 8, revelation: "Makkiyah" },
  { number: 103, name: "Al-'Asr", arabic: "العصر", meaning: "Waktu Asar", ayahs: 3, revelation: "Makkiyah" },
  { number: 104, name: "Al-Humazah", arabic: "الهمزة", meaning: "Pengumpat", ayahs: 9, revelation: "Makkiyah" },
  { number: 105, name: "Al-Fil", arabic: "الفيل", meaning: "Gajah", ayahs: 5, revelation: "Makkiyah" },
  { number: 106, name: "Quraisy", arabic: "قريش", meaning: "Suku Quraisy", ayahs: 4, revelation: "Makkiyah" },
  { number: 107, name: "Al-Ma'un", arabic: "الماعون", meaning: "Barang Berguna", ayahs: 7, revelation: "Makkiyah" },
  { number: 108, name: "Al-Kausar", arabic: "الكوثر", meaning: "Nikmat yang Banyak", ayahs: 3, revelation: "Makkiyah" },
  { number: 109, name: "Al-Kafirun", arabic: "الكافرون", meaning: "Orang Kafir", ayahs: 6, revelation: "Makkiyah" },
  { number: 110, name: "An-Nasr", arabic: "النصر", meaning: "Pertolongan", ayahs: 3, revelation: "Madaniyah" },
  { number: 111, name: "Al-Lahab", arabic: "المسد", meaning: "Gejolak Api", ayahs: 5, revelation: "Makkiyah" },
  { number: 112, name: "Al-Ikhlas", arabic: "الإخلاص", meaning: "Ketulusan", ayahs: 4, revelation: "Makkiyah" },
  { number: 113, name: "Al-Falaq", arabic: "الفلق", meaning: "Waktu Subuh", ayahs: 5, revelation: "Makkiyah" },
  { number: 114, name: "An-Nas", arabic: "الناس", meaning: "Manusia", ayahs: 6, revelation: "Makkiyah" },
];

// Daftar qari murottal yang tersedia
export const RECITERS = [
  { id: "Alafasy_128kbps", name: "Mishary Rashid Alafasy" },
  { id: "Abdul_Basit_Murattal_192kbps", name: "Abdul Basit (Murattal)" },
  { id: "Abdurrahmaan_As-Sudais_192kbps", name: "Abdurrahman As-Sudais" },
  { id: "Ghamadi_40kbps", name: "Saad Al-Ghamdi" },
  { id: "Husary_128kbps", name: "Mahmoud Khalil Al-Husary" },
  { id: "Minshawy_Murattal_128kbps", name: "Muhammad Al-Minshawi" },
  { id: "Yasser_Ad-Dussary_128kbps", name: "Yasser Ad-Dussary" },
];

// Helper: format nomor surah jadi 3 digit (001, 002, ... 114)
export function pad3(n: number): string {
  return String(n).padStart(3, "0");
}

// URL audio murottal per surah (full surah)
export function surahAudioUrl(surah: number, reciter: string): string {
  return `https://server8.mp3quran.net/${reciter}/${pad3(surah)}.mp3`;
}

// URL audio per ayat (untuk mode ayat-per-ayat)
export function ayahAudioUrl(surah: number, ayah: number, reciter: string): string {
  return `https://everyayah.com/data/${reciter}/${pad3(surah)}${pad3(ayah)}.mp3`;
}

// API untuk teks Arab + terjemahan (islamic.network / alquran.cloud)
export function surahTextApi(surah: number): string {
  return `https://api.alquran.cloud/v1/surah/${surah}/editions/quran-uthmani,en.asad,id.indonesian`;
}