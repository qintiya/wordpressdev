export type Article = {
  id: string;
  title: string;
  category: string;
  excerpt: string;
  author: string;
  date: string;
  readMin: number;
  views: number;
  sections: { heading: string; body: string[] }[];
  conclusion: string;
  faq: { q: string; a: string }[];
};

export type Tool = {
  id: string;
  name: string;
  desc: string;
  icon: string;
  group: string;
};

export const CATEGORIES = [
  { id: "aqidah", name: "Aqidah", count: 28 },
  { id: "fiqh", name: "Fiqh", count: 42 },
  { id: "tafsir", name: "Science of Interpretation", count: 31 },
  { id: "hadith", name: "Sunnah Insight", count: 26 },
  { id: "seerah", name: "The Story of Salihin", count: 24 },
  { id: "history", name: "Islamic History", count: 38 },
  { id: "tazkiyah", name: "Sufism", count: 19 },
  { id: "nahwu", name: "Nahwu", count: 22 },
  { id: "shorof", name: "Shorof", count: 18 },
  { id: "tajweed", name: "Tajweed and Tahsin", count: 21 },
  { id: "dua", name: "Collection of Prayers", count: 30 },
  { id: "santri", name: "Santri Articles", count: 27 },
  { id: "khutbah", name: "Friday Sermon", count: 16 },
  { id: "tutorial", name: "Tutorial", count: 25 },
  { id: "quranic", name: "Quranic Insight", count: 29 },
];

const mk = (
  id: string,
  title: string,
  category: string,
  excerpt: string,
  views: number
): Article => ({
  id,
  title,
  category,
  excerpt,
  author: "ALHIKMAH Editorial",
  date: "2025-02-14",
  readMin: 12,
  views,
  sections: [
    {
      heading: "Introduction",
      body: [
        "This article explores the topic in depth, drawing on authentic sources and established scholarship. It is written to be accessible to general readers while maintaining academic rigour.",
        "The discussion is structured to guide the reader from foundational concepts to practical application, with references to the Quran and Sunnah throughout.",
      ],
    },
    {
      heading: "Foundations",
      body: [
        "Understanding this subject requires familiarity with its foundational principles. These principles have been articulated by scholars across generations and remain relevant today.",
        "The Quran and Sunnah provide the primary framework, while the works of classical scholars offer detailed elaboration and practical guidance.",
      ],
    },
    {
      heading: "Practical Application",
      body: [
        "Knowledge without application is incomplete. This section outlines how the principles discussed can be applied in daily life, with attention to both individual and communal contexts.",
        "Practical steps are provided, along with common pitfalls to avoid and resources for further study.",
      ],
    },
    {
      heading: "Common Questions",
      body: [
        "Readers often raise questions about this topic. The most frequent are addressed in the FAQ section below, with concise answers grounded in authentic sources.",
      ],
    },
  ],
  conclusion:
    "This topic rewards careful study and sincere application. May Allah grant us beneficial knowledge and the ability to act upon it.",
  faq: [
    { q: "What is the primary source for this topic?", a: "The Quran and authentic Sunnah, supported by classical scholarship." },
    { q: "Is this suitable for beginners?", a: "Yes — the article is written to be accessible while remaining rigorous." },
    { q: "Where can I learn more?", a: "Explore the related articles and tools on ALHIKMAH." },
  ],
});

export const ARTICLES: Article[] = [
  mk("a1", "The Lost Islamic City Archaeologists Still Can't Explain", "Islamic History", "Beneath the desert sands lies a sprawling Islamic city that vanished for 1,000 years.", 18420),
  mk("a2", "The Quran Verse Scientists Refused to Believe", "Quranic Insight", "When researchers first read this verse, they dismissed it as impossible.", 22150),
  mk("a3", "The Companion Who Never Met the Prophet ﷺ", "The Story of Salihin", "He never saw the Prophet ﷺ, yet his contribution changed Islam forever.", 15980),
  mk("a4", "The Mosque That Was Built in Just Three Days", "Islamic History", "A community with almost nothing built a mosque in three days.", 12340),
  mk("a5", "The Manuscript That Rewrote Islamic History", "Islamic History", "A single manuscript, hidden for centuries, forced historians to rethink everything.", 9870),
  mk("a6", "The Dua That Changed a Life Overnight", "Collection of Prayers", "He had nothing left. Then he made one dua — and by morning, everything changed.", 26710),
  mk("a7", "The Scholar Who Refused the King's Gift", "Scholar", "A king offered him gold, land, and a palace. He refused it all.", 11250),
  mk("a8", "The Night the Mosque Filled With Light", "Sufism", "Witnesses described a light that filled the mosque from within.", 8760),
  mk("a9", "The Fasting Experiment That Shocked Doctors", "Fiqh", "When doctors studied Islamic fasting, they expected modest results.", 19840),
  mk("a10", "The Verse That Made a King Weep in Public", "Quranic Insight", "A powerful king broke down in tears when he heard a single verse.", 14320),
  mk("a11", "The Woman Who Taught the Greatest Scholars", "Scholar", "Her students became some of the most famous scholars in Islamic history.", 10560),
  mk("a12", "The Mystery of the Seven Sleepers", "Quranic Insight", "A group of young men slept for centuries and woke to a world they did not recognise.", 17290),
  mk("a13", "The Hadith That Seems to Describe Modern Technology", "Sunnah Insight", "A hadith recorded over 1,400 years ago describes events that sound strikingly modern.", 21030),
  mk("a14", "The City Where Muslims, Jews, and Christians Prayed Together", "Islamic History", "For centuries, this city was a model of coexistence.", 13480),
  mk("a15", "The Prayer That Was Answered 1,400 Years Later", "Collection of Prayers", "A dua made by a companion seemed to go unanswered for over a millennium.", 18920),
  mk("a16", "The Secret of the Prophet's ﷺ Daily Routine", "Sunnah Insight", "His routine was simple, disciplined, and remarkably effective.", 24310),
  mk("a17", "The Quran Chapter That Protects From Evil", "Quranic Insight", "Millions recite it every day. Few understand why it is so powerful.", 16740),
  mk("a18", "The Muslim Scientist Who Invented Modern Surgery", "Islamic History", "He wrote a medical encyclopedia that was used for 600 years.", 12180),
  mk("a19", "The Prophet Who Spoke to Animals", "Quranic Insight", "The Quran describes a prophet who understood the language of animals.", 15470),
  mk("a20", "The Hadith About the Stranger Who Knew Everything", "Sunnah Insight", "A man appeared from nowhere, asked three questions, and then vanished.", 13890),
  mk("a21", "The Muslim Empire That Invented the Modern University", "Islamic History", "Long before Oxford, Muslim scholars were building institutions of higher learning.", 11630),
  mk("a22", "The Dua That Opens the Doors of Provision", "Collection of Prayers", "It is short, easy to memorise, and recommended by scholars.", 20150),
  mk("a23", "The Mystery of the Disjointed Letters in the Quran", "Quranic Insight", "Some chapters begin with letters that seem to have no meaning.", 9420),
  mk("a24", "The Muslim Who Saved a Thousand Lives", "The Story of Salihin", "He risked everything to save people he had never met.", 10780),
  mk("a25", "The Hadith That Changed How Muslims Treat Animals", "Sunnah Insight", "A single hadith transformed the way Muslims think about animals.", 12960),
  mk("a26", "The Secret Meaning of the Basmala", "Quranic Insight", "Muslims recite it millions of times a day. Few understand its depth.", 17650),
  mk("a27", "The Muslim City That Had Street Lighting Before Europe", "Islamic History", "Centuries before European cities lit their streets, a Muslim city was illuminated.", 14120),
  mk("a28", "The Dua for Anxiety and Depression", "Collection of Prayers", "Anxiety and depression are among the greatest challenges of our time.", 28430),
  mk("a29", "The Hadith About 'The Best of You'", "Sunnah Insight", "It is one of the most quoted hadiths in Islam — and often misunderstood.", 19370),
  mk("a30", "The Quran Verse That Explains Why We Suffer", "Quranic Insight", "Suffering is one of the oldest questions in human history.", 23280),
];

export const TOOL_GROUPS = [
  "Worship & Daily Practice",
  "Finance & Obligations",
  "Calendar & Dates",
  "Hajj & Umrah",
  "Names & Text",
  "Food",
];

export const TOOLS: Tool[] = [
  { id: "prayertimes", name: "Prayer Times", desc: "The five daily prayer times", icon: "🕌", group: "Worship & Daily Practice" },
  { id: "tasbeeh", name: "Tasbeeh", desc: "Count your dhikr", icon: "📿", group: "Worship & Daily Practice" },
  { id: "qibla", name: "Qibla Finder", desc: "Find the direction of the Kaaba", icon: "🧭", group: "Worship & Daily Practice" },
  { id: "salahtracker", name: "Salah Tracker", desc: "Log your daily prayers", icon: "✅", group: "Worship & Daily Practice" },
  { id: "dua", name: "Dua Library", desc: "Duas for every occasion", icon: "🤲", group: "Worship & Daily Practice" },
  { id: "asmaulhusna", name: "99 Names of Allah", desc: "Learn the Asma ul-Husna", icon: "✨", group: "Worship & Daily Practice" },
  { id: "zakat", name: "Zakat", desc: "Calculate your 2.5% zakat", icon: "💰", group: "Finance & Obligations" },
  { id: "inheritance", name: "Inheritance Calculator", desc: "Islamic inheritance shares (Faraid)", icon: "📊", group: "Finance & Obligations" },
  { id: "sadaqah", name: "Sadaqah Tracker", desc: "Track your charity", icon: "❤️", group: "Finance & Obligations" },
  { id: "zakatfitr", name: "Zakat al-Fitr Calculator", desc: "Work out Zakat al-Fitr", icon: "🌾", group: "Finance & Obligations" },
  { id: "hajjsavings", name: "Hajj Savings Planner", desc: "Plan and save for Hajj", icon: "🏦", group: "Finance & Obligations" },
  { id: "hijri", name: "Hijri Date Converter", desc: "Convert Hijri and Gregorian dates", icon: "📅", group: "Calendar & Dates" },
  { id: "ramadan", name: "Ramadan Countdown", desc: "Countdown to Ramadan", icon: "🌙", group: "Calendar & Dates" },
  { id: "events", name: "Islamic Events Calendar", desc: "Key Islamic dates this year", icon: "🗓️", group: "Calendar & Dates" },
  { id: "agehijri", name: "Age in Hijri Calculator", desc: "Your age in the Hijri calendar", icon: "🎂", group: "Calendar & Dates" },
  { id: "fasting", name: "Ramadan Fasting Tracker", desc: "Track your Ramadan fasts", icon: "🍽️", group: "Calendar & Dates" },
  { id: "eid", name: "Eid Countdown", desc: "Countdown to Eid", icon: "🎉", group: "Calendar & Dates" },
  { id: "umrah", name: "Umrah Step-by-Step Guide", desc: "A guided walkthrough of Umrah", icon: "🕋", group: "Hajj & Umrah" },
  { id: "packing", name: "Hajj & Umrah Packing Checklist", desc: "Everything to pack for the journey", icon: "🧳", group: "Hajj & Umrah" },
  { id: "hajjcost", name: "Hajj Cost Estimator", desc: "Estimate the cost of Hajj", icon: "💵", group: "Hajj & Umrah" },
  { id: "names", name: "Islamic Name Finder", desc: "Find meaningful Muslim names", icon: "👶", group: "Names & Text" },
  { id: "arabictext", name: "Arabic Text Generator", desc: "Create calligraphic Arabic text", icon: "✒️", group: "Names & Text" },
  { id: "translit", name: "Transliteration Tool", desc: "Arabic to Roman transliteration", icon: "🔤", group: "Names & Text" },
  { id: "pegon", name: "Arabic Pegon Converter", desc: "Latin Transliteration ↔ Arabic Pegon", icon: "🔁", group: "Names & Text" },
  { id: "calligraphy", name: "Arabic Calligraphy", desc: "6 styles: Naskh, Tsuluts, Diwani, Kufi, Farisi, Riq'ah", icon: "🖋️", group: "Names & Text" },
  { id: "halalfood", name: "Halal Food Additive Checker", desc: "Check E-numbers and additives", icon: "🥗", group: "Food" },
  { id: "timer", name: "Timer & Stopwatch", desc: "For worship and study", icon: "⏱️", group: "Worship & Daily Practice" },
  { id: "quran", name: "Digital Quran", desc: "114 surahs with translations", icon: "📖", group: "Worship & Daily Practice" },
  { id: "murotal", name: "Murotal 30 Juz", desc: "Complete Al-Quran audio player", icon: "🎧", group: "Worship & Daily Practice" },
];

export const NEWS = [
  { title: "New Saudi Excavations Reveal Early Islamic Roots", date: "Feb 14, 2025" },
  { title: "Timbuktu Manuscript Project Releases New Documents", date: "Feb 12, 2025" },
  { title: "AI Reconstruction Brings Islamic Golden Age Cities to Life", date: "Feb 10, 2025" },
  { title: "Zamzam Well Study Published by Hydrogeologists", date: "Feb 8, 2025" },
];

export const ARCHIVE = [
  { label: "February 2025", count: 42 },
  { label: "January 2025", count: 38 },
  { label: "December 2024", count: 35 },
  { label: "November 2024", count: 29 },
  { label: "October 2024", count: 31 },
];

export const SURAHS = [
  { n: 1, name: "Al-Fatihah", ayah: 7 },
  { n: 2, name: "Al-Baqarah", ayah: 286 },
  { n: 18, name: "Al-Kahf", ayah: 110 },
  { n: 36, name: "Yasin", ayah: 83 },
  { n: 55, name: "Ar-Rahman", ayah: 78 },
  { n: 67, name: "Al-Mulk", ayah: 30 },
];

export const CALLIGRAPHY_STYLES = ["Naskh", "Tsuluts", "Diwani", "Kufi", "Farisi", "Riq'ah"];