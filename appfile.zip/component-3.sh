git init
git add .
git commit -m "Initial ALHIKMAH deploy"
git branch -M main
git remote add origin https://github.com/USERNAME/alhikmah.git
git push -u origin main