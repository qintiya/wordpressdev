(function($) {
    'use strict';

    var TransjtConnect = {
        $connectBtn: null,
        popup: null,
        popupCheckInterval: null,
        isConnecting: false,
        messageReceived: false,
        pendingRequestCode: null,

        init: function() {
            this.cacheElements();
            this.bindEvents();
        },

        cacheElements: function() {
            this.$connectBtn = $('#transjt-connect-btn');
        },

        bindEvents: function() {
            var self = this;

            this.$connectBtn.on('click', function(e) {
                e.preventDefault();
                self.startConnection();
            });

            window.addEventListener('message', function(event) {
                self.handlePostMessage(event);
            }, false);
        },

        startConnection: function() {
            if (this.isConnecting) {
                return;
            }

            this.isConnecting = true;
            this.messageReceived = false;
            this.$connectBtn.prop('disabled', true).text(transjtConnect.i18n.connecting);

            var self = this;
            $.ajax({
                url: transjtConnect.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'transjt_prepare_connection',
                    nonce: transjtConnect.nonce
                },
                success: function(response) {
                    if (response.success) {
                        self.pendingRequestCode = response.data.requestCode;
                        self.openConnectionPopup(response.data.appUrl);
                    } else {
                        self.handleError(response.data.message);
                        self.isConnecting = false;
                    }
                },
                error: function() {
                    self.handleError(transjtConnect.i18n.error);
                    self.resetButton();
                    self.isConnecting = false;
                }
            });
        },

        openConnectionPopup: function(appUrl) {
            var self = this;
            var width = 750;
            var height = 600;
            var left = (screen.width - width) / 2;
            var top = (screen.height - height) / 2;

            this.popup = window.open(
                appUrl,
                'transjt_connect',
                'width=' + width + ',height=' + height + ',left=' + left + ',top=' + top + ',scrollbars=yes,resizable=yes'
            );

            if (!this.popup || this.popup.closed) {
                this.handleError(transjtConnect.i18n.popupBlocked);
                this.isConnecting = false;
                return;
            }

            this.popup.focus();

            this.popupCheckInterval = setInterval(function() {
                if (!self.popup || self.popup.closed) {
                    self.handlePopupClosed();
                }
            }, 500);
        },

        handlePostMessage: function(event) {
            if (event.origin !== transjtConnect.allowedOrigin) {
                return;
            }

            var data = event.data;

            if (typeof data === 'object' && data.type) {
                // Mark that we received a valid message to prevent race condition
                this.messageReceived = true;
                this.clearPopupCheck();

                switch (data.type) {
                    case 'transjt_connection_success':
                        this.handleConnectionSuccess(data);
                        break;
                    case 'transjt_connection_error':
                        this.handleConnectionError(data);
                        break;
                    case 'transjt_connection_cancel':
                        this.closePopup();
                        break;
                }
            }
        },

        handleConnectionSuccess: function() {
            var self = this;

            this.closePopup();

            $.ajax({
                url: transjtConnect.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'transjt_exchange_token',
                    nonce: transjtConnect.nonce,
                    requestCode: this.pendingRequestCode || ''
                },
                success: function(response) {
                    if (response.success) {
                        window.location.reload();
                    } else {
                        self.handleError(response.data.message);
                    }
                },
                error: function() {
                    self.handleError(transjtConnect.i18n.error);
                }
            });
        },

        handleConnectionError: function(data) {
            this.closePopup();
            this.handleError(data.message || transjtConnect.i18n.error);
        },

        handlePopupClosed: function() {
            this.clearPopupCheck();

            // If we already received a postMessage, don't cancel - let the message handler deal with it
            if (this.messageReceived) {
                return;
            }

            this.resetButton();
            this.isConnecting = false;

            // Cancel pending connection on server
            $.ajax({
                url: transjtConnect.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'transjt_cancel_connection',
                    nonce: transjtConnect.nonce
                }
            });
        },

        closePopup: function() {
            this.clearPopupCheck();
            if (this.popup && !this.popup.closed) {
                this.popup.close();
            }
            this.popup = null;
            this.pendingRequestCode = null;
            this.resetButton();
            this.isConnecting = false;
        },

        clearPopupCheck: function() {
            if (this.popupCheckInterval) {
                clearInterval(this.popupCheckInterval);
                this.popupCheckInterval = null;
            }
        },

        resetButton: function() {
            this.$connectBtn.prop('disabled', false).text(transjtConnect.i18n.connectBtn);
        },

        handleError: function(message) {
            this.closePopup();

            var $notice = $('<div class="notice notice-error is-dismissible"><p>' +
                           this.escapeHtml(message) + '</p></div>');

            $('.wrap h1').first().after($notice);

            setTimeout(function() {
                $notice.fadeOut(function() {
                    $(this).remove();
                });
            }, 5000);
        },

        escapeHtml: function(text) {
            var div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    };

    $(document).ready(function() {
        TransjtConnect.init();
        TransjtPackages.init();
    });

    var TransjtPackages = {
        $section: null,
        // latest install report and name per package id, for the copy button
        reports: {},
        names: {},

        init: function() {
            this.$section = $('#transjt-packages-section');
            if (!this.$section.length) {
                return;
            }
            this.loadPackages();
        },

        loadPackages: function() {
            var self = this;

            $.ajax({
                url: transjtConnect.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'transjt_get_packages',
                    nonce: transjtConnect.packagesNonce
                },
                success: function(response) {
                    if (response.success) {
                        self.renderPackages(response.data.packages);
                    } else {
                        self.showError(response.data.message || transjtConnect.i18n.packagesError);
                    }
                },
                error: function() {
                    self.showError(transjtConnect.i18n.packagesError);
                }
            });
        },

        renderPackages: function(packages) {
            this.$section.find('.transjt-packages-loading').hide();

            if (!packages || packages.length === 0) {
                this.$section.find('.transjt-packages-table').hide();
                this.$section.find('.transjt-packages-empty').show();
                return;
            }

            var self = this;
            var $tbody = this.$section.find('.transjt-packages-list').empty();

            packages.forEach(function(pkg) {
                self.reports[pkg.id] = pkg.deploy_report || null;
                self.names[pkg.id] = pkg.name;

                var created_date = pkg.created_at ? self.parseUtcDate(pkg.created_at) : null;
                var created = created_date
                    ? '<span class="transjt-badge transjt-badge-not-installed" title="' + self.escapeAttr(self.formatDate(created_date)) + '">' + self.escapeHtml(transjtConnect.i18n.created) + ' ' + self.escapeHtml(self.relativeDate(created_date)) + '</span>'
                    : '';

                var installed_date = pkg.installed_at ? self.parseUtcDate(pkg.installed_at) : null;
                var installed = installed_date
                    ? '<span class="transjt-badge transjt-badge-installed" title="' + self.escapeAttr(self.formatDate(installed_date)) + '">' + self.escapeHtml(transjtConnect.i18n.installed) + ' ' + self.escapeHtml(self.relativeDate(installed_date)) + '</span>'
                    : '<span class="transjt-badge transjt-badge-not-installed">' + self.escapeHtml(transjtConnect.i18n.notInstalled) + '</span>';

                var previewHtml = pkg.previewUrl
                    ? '<img class="transjt-pkg-preview" src="' + self.escapeAttr(pkg.previewUrl) + '" alt="">'
                    : '';

                var componentsHtml = '';
                if (pkg.components && pkg.components.length) {
                    componentsHtml = '<ul class="transjt-component-list">';
                    pkg.components.forEach(function(cmp) {
                        var comp = cmp.component || {};
                        var isOk = comp.status === 'OK';
                        var code = isOk ? 'OK' : (comp.error || comp.status || '?');
                        var label = self.componentStatusLabel(code);
                        var iconClass = isOk ? 'dashicons-yes transjt-status-ok' : 'dashicons-no-alt transjt-status-error';
                        componentsHtml += '<li title="' + self.escapeAttr(label) + '"><span class="dashicons transjt-status-icon ' + iconClass + '"></span>' + self.escapeHtml(comp.name) + '</li>';
                    });
                    componentsHtml += '</ul>';
                }

                var $row = $('<tr>')
                    .attr('data-package-id', pkg.id)
                    .append($('<td class="transjt-pkg-preview-cell">').html(previewHtml))
                    .append($('<td>').html(
                        '<div class="transjt-pkg-name">' + self.escapeHtml(pkg.name) + '</div>' + componentsHtml
                    ))
                    .append($('<td>').html(
                        '<div class="transjt-pkg-dates">' + (created ? created : '') + '<span class="transjt-installed-badge">' + installed + '</span></div>' +
                        '<div class="transjt-pkg-actions">' +
                        '<button class="button ' + (installed_date ? 'button-secondary' : 'button-primary') + ' transjt-install-btn" data-package-id="' + self.escapeAttr(pkg.id) + '">' +
                        self.escapeHtml(installed_date ? transjtConnect.i18n.reinstallBtn : transjtConnect.i18n.installBtn) + '</button>' +
                        '<button class="button button-secondary transjt-delete-btn" data-package-id="' + self.escapeAttr(pkg.id) + '">' + self.escapeHtml(transjtConnect.i18n.deleteBtn) + '</button>' +
                        '</div>' +
                        '<div class="transjt-pkg-report">' + self.reportHtml(self.reports[pkg.id]) + '</div>' +
                        '<div class="transjt-install-notice"></div>'
                    ));

                $tbody.append($row);
            });

            this.$section.find('.transjt-packages-table').show();
            this.bindInstallButtons();
        },

        reportHtml: function(report) {
            if (!report) return '';
            var warning = '';
            if (report.status === 'FAILED') {
                warning = transjtConnect.i18n.installFailed;
            } else if ((report.images || []).some(function(image) { return image.status !== 'UPLOADED'; })) {
                warning = transjtConnect.i18n.imagesFailed;
            }
            return (warning ? '<span class="transjt-badge transjt-badge-error">' + this.escapeHtml(warning) + '</span>' : '') +
                '<button type="button" class="button-link transjt-copy-report-btn">' + this.escapeHtml(transjtConnect.i18n.copyReportBtn) + '</button>';
        },

        setReport: function(package_id, $row, report) {
            if (!report) return;
            this.reports[package_id] = report;
            $row.find('.transjt-pkg-report').html(this.reportHtml(report));
        },

        copyReport: function(package_id, $row) {
            var $notice = $row.find('.transjt-install-notice');
            var text = JSON.stringify({
                packageId: package_id,
                name: this.names[package_id],
                report: this.reports[package_id]
            }, null, 2);
            var done = function() { $notice.css('color', 'green').text(transjtConnect.i18n.reportCopied).show(); };
            var failed = function() { $notice.css('color', 'red').text(transjtConnect.i18n.reportCopyError).show(); };

            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(done, failed);
                return;
            }
            // the clipboard API needs https - plain http admin pages fall back to execCommand
            var $textarea = $('<textarea readonly>').val(text).css({ position: 'fixed', top: 0, left: 0, opacity: 0 }).appendTo('body');
            $textarea[0].select();
            var copied = false;
            try {
                copied = document.execCommand('copy');
            } catch (e) {}
            $textarea.remove();
            if (copied) {
                done();
            } else {
                failed();
            }
        },

        componentStatusLabel: function(code) {
            var labels = {
                'OK':                        'Success',
                'COMPONENT_NOT_LOADED':      'Component could not be loaded',
                'CONCURRENT_REQUESTS_LIMIT': 'Concurrent requests limit exceeded',
                'TOO_LARGE_INPUT':           'Too large input',
                'INSUFFICIENT_TOKEN_BALANCE':'Insufficient token balance',
                'ERROR_ARTEFACTS':           'Output format error',
                'BLOG_EXPORT_UNAVAILABLE':   'Upgrade for blog support',
                'CONFLICT':                  'Skipped'
            };
            return labels[code] || code;
        },

        parseUtcDate: function(str) {
            var s = str.replace(' ', 'T');
            if (!/Z|[+-]\d{2}:\d{2}$/.test(s)) s += 'Z';
            return new Date(s);
        },

        relativeDate: function(date) {
            var diff = Math.floor((new Date() - date) / 1000);
            if (diff < 60)     return 'just now';
            if (diff < 3600)   { var m = Math.floor(diff / 60);    return m === 1 ? 'a minute ago'  : m + ' minutes ago'; }
            if (diff < 86400)  { var h = Math.floor(diff / 3600);  return h === 1 ? 'an hour ago'   : h + ' hours ago'; }
            if (diff < 172800) return 'yesterday';
            if (diff < 604800) { var d = Math.floor(diff / 86400); return d + ' days ago'; }
            if (diff < 2592000){ var w = Math.floor(diff / 604800);  return w === 1 ? 'last week'  : w + ' weeks ago'; }
            if (diff < 31536000){ var mo = Math.floor(diff / 2592000); return mo === 1 ? 'last month' : mo + ' months ago'; }
            var y = Math.floor(diff / 31536000);
            return y === 1 ? 'last year' : y + ' years ago';
        },

        formatDate: function(date) {
            var p = function(n) { return n < 10 ? '0' + n : '' + n; };
            return p(date.getDate()) + '.' + p(date.getMonth() + 1) + '.' + date.getFullYear() +
                ' ' + p(date.getHours()) + ':' + p(date.getMinutes()) + ':' + p(date.getSeconds());
        },

        bindInstallButtons: function() {
            var self = this;
            this.$section.off('click', '.transjt-install-btn').on('click', '.transjt-install-btn', function() {
                var $btn = $(this);
                if (!confirm(transjtConnect.i18n.installConfirm)) return;
                self.installPackage($btn.data('package-id'), $btn);
            });
            this.$section.off('click', '.transjt-delete-btn').on('click', '.transjt-delete-btn', function() {
                var $btn = $(this);
                if (!confirm(transjtConnect.i18n.deleteConfirm)) return;
                self.deletePackage($btn.data('package-id'), $btn);
            });
            this.$section.off('click', '.transjt-copy-report-btn').on('click', '.transjt-copy-report-btn', function() {
                var $row = $(this).closest('tr');
                self.copyReport($row.attr('data-package-id'), $row);
            });
        },

        installPackage: function(package_id, $btn) {
            var self = this;
            var $notice = $btn.closest('td').find('.transjt-install-notice');

            $btn.prop('disabled', true).text(transjtConnect.i18n.installing);
            $notice.hide().text('');

            $.ajax({
                url: transjtConnect.ajaxUrl,
                type: 'POST',
                timeout: 120000,
                data: {
                    action: 'transjt_install_package',
                    nonce: transjtConnect.packagesNonce,
                    package_id: package_id
                },
                success: function(response) {
                    self.setReport(package_id, $btn.closest('tr'), response.data && response.data.report);
                    if (response.success) {
                        $btn.removeClass('button-primary').addClass('button-secondary')
                            .text(transjtConnect.i18n.reinstallBtn).prop('disabled', false);
                        $notice.css('color', 'green').text(transjtConnect.i18n.installSuccess).show();
                        var now = new Date();
                        $btn.closest('tr').find('.transjt-installed-badge').html(
                            '<span class="transjt-badge transjt-badge-installed" title="' + self.escapeAttr(self.formatDate(now)) + '">' + self.escapeHtml(transjtConnect.i18n.installed) + ' ' + self.escapeHtml(self.relativeDate(now)) + '</span>'
                        );
                    } else {
                        $btn.text(transjtConnect.i18n.installBtn).prop('disabled', false);
                        $notice.css('color', 'red').text(response.data.message || transjtConnect.i18n.error).show();
                    }
                },
                error: function() {
                    $btn.text(transjtConnect.i18n.installBtn).prop('disabled', false);
                    $notice.css('color', 'red').text(transjtConnect.i18n.error).show();
                }
            });
        },

        deletePackage: function(package_id, $btn) {
            var self = this;
            var $notice = $btn.closest('td').find('.transjt-install-notice');

            $btn.prop('disabled', true).text(transjtConnect.i18n.deleting);
            $btn.siblings('.transjt-install-btn').prop('disabled', true);
            $notice.hide().text('');

            $.ajax({
                url: transjtConnect.ajaxUrl,
                type: 'POST',
                timeout: 30000,
                data: {
                    action: 'transjt_delete_package',
                    nonce: transjtConnect.packagesNonce,
                    package_id: package_id
                },
                success: function(response) {
                    if (response.success) {
                        self.loadPackages();
                    } else {
                        $btn.text(transjtConnect.i18n.deleteBtn).prop('disabled', false);
                        $btn.siblings('.transjt-install-btn').prop('disabled', false);
                        $notice.css('color', 'red').text(response.data.message || transjtConnect.i18n.error).show();
                    }
                },
                error: function() {
                    $btn.text(transjtConnect.i18n.deleteBtn).prop('disabled', false);
                    $btn.siblings('.transjt-install-btn').prop('disabled', false);
                    $notice.css('color', 'red').text(transjtConnect.i18n.error).show();
                }
            });
        },

        showError: function(message) {
            this.$section.find('.transjt-packages-loading').hide();
            this.$section.find('.transjt-packages-error').text(message).show();
        },

        escapeHtml: function(text) {
            var div = document.createElement('div');
            div.textContent = String(text);
            return div.innerHTML;
        },

        escapeAttr: function(value) {
            return String(value).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        }
    };

})(jQuery);
