<?php
namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

class Helper {
    public static function sanitize_path($path) {
        return ltrim($path, '/');
    }

    /**
     * resolve ../ sequences without requiring the path to exist on disk
     */
    public static function normalize_path($path) {
        $parts = explode('/', str_replace('\\', '/', $path));
        $resolved = [];
        foreach ($parts as $part) {
            if ($part === '..') {
                array_pop($resolved);
            } elseif ($part !== '.' && $part !== '') {
                $resolved[] = $part;
            }
        }
        return '/' . implode('/', $resolved);
    }

    /**
     * absolute path of a theme-relative path, or null when it could lead outside the theme directory
     */
    public static function theme_path($theme_dir, $rel_path) {
        if (!is_string($rel_path) || $rel_path === '' || $rel_path[0] === '/' || strpbrk($rel_path, "\\\0") !== false || in_array('..', explode('/', $rel_path), true)) {
            return null;
        }
        $path = rtrim($theme_dir, '/') . '/' . $rel_path;
        // a symlink inside the theme can still point outside it: resolve the nearest part that exists
        $existing = $path;
        while (!file_exists($existing)) {
            $existing = dirname($existing);
        }
        $real_dir = realpath($theme_dir);
        $real = realpath($existing);
        if ($real_dir === false || $real === false || ($real !== $real_dir && strpos($real, $real_dir . '/') !== 0)) {
            return null;
        }
        return $path;
    }

    public static function get_extension_from_mime($mime_type) {
        $mime_map = [
            'image/jpeg' => 'jpg',
            'image/jpg'  => 'jpg',
            'image/png'  => 'png',
            'image/gif'  => 'gif',
            'image/webp' => 'webp',
            'image/svg+xml' => 'svg',
            'application/pdf' => 'pdf',
            'video/mp4'  => 'mp4',
            'video/webm' => 'webm',
            'audio/mpeg' => 'mp3',
            'audio/ogg'  => 'ogg',
        ];
        
        return $mime_map[$mime_type] ?? null;
    }
    
    public static function generate_secure_key($length = 64) {
        return wp_generate_password($length, false);
    }
    
    public static function set_notice($type, $message, $expiration = 30) {
        set_transient('transjt_admin_notice', [
            'type' => $type,
            'message' => $message
        ], $expiration);
    }
    
    /**
     * get and delete admin notice transient
     */
    public static function get_notice() {
        $notice = get_transient('transjt_admin_notice');
        if ($notice) {
            delete_transient('transjt_admin_notice');
        }
        return $notice;
    }

    public static function sanitize_svg_content(string $content) {
        $sanitizer = new \Transjt\SvgSanitize\Sanitizer();
        $sanitizer->removeRemoteReferences(true);
        $clean = $sanitizer->sanitize($content);
        if ($clean === false || $clean === '') {
            return new \WP_Error('svg_error', __('Invalid SVG: sanitization failed', 'transjt-ai'));
        }
        return $clean;
    }

    public static function parse_header(string $file_path, array $headers){
        $file_content = file_get_contents($file_path, false, null, 0, 1024);
        $result = [];
        foreach ($headers as $key => $header) {
            if (preg_match('/^\s*\*\s*' . preg_quote($header, '/') . ':\s*(.+)$/mi', $file_content, $matches)) {
                $result[$key] = trim($matches[1]);
            }
        }
        return $result;
    }

    /**
     * scan blocks directory and call ensure_default_form() on each block that declares a CF7 class
     */
    public static function run_cf7_setup(string $theme_dir) {
        $blocks_base = realpath($theme_dir . '/blocks');
        $block_dirs  = $blocks_base ? (glob($blocks_base . '/*', GLOB_ONLYDIR) ?: []) : [];

        foreach ($block_dirs as $block_dir) {
            $cf7_path      = $block_dir . '/cf7.php';
            $real_cf7_path = realpath($cf7_path);
            if (!$real_cf7_path || strpos($real_cf7_path, $blocks_base . DIRECTORY_SEPARATOR) !== 0) {
                continue;
            }
            $cf7_class = self::parse_header($real_cf7_path, [
                'class_name' => 'Class Name'
            ])['class_name'] ?? null;
            // themes generated without the "Class Name" header would otherwise be skipped
            // silently and ship with no forms - fall back to the class the file declares
            if (!$cf7_class) {
                $cf7_source = file_get_contents($real_cf7_path);
                if (preg_match('/^\s*(?:final\s+)?class\s+([A-Za-z_][A-Za-z0-9_]*)\s+extends\s+CF7_Block_Integration\b/mi', $cf7_source, $matches)) {
                    $cf7_class = $matches[1];
                }
            }
            if (!$cf7_class || !preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $cf7_class)) {
                continue;
            }
            // phpcs:ignore WordPress.Security.EvalBase -- path constrained by realpath() to $blocks_base; filename validated by regex above
            require_once $real_cf7_path;
            if (class_exists($cf7_class) && method_exists($cf7_class, 'ensure_default_form')) {
                $cf7_class::ensure_default_form();
            }
        }
    }

}