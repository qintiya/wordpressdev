<?php
namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

class AssetHandler {
    const PROJECT_META_KEY = '_transjt_project';
    // md5 of the bytes a bundled theme image was uploaded from
    const MD5_META_KEY = '_transjt_asset_md5';
    private $logger;

    public function __construct(?Logger $logger = null) {
        $this->logger = $logger;
    }

    public function handle_upload($request) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        $url = $request->get_param('url');
        $project = $request->get_param('project');
        $custom_filename = $request->get_param('filename');
        $overwrite_param = $request->get_param('overwrite');
        $overwrite = $overwrite_param === null || filter_var($overwrite_param, FILTER_VALIDATE_BOOLEAN); // default true

        if (!$url) {
            return new \WP_Error('rest_error', __('Invalid request: url required', 'transjt-ai'), ['status' => 400]);
        }

        if (!$project) {
            return new \WP_Error('rest_error', __('Invalid request: project required', 'transjt-ai'), ['status' => 400]);
        }

        // enforce allowed-domains whitelist (SSRF prevention)
        $host = wp_parse_url($url, PHP_URL_HOST);
        $allowed = defined('TRANSJT_ALLOWED_DOMAINS') && TRANSJT_ALLOWED_DOMAINS
            ? array_map('trim', explode(',', TRANSJT_ALLOWED_DOMAINS))
            : [];
        if (empty($allowed) || !in_array($host, $allowed, true)) {
            return new \WP_Error('disallowed_domain', __('URL domain is not allowed', 'transjt-ai'), ['status' => 403]);
        }

        // download file to temp location
        $tmp = download_url($url, 30);
        if (is_wp_error($tmp)) {
            return $tmp;
        }

        // use provided filename or extract from URL
        if ($custom_filename) {
            $filename = sanitize_file_name($custom_filename);
        } else {
            $filename = basename(wp_parse_url($url, PHP_URL_PATH));
        }

        // add extension if missing
        if (!pathinfo($filename, PATHINFO_EXTENSION)) {
            $extension = $this->detect_extension_from_url($url);
            if ($extension) {
                $filename .= '.' . $extension;
            }
        }

        return $this->sideload_to_media_library($tmp, $filename, $project, $overwrite);
    }

    /**
     * sideload a file already sitting on local disk (e.g. bundled inside an installed theme package)
     * into the WordPress media library. Used to resolve deploy.json entries at deploy time,
     * where the asset bytes are already local and don't need to be re-fetched from their original URL.
     */
    public function sideload_local_file($local_path, $filename, $project, $overwrite = true) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        // the same bytes uploaded before are used again while their attachment is still in the media library
        $md5 = md5_file($local_path);
        $existing = $md5 ? $this->find_by_md5($md5) : 0;
        if ($existing) {
            return [
                'status' => 'OK',
                'wp_resource' => [
                    'id' => $existing,
                    'url' => wp_get_attachment_url($existing),
                    'project' => sanitize_file_name($project)
                ]
            ];
        }

        $tmp = wp_tempnam($filename);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_copy -- copying a local theme file into the standard WP temp path before sideload
        if (!copy($local_path, $tmp)) {
            return new \WP_Error('copy_failed', __('Failed to stage local file for upload', 'transjt-ai'));
        }

        $result = $this->sideload_to_media_library($tmp, $filename, $project, $overwrite);
        if (!is_wp_error($result) && $md5) {
            update_post_meta($result['wp_resource']['id'], self::MD5_META_KEY, $md5);
        }
        return $result;
    }

    /**
     * an attachment tagged with these bytes whose file is still there, or 0
     */
    private function find_by_md5($md5) {
        $ids = get_posts([
            'post_type'        => 'attachment',
            'post_status'      => 'any',
            'meta_key'         => self::MD5_META_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery
            'meta_value'       => $md5, // phpcs:ignore WordPress.DB.SlowDBQuery
            'fields'           => 'ids',
            'posts_per_page'   => 1,
            'no_found_rows'    => true,
            'suppress_filters' => true,
        ]);
        $file = $ids ? get_attached_file($ids[0]) : '';
        return $file && file_exists($file) ? (int) $ids[0] : 0;
    }

    /**
     * shared tail of handle_upload()/sideload_local_file(): stage a temp file into the media library
     */
    private function sideload_to_media_library($tmp, $filename, $project, $overwrite) {
        // delete existing attachment with same filename if overwrite is enabled
        if ($overwrite) {
            $this->delete_existing_by_filename($filename);
        }

        // sanitize SVG content before uploading to media library; check both extension and MIME type
        $is_svg = strtolower(pathinfo($filename, PATHINFO_EXTENSION)) === 'svg';
        if (!$is_svg && function_exists('mime_content_type')) {
            $is_svg = mime_content_type($tmp) === 'image/svg+xml';
        }
        if ($is_svg) {
            $sanitize_result = $this->sanitize_svg($tmp);
            if (\is_wp_error($sanitize_result)) {
                // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink -- temp file from download_url(); safe to use unlink directly
                if (file_exists($tmp)) unlink($tmp);
                return $sanitize_result;
            }
        }

        // upload to WordPress media library
        $file_array = ['name' => $filename, 'tmp_name' => $tmp];
        $id = media_handle_sideload($file_array, 0);

        // clean up temp file on error
        if (is_wp_error($id)) {
            // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink -- temp file from download_url(); safe to use unlink directly
            if (file_exists($file_array['tmp_name'])) unlink($file_array['tmp_name']);
            if ($this->logger) {
                $this->logger->log_asset_upload($project, $filename, false, ['error' => $id->get_error_message()]);
            }
            return $id;
        }

        // tag asset with project
        $project = sanitize_file_name($project);
        update_post_meta($id, self::PROJECT_META_KEY, $project);

        if ($this->logger) {
            $this->logger->log_asset_upload($project, $filename, true, ['attachment_id' => $id]);
        }

        return [
            'status' => 'OK',
            'wp_resource' => [
                'id' => $id,
                'url' => wp_get_attachment_url($id),
                'project' => $project
            ]
        ];
    }

    /**
     * detect file extension from URL headers
     */
    private function detect_extension_from_url($url) {
        $response = wp_remote_head($url);

        if (is_wp_error($response)) {
            return null;
        }

        $content_type = wp_remote_retrieve_header($response, 'content-type');
        return Helper::get_extension_from_mime($content_type);
    }

    /**
     * delete existing transjt-tagged attachment by filename
     * scoped to _transjt_project meta to avoid deleting unrelated media
     */
    private function delete_existing_by_filename($filename) {
        global $wpdb;

        $cache_key     = 'transjt_att_' . md5($filename);
        $attachment_id = wp_cache_get($cache_key, 'transjt');

        if ($attachment_id === false) {
            // query for attachment with matching filename that is tagged as a transjt asset
            $attachment_id = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- no WP API for this cross-table JOIN
            $wpdb->prepare(
                "SELECT pm1.post_id FROM {$wpdb->postmeta} pm1
                 INNER JOIN {$wpdb->postmeta} pm2 ON pm2.post_id = pm1.post_id
                   AND pm2.meta_key = '_transjt_project'
                 WHERE pm1.meta_key = '_wp_attached_file'
                   AND pm1.meta_value LIKE %s
                 LIMIT 1",
                '%/' . $wpdb->esc_like($filename)
            ));

            // also check for files without subdirectory
            if (!$attachment_id) {
                $attachment_id = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- no WP API for this cross-table JOIN
                $wpdb->prepare(
                    "SELECT pm1.post_id FROM {$wpdb->postmeta} pm1
                     INNER JOIN {$wpdb->postmeta} pm2 ON pm2.post_id = pm1.post_id
                       AND pm2.meta_key = '_transjt_project'
                     WHERE pm1.meta_key = '_wp_attached_file'
                       AND pm1.meta_value = %s
                     LIMIT 1",
                    $filename
                ));
            }

            // use 0 as sentinel for "not found" (0 is not a valid attachment ID)
            wp_cache_set($cache_key, $attachment_id ? $attachment_id : 0, 'transjt', MINUTE_IN_SECONDS);
        }

        if ($attachment_id) {
            wp_delete_attachment($attachment_id, true);
            wp_cache_delete($cache_key, 'transjt');
        }
    }

    private function sanitize_svg($file_path) {
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_get_contents -- temp file from download_url() lives in sys_get_temp_dir(), outside the WP directory tree; WP_Filesystem cannot be reliably initialized inside a REST callback and is not designed for arbitrary temp paths; WordPress core itself uses file_get_contents() on download_url() temp files (see Plugin_Upgrader)
        $content = file_get_contents($file_path);
        if ($content === false) {
            return new \WP_Error('svg_error', __('Failed to read SVG file', 'transjt-ai'));
        }
        $clean = Helper::sanitize_svg_content($content);
        if (is_wp_error($clean)) return $clean;
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- same justification as above: download_url() temp file in sys_get_temp_dir(); WP_Filesystem not suitable for temp paths outside the WP directory tree
        file_put_contents($file_path, $clean);
        return true;
    }
}
