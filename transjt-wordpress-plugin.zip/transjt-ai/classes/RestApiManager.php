<?php
namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

class RestApiManager {
    private $config;
    private $asset_handler;
    private $logger;
    private $connection_manager;
    private $migration_site;
    private $migration_content;

    public function __construct(Config $config, AssetHandler $asset_handler, ?Logger $logger = null, ?ConnectionManager $connection_manager = null, ?MigrationSite $migration_site = null, ?MigrationContent $migration_content = null) {
        $this->config = $config;
        $this->asset_handler = $asset_handler;
        $this->logger = $logger;
        $this->connection_manager = $connection_manager;
        $this->migration_site = $migration_site;
        $this->migration_content = $migration_content;

        add_action('rest_api_init', [$this, 'register_routes']);
        add_action('after_switch_theme', [$this, 'on_theme_switch']);
    }

    public function register_routes() {
        $namespace = $this->config->get('rest_namespace');

        $route_args = [
            'permission_callback' => [$this, 'validate_access_key'],
        ];

        // meta endpoint - get file hashes
        register_rest_route($namespace, '/meta', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this, 'handle_meta'],
        ]));

        // asset upload endpoint - media assets
        register_rest_route($namespace, '/asset', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->asset_handler, 'handle_upload'],
        ]));

        // ping endpoint - connection check
        register_rest_route($namespace, '/ping', array_merge($route_args, [
            'methods'  => 'GET',
            'callback' => [$this, 'handle_ping'],
        ]));

        // version endpoint - report plugin version to the backend
        register_rest_route($namespace, '/version', array_merge($route_args, [
            'methods'  => 'GET',
            'callback' => [$this, 'handle_version'],
        ]));

        // install endpoint - backend-triggered package installation
        register_rest_route($namespace, '/install', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this, 'handle_install'],
        ]));

        // install assets endpoint - the next bundled images of a theme installed without them
        register_rest_route($namespace, '/install/assets', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this, 'handle_install_assets'],
        ]));

        // apply endpoint - write part of a package into the installed theme
        register_rest_route($namespace, '/apply', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this, 'handle_apply'],
        ]));

        // files endpoint - theme file contents for the backend's backup
        register_rest_route($namespace, '/files', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this, 'handle_files'],
        ]));

        // migration site endpoint - the site's address, plugins, languages and permalinks
        register_rest_route($namespace, '/migration/site', array_merge($route_args, [
            'methods'  => 'GET',
            'callback' => [$this->migration_site, 'handle_site'],
        ]));

        // migration plugins endpoint - install and activate Contact Form 7 or Polylang
        register_rest_route($namespace, '/migration/plugins', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->migration_site, 'handle_plugin'],
        ]));

        // migration permalinks endpoint - post-name permalinks
        register_rest_route($namespace, '/migration/permalinks', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->migration_site, 'handle_permalinks'],
        ]));

        // migration languages endpoint - Polylang's languages
        register_rest_route($namespace, '/migration/languages', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->migration_site, 'handle_languages'],
        ]));

        // migration media endpoint - files into the media library
        register_rest_route($namespace, '/migration/media', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->migration_content, 'handle_media'],
        ]));

        // migration authors endpoint - a user per author
        register_rest_route($namespace, '/migration/authors', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->migration_content, 'handle_authors'],
        ]));

        // migration terms endpoint - categories and tags
        register_rest_route($namespace, '/migration/terms', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->migration_content, 'handle_terms'],
        ]));

        // migration types endpoint - a post type per collection
        register_rest_route($namespace, '/migration/types', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->migration_content, 'handle_types'],
        ]));

        // migration posts endpoint - posts, entries and translated pages as drafts
        register_rest_route($namespace, '/migration/posts', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->migration_content, 'handle_posts'],
        ]));

        // migration forms endpoint - Contact Form 7 forms
        register_rest_route($namespace, '/migration/forms', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->migration_content, 'handle_forms'],
        ]));

        // migration menus endpoint - menus with no theme location
        register_rest_route($namespace, '/migration/menus', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->migration_content, 'handle_menus'],
        ]));

        // migration redirects endpoint - the old addresses
        register_rest_route($namespace, '/migration/redirects', array_merge($route_args, [
            'methods'  => 'POST',
            'callback' => [$this->migration_content, 'handle_redirects'],
        ]));
    }

    /**
     * validate access key from request header
     */
    public function validate_access_key($request) {
        $stored_key = $this->config->get_access_key();
        $provided_key = (string) $request->get_header($this->config->get('access_key_header'));
        $route = $request->get_route();

        if (empty($stored_key)) {
            if ($this->logger) {
                $this->logger->log_api_auth_failure($route, 'access key not configured');
            }
            return new \WP_Error('rest_forbidden', __('Access Key is not configured in WordPress.', 'transjt-ai'), ['status' => 403]);
        }

        if (hash_equals($stored_key, $provided_key)) {
            if ($this->logger) {
                $this->logger->log_api($route, 'authenticated request');
            }
            // scope MIME type extensions to authenticated plugin requests only; remove after response
            add_filter('upload_mimes', [$this, 'allow_additional_mime_types']);
            add_filter('rest_post_dispatch', function($response) {
                remove_filter('upload_mimes', [$this, 'allow_additional_mime_types']);
                return $response;
            });
            return true;
        }

        if ($this->logger) {
            $this->logger->log_api_auth_failure($route, 'invalid access key');
        }
        return new \WP_Error('rest_forbidden', __('Invalid access key.', 'transjt-ai'), ['status' => 403]);
    }

    /**
     * handle meta request - return file hashes
     */
    public function handle_meta($request) {
        $project = $request->get_param('project');
        $paths = $request->get_param('paths');

        if (!$project) {
            return new \WP_Error('rest_error', __('Invalid request: project required', 'transjt-ai'), ['status' => 400]);
        }

        if (!is_array($paths) || empty($paths)) {
            return new \WP_Error('rest_error', __('Invalid request: paths must be a non-empty array', 'transjt-ai'), ['status' => 400]);
        }

        if (count($paths) > 500) {
            return new \WP_Error('rest_error', __('Invalid request: too many paths', 'transjt-ai'), ['status' => 400]);
        }

        $project = sanitize_file_name($project);
        $project_dir = get_theme_root() . '/' . $project;
        $result = [];

        foreach ($paths as $path) {
            $full_path = $project_dir . '/' . Helper::sanitize_path($path);

            if (is_file($full_path)) {
                $result[$path] = (object)[
                    'hash' => md5_file($full_path),
                ];
            } else {
                $result[$path] = null;
            }
        }

        if ($this->logger) {
            $this->logger->log_api('/meta', 'file meta retrieved', ['project' => $project, 'paths_count' => count($paths)]);
        }

        return rest_ensure_response([
            "status" => "OK",
            "data" => $result
        ]);
    }

    /**
     * handle ping - connection check
     */
    public function handle_ping($request) {
        return rest_ensure_response([
            'status' => 'OK',
            'data'   => 'pong',
        ]);
    }

    /**
     * handle version - report plugin version to the backend
     */
    public function handle_version($request) {
        return rest_ensure_response([
            'status' => 'OK',
            'data'   => ['version' => TRANSJT_VERSION],
        ]);
    }

    /**
     * run CF7 form setup when a transjt theme is activated
     */
    public function on_theme_switch() {
        if (strpos(get_stylesheet(), 'tj-') !== 0) {
            return;
        }
        Helper::run_cf7_setup(get_template_directory());
    }

    /**
     * handle install - backend-triggered theme package installation
     */
    public function handle_install($request) {
        $package_id = sanitize_text_field((string) $request->get_param('packageId'));

        if (empty($package_id)) {
            return new \WP_Error('rest_error', __('Invalid request: packageId required', 'transjt-ai'), ['status' => 400]);
        }

        $details = $this->connection_manager->get_package_details($package_id);

        if (is_wp_error($details)) {
            if ($this->logger) {
                $this->logger->log_api('/install', 'package details fetch failed', ['package_id' => $package_id, 'error' => $details->get_error_message()]);
            }
            return new \WP_Error('rest_error', $details->get_error_message(), ['status' => 400]);
        }

        $installer = new ThemeInstaller($this->logger);
        $result = $installer->install_from_details([
            'project'  => $details['slug'] ?? $package_id,
            'zip_url'  => $details['zip_url'] ?? '',
            'zip_hash' => $details['zip_hash'] ?? '',
            // false: the backend uploads the images through install/assets, in calls short enough for a proxy
            'assets'   => $request->get_param('assets') !== false,
        ]);

        $this->connection_manager->acknowledge_installation(
            $package_id,
            $result['success'] ? 'installed' : 'failed',
            $result['success'] ? null : $result['message'],
            $result['report']
        );

        if ($this->logger) {
            $this->logger->log_api(
                '/install',
                $result['success'] ? 'package installed' : 'package install failed',
                ['package_id' => $package_id]
            );
        }

        if (!$result['success']) {
            return new \WP_Error('rest_error', $result['message'], ['status' => 422, 'report' => $result['report']]);
        }

        $theme_slug = $details['slug'] ?? $package_id;
        if ($theme_slug === get_stylesheet()) {
            Helper::run_cf7_setup(get_template_directory());
        }

        return rest_ensure_response([
            'status' => 'OK',
            'data'   => ['packageId' => $package_id, 'report' => $result['report'], 'pendingAssets' => $result['pendingAssets']],
        ]);
    }

    /**
     * handle install/assets - the next bundled images of a theme installed with assets: false
     */
    public function handle_install_assets($request) {
        $project = sanitize_file_name((string) $request->get_param('project'));

        if (empty($project)) {
            return new \WP_Error('rest_error', __('Invalid request: project required', 'transjt-ai'), ['status' => 400]);
        }

        $installer = new ThemeInstaller($this->logger);
        return rest_ensure_response([
            'status' => 'OK',
            'data'   => $installer->install_assets($project, max(0, (int) $request->get_param('offset'))),
        ]);
    }

    /**
     * handle apply - write the given paths of a package into the installed theme; the backend records the result
     */
    public function handle_apply($request) {
        $package_id = sanitize_text_field((string) $request->get_param('packageId'));
        $paths = $request->get_param('paths');
        $expected = $request->get_param('expected');

        if (empty($package_id)) {
            return new \WP_Error('rest_error', __('Invalid request: packageId required', 'transjt-ai'), ['status' => 400]);
        }

        if (!is_array($paths) || empty($paths)) {
            return new \WP_Error('rest_error', __('Invalid request: paths must be a non-empty array', 'transjt-ai'), ['status' => 400]);
        }

        $details = $this->connection_manager->get_package_details($package_id);

        if (is_wp_error($details)) {
            if ($this->logger) {
                $this->logger->log_api('/apply', 'package details fetch failed', ['package_id' => $package_id, 'error' => $details->get_error_message()]);
            }
            return new \WP_Error('rest_error', $details->get_error_message(), ['status' => 400]);
        }

        $installer = new ThemeInstaller($this->logger);
        $result = $installer->apply_from_details([
            'project'  => $details['slug'] ?? '',
            'zip_url'  => $details['zip_url'] ?? '',
            'zip_hash' => $details['zip_hash'] ?? '',
        ], array_values($paths), is_array($expected) ? $expected : [], (bool) $request->get_param('force'));

        if ($this->logger) {
            $this->logger->log_api('/apply', is_wp_error($result) ? 'package apply failed' : 'package applied', ['package_id' => $package_id]);
        }

        if (is_wp_error($result)) {
            return $result;
        }

        // new form blocks need their forms, as after /install
        if (($details['slug'] ?? '') === get_stylesheet()) {
            Helper::run_cf7_setup(get_template_directory());
        }

        return rest_ensure_response([
            'status' => 'OK',
            'data'   => ['files' => (object) $result['files'], 'skipped' => $result['skipped'], 'pluginVersion' => TRANSJT_VERSION],
        ]);
    }

    /**
     * handle files - return theme file contents, base64, null for a missing file
     */
    public function handle_files($request) {
        $project = $request->get_param('project');
        $paths = $request->get_param('paths');

        if (!$project) {
            return new \WP_Error('rest_error', __('Invalid request: project required', 'transjt-ai'), ['status' => 400]);
        }

        if (!is_array($paths) || empty($paths)) {
            return new \WP_Error('rest_error', __('Invalid request: paths must be a non-empty array', 'transjt-ai'), ['status' => 400]);
        }

        if (count($paths) > 100) {
            return new \WP_Error('rest_error', __('Invalid request: too many paths', 'transjt-ai'), ['status' => 400]);
        }

        $project = sanitize_file_name($project);
        $project_dir = get_theme_root() . '/' . $project;
        if (!$project || !is_dir($project_dir)) {
            return new \WP_Error('THEME_NOT_INSTALLED', __('The theme is not installed on this site', 'transjt-ai'), ['status' => 404]);
        }

        $targets = [];
        $size = 0;
        foreach ($paths as $path) {
            $target = Helper::theme_path($project_dir, $path);
            if ($target === null) {
                // translators: %s: Theme file path.
                return new \WP_Error('INVALID_PATH', sprintf(__('Invalid theme path: %s', 'transjt-ai'), is_string($path) ? $path : ''), ['status' => 400]);
            }
            if (is_file($target)) {
                $targets[$path] = $target;
                $size += filesize($target);
            }
        }

        if ($size > 20 * MB_IN_BYTES) {
            return new \WP_Error('TOO_LARGE', __('Requested files exceed 20MB', 'transjt-ai'), ['status' => 413]);
        }

        // the base64 copies need more than the default front-end limit
        wp_raise_memory_limit('admin');
        $result = [];
        foreach ($paths as $path) {
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_get_contents -- local theme file
            $result[$path] = isset($targets[$path]) ? base64_encode(file_get_contents($targets[$path])) : null;
        }

        if ($this->logger) {
            $this->logger->log_api('/files', 'file contents retrieved', ['project' => $project, 'paths_count' => count($paths)]);
        }

        return rest_ensure_response([
            'status' => 'OK',
            'data'   => $result,
        ]);
    }

    /**
     * allow additional MIME types for asset uploads
     *
     * SVG mime is included because the transjt sync pipeline pushes theme assets (icons, illustrations)
     * in SVG format. This filter is attached only after successful access key validation, so it applies
     * exclusively to authenticated plugin requests, not to the media uploader or any other upload path.
     */
    public function allow_additional_mime_types($mimes) {
        $mimes['svg'] = 'image/svg+xml';
        $mimes['webp'] = 'image/webp';
        $mimes['woff'] = 'font/woff';
        $mimes['woff2'] = 'font/woff2';
        $mimes['ttf'] = 'font/ttf';
        $mimes['otf'] = 'font/otf';
        $mimes['eot'] = 'application/vnd.ms-fontobject';
        return $mimes;
    }
}
