<?php
namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

class UpdateManager {
    private const TRANSIENT_KEY = 'transjt_update_info';
    private const FAILURE_TTL = 60; // retry failed checks after 60 seconds

    private $logger;
    private $request_done = false;
    private $request_data = null;

    public function __construct(?Logger $logger = null) {
        $this->logger = $logger;
        add_filter('site_transient_update_plugins', [$this, 'injectUpdateInfo']);
        add_filter('plugins_api', [$this, 'pluginInfo'], 10, 3);
        add_filter('http_request_host_is_external', [$this, 'allowUpdateHost'], 10, 2);
    }

    // whitelist the update/download host so wp_http_validate_url() doesn't reject
    // private/local IPs (e.g. on dev environments with .loc domains)
    public function allowUpdateHost($is_external, $host) {
        $update_host = parse_url(TRANSJT_UPDATE_INFO_URL, PHP_URL_HOST);
        if ($update_host && strtolower($host) === strtolower($update_host)) {
            return true;
        }
        return $is_external;
    }

    private function log(string $message, string $type = 'info', array $context = []): void {
        if ($this->logger) {
            $this->logger->log($message, $type, $context);
        }
    }

    public function injectUpdateInfo($transient) {
        if (!is_object($transient)) {
            return $transient;
        }

        $data = $this->fetchVersionData();
        if (!$data || !isset($data['version'])) {
            return $transient;
        }

        $entry               = new \stdClass();
        $entry->slug         = 'transjt-ai';
        $entry->plugin       = TRANSJT_PLUGIN_BASENAME;
        $entry->new_version  = $data['version'];
        $entry->url          = 'https://transjt.ai';
        $entry->package      = $data['download_url'];
        $entry->requires     = $data['requires']     ?? '6.0';
        $entry->tested       = $data['tested']       ?? '';
        $entry->requires_php = $data['requires_php'] ?? '7.4';
        $entry->icons        = [];
        $entry->banners      = [];

        if (version_compare($data['version'], TRANSJT_VERSION, '>')) {
            $transient->response[TRANSJT_PLUGIN_BASENAME] = $entry;
        } else {
            $transient->no_update[TRANSJT_PLUGIN_BASENAME] = $entry;
        }

        return $transient;
    }

    public function pluginInfo($result, $action, $args) {
        if ($action !== 'plugin_information' || ($args->slug ?? '') !== 'transjt-ai') {
            return $result;
        }

        $data = $this->fetchVersionData();
        if (!$data) {
            return $result;
        }

        $info = new \stdClass();
        $info->name = $data['name'];
        $info->slug = 'transjt-ai';
        $info->version = $data['version'];
        $info->requires = $data['requires'] ?? '6.0';
        $info->tested = $data['tested'] ?? '';
        $info->requires_php = $data['requires_php'] ?? '7.4';
        $info->download_link = $data['download_url'];
        $info->banners = $data['banners'] ?? [];
        $info->sections = $data['sections'] ?? ['description' => ''];

        return $info;
    }

    private function fetchVersionData(): ?array {
        // within-request deduplication: filter fires multiple times per page load
        if ($this->request_done) {
            return $this->request_data;
        }

        $cached = get_transient(self::TRANSIENT_KEY);
        if ($cached !== false) {
            $this->request_done = true;
            $this->request_data = isset($cached['_failed']) ? null : $cached;
            return $this->request_data;
        }

        $this->log('checking for plugin update', 'info', ['endpoint' => TRANSJT_UPDATE_INFO_URL, 'current_version' => TRANSJT_VERSION]);

        $response = wp_remote_get(TRANSJT_UPDATE_INFO_URL, [
            'timeout' => 10,
            'headers' => ['Accept' => 'application/json'],
        ]);

        if (is_wp_error($response)) {
            $this->log('update check failed: ' . $response->get_error_message(), 'error');
            set_transient(self::TRANSIENT_KEY, ['_failed' => true], self::FAILURE_TTL);
            $this->request_done = true;
            return null;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            $this->log('update check failed: unexpected HTTP status', 'error', ['status' => $code]);
            set_transient(self::TRANSIENT_KEY, ['_failed' => true], self::FAILURE_TTL);
            $this->request_done = true;
            return null;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $data = $body['data'] ?? null;
        if (($body['status'] ?? '') !== 'OK' || !is_array($data) || empty($data['version']) || empty($data['download_url'])) {
            $this->log('update check failed: invalid response body', 'error');
            set_transient(self::TRANSIENT_KEY, ['_failed' => true], self::FAILURE_TTL);
            $this->request_done = true;
            return null;
        }

        $this->log('update check complete', 'info', ['latest_version' => $data['version'], 'current_version' => TRANSJT_VERSION]);

        set_transient(self::TRANSIENT_KEY, $data, TRANSJT_UPDATE_CACHE_TTL);
        $this->request_done = true;
        $this->request_data = $data;
        return $data;
    }
}
