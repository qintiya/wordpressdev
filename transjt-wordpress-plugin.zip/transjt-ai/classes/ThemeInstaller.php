<?php

namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

class ThemeInstaller {
    // theme-relative paths the site owner edits: carried across a reinstall, since the core
    // upgrader clears the whole theme directory before unpacking the new package
    private const PRESERVE_EXISTING_FILES = ['assets/css/custom.css', 'assets/js/custom.js'];
    // the theme's page sync runs off this file, so apply writes it last
    private const BUILD_FILE = 'pages/build.txt';
    // an install/assets call takes no new image after this long, to stay under a proxy's timeout in front of the site
    private const ASSETS_BATCH_S = 15;

    private $logger;

    public function __construct(?Logger $logger = null) {
        $this->logger = $logger;
    }

    public function install_from_details(array $details): array {
        $project  = $details['project'] ?? '';
        $zip_url  = $details['zip_url'] ?? '';
        $zip_hash = $details['zip_hash'] ?? '';

        // sent to the backend with the install acknowledgement and kept on the package for support
        $report = [
            'date'          => gmdate('c'),
            'status'        => 'FAILED',
            'error'         => null,
            'pluginVersion' => TRANSJT_VERSION,
        ];

        if (!$project || !$zip_url || !$zip_hash) {
            $message = __('Invalid package details: project, zip_url, and zip_hash required', 'transjt-ai');
            $report['error'] = $message;
            return ['success' => false, 'message' => $message, 'report' => $report];
        }

        $theme_dir = get_theme_root() . '/' . $project;
        $preserved = $this->_read_preserved_files($theme_dir);

        $result = $this->_perform_install($project, $zip_url, $zip_hash);

        if (is_wp_error($result)) {
            $report['error'] = $result->get_error_message();
            return ['success' => false, 'message' => $result->get_error_message(), 'report' => $report];
        }

        // assets false: the images stay bundled for install_assets()
        $with_assets = $details['assets'] ?? true;
        if ($with_assets) {
            $report['images'] = $this->_process_pending_assets($theme_dir, $project)['images'];
        }
        // last, so the owner's own content is never touched by the asset URL rewrite above
        $report['files'] = ['preserved' => $this->_restore_preserved_files($theme_dir, $preserved)];
        $report['status'] = 'OK';

        $pending = $with_assets ? 0 : count($this->_pending_assets($theme_dir));
        return ['success' => true, 'message' => __('Theme installed successfully', 'transjt-ai'), 'report' => $report, 'pendingAssets' => $pending];
    }

    /**
     * the bundled images of a theme installed without them, from $offset on, for up to ASSETS_BATCH_S (at least one)
     */
    public function install_assets(string $project, int $offset): array {
        // as the core upgrader gives an install: one large image alone can outlast the host's default limit
        @set_time_limit(300); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        return $this->_process_pending_assets(get_theme_root() . '/' . $project, $project, $offset, microtime(true) + self::ASSETS_BATCH_S);
    }

    /**
     * write the listed paths of the package over the installed theme, leaving every other file as it is.
     * $expected maps each path to the md5 the backend saw on the site (null: must not exist); unless $force,
     * any difference refuses the call before a file is written.
     * returns ['files' => [path => md5 written], 'skipped' => [preserved paths]] or WP_Error
     */
    public function apply_from_details(array $details, array $paths, array $expected, bool $force) {
        $project = sanitize_file_name($details['project'] ?? '');
        $theme_dir = get_theme_root() . '/' . $project;
        if (!$project || !is_dir($theme_dir)) {
            return new \WP_Error('THEME_NOT_INSTALLED', __('The theme is not installed on this site', 'transjt-ai'), ['status' => 404]);
        }

        $targets = [];
        foreach ($paths as $path) {
            $target = Helper::theme_path($theme_dir, $path);
            if ($target === null) {
                // translators: %s: Theme file path.
                return new \WP_Error('INVALID_PATH', sprintf(__('Invalid theme path: %s', 'transjt-ai'), is_string($path) ? $path : ''), ['status' => 400]);
            }
            $targets[$path] = $target;
        }
        if (isset($targets[self::BUILD_FILE])) {
            $build_target = $targets[self::BUILD_FILE];
            unset($targets[self::BUILD_FILE]);
            $targets[self::BUILD_FILE] = $build_target;
        }

        $tmp_file = $this->_download_verified_zip($project, $details['zip_url'] ?? '', $details['zip_hash'] ?? '');
        if (is_wp_error($tmp_file)) {
            return $tmp_file;
        }
        if (!class_exists('ZipArchive')) {
            unlink($tmp_file); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
            return new \WP_Error('zip_unsupported', __('The ZipArchive PHP extension is required', 'transjt-ai'), ['status' => 500]);
        }
        $zip = new \ZipArchive();
        if ($zip->open($tmp_file) !== true) {
            unlink($tmp_file); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
            return new \WP_Error('invalid_zip', __('Could not open the theme ZIP', 'transjt-ai'), ['status' => 422]);
        }
        $result = $this->_apply_zip($zip, $project, $targets, $expected, $force);
        $zip->close();
        unlink($tmp_file); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink

        if ($this->logger) {
            $this->logger->log(
                is_wp_error($result) ? 'Theme apply failed: ' . $result->get_error_code() : 'Theme files applied',
                is_wp_error($result) ? 'error' : 'file',
                ['project' => $project, 'files' => is_wp_error($result) ? count($result->get_error_data()['files'] ?? []) : count($result['files'])]
            );
        }

        return $result;
    }

    private function _apply_zip(\ZipArchive $zip, string $project, array $targets, array $expected, bool $force) {
        // bundled images are only resolved by a full install
        if ($zip->locateName($project . '/deploy.json') !== false) {
            return new \WP_Error('PENDING_ASSETS_UNSUPPORTED', __('This package must be installed in full', 'transjt-ai'), ['status' => 422]);
        }
        foreach (array_keys($targets) as $path) {
            if ($zip->locateName($project . '/' . $path) === false) {
                // translators: %s: Theme file path.
                return new \WP_Error('INVALID_PATH', sprintf(__('Path is not in the package: %s', 'transjt-ai'), $path), ['status' => 400]);
            }
        }

        $skipped = [];
        foreach (self::PRESERVE_EXISTING_FILES as $path) {
            if (isset($targets[$path]) && file_exists($targets[$path])) {
                $skipped[] = $path;
                unset($targets[$path]);
            }
        }

        if (!$force) {
            $conflicts = [];
            foreach ($targets as $path => $target) {
                $current = is_file($target) ? md5_file($target) : null;
                $want = $expected[$path] ?? null;
                if ($current !== $want) {
                    $conflicts[] = ['path' => $path, 'reason' => $current === null ? 'deleted' : ($want === null ? 'exists' : 'changed')];
                }
            }
            if ($conflicts) {
                return new \WP_Error('CONFLICT', __('Theme files were changed on the site', 'transjt-ai'), ['status' => 409, 'conflicts' => $conflicts]);
            }
        }

        $files = [];
        $error = null;
        foreach ($targets as $path => $target) {
            $content = $zip->getFromName($project . '/' . $path);
            if ($content === false || !$this->_write_file($target, $content)) {
                // translators: %s: Theme file path.
                $error = new \WP_Error('WRITE_FAILED', sprintf(__('Could not write %s', 'transjt-ai'), $path), ['status' => 500, 'files' => $files]);
                break;
            }
            $files[$path] = md5($content);
            // some hosts never revalidate opcache
            if (substr($path, -4) === '.php' && function_exists('opcache_invalidate')) {
                opcache_invalidate($target, true);
            }
        }

        if ($files) {
            if (function_exists('wp_clean_theme_json_cache')) {
                wp_clean_theme_json_cache();
            }
            wp_get_theme($project)->cache_delete();
        }

        return $error ?: ['files' => $files, 'skipped' => $skipped];
    }

    // a temp file renamed into place, so no request runs half a file
    private function _write_file(string $target, string $content): bool {
        if (!wp_mkdir_p(dirname($target))) {
            return false;
        }
        $tmp = dirname($target) . '/.' . basename($target) . '.' . wp_generate_password(8, false) . '.tmp';
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- theme file from the verified package
        if (file_put_contents($tmp, $content) === false) {
            return false;
        }
        chmod($tmp, file_exists($target) ? (fileperms($target) & 0777) : (defined('FS_CHMOD_FILE') ? FS_CHMOD_FILE : 0644)); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod
        if (!rename($tmp, $target)) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
            unlink($tmp); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
            return false;
        }
        return true;
    }

    /**
     * read the files listed in PRESERVE_EXISTING_FILES out of the currently installed theme,
     * before the upgrader deletes the directory. missing files are simply not collected -
     * a first install has nothing to preserve and gets the package's placeholder as-is.
     */
    private function _read_preserved_files(string $theme_dir): array {
        $preserved = [];

        foreach (self::PRESERVE_EXISTING_FILES as $rel_path) {
            $path = rtrim($theme_dir, '/') . '/' . $rel_path;
            if (!file_exists($path)) {
                continue;
            }
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_get_contents -- local theme file, not from download_url()
            $content = file_get_contents($path);
            if ($content === false) {
                if ($this->logger) {
                    $this->logger->log('Theme install: could not read ' . $rel_path . ' - it will be replaced by the package copy', 'error');
                }
                continue;
            }
            $preserved[$rel_path] = $content;
        }

        return $preserved;
    }

    /**
     * write the preserved content back over the placeholder the package just installed.
     * a path the new package no longer ships is not resurrected. returns the restored paths.
     */
    private function _restore_preserved_files(string $theme_dir, array $preserved): array {
        $restored = [];
        foreach ($preserved as $rel_path => $content) {
            $path = rtrim($theme_dir, '/') . '/' . $rel_path;
            if (!file_exists($path)) {
                continue;
            }
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- local theme file, not from download_url()
            if (file_put_contents($path, $content) === false) {
                if ($this->logger) {
                    $this->logger->log('Theme install: could not restore ' . $rel_path, 'error');
                }
                continue;
            }
            $restored[] = $rel_path;
            if ($this->logger) {
                $this->logger->log('Theme install: preserved existing ' . $rel_path, 'file');
            }
        }

        return $restored;
    }

    /**
     * resolve deploy.json left by the backend at build time (images bundled into the package
     * instead of live-uploaded, since no connection existed yet): sideload each bundled image into the
     * media library, rewrite its original URL to the resulting attachment URL across the theme files,
     * then remove the manifest and staged files from the installed theme. from $offset, and with $until only until
     * that time (at least one image); the manifest goes with the last image.
     * returns ['images' => status per image, 'next' => the first image not done, 'total' => count]
     */
    private function _process_pending_assets(string $theme_dir, string $project, int $offset = 0, ?float $until = null): array {
        $manifest_path = rtrim($theme_dir, '/') . '/deploy.json';
        $assets = $this->_pending_assets($theme_dir);
        $total = count($assets);
        $stale_paths = [];

        $asset_handler = new AssetHandler($this->logger);
        $replacements = [];
        $images = [];

        // svg is not in the core allowed list; outside an access-key REST request (the admin page install) nothing else adds it
        $allow_svg = function ($mimes) {
            $mimes['svg'] = 'image/svg+xml';
            return $mimes;
        };
        add_filter('upload_mimes', $allow_svg);

        for ($i = $offset; $i < $total; $i++) {
            if ($until !== null && $i > $offset && microtime(true) >= $until) {
                break;
            }
            $asset = $assets[$i];
            $package_path = $asset['packagePath'] ?? '';
            $original_url = $asset['originalUrl'] ?? '';
            if (!$original_url) {
                continue;
            }
            $image = [
                'originalUrl' => $original_url,
                'packagePath' => $package_path ?: null,
                'status'      => 'UPLOADED',
                'url'         => null,
                'error'       => null,
                'replaced'    => 0,
            ];

            if (!$package_path) {
                $image['status'] = 'NOT_BUNDLED';
                $images[] = $image;
                continue;
            }

            $local_path = rtrim($theme_dir, '/') . '/' . ltrim($package_path, '/');
            if (!file_exists($local_path)) {
                $image['status'] = 'MISSING_IN_PACKAGE';
                $images[] = $image;
                continue;
            }
            $stale_paths[] = $local_path;

            $result = $asset_handler->sideload_local_file($local_path, basename($local_path), $project);
            if (is_wp_error($result) || empty($result['wp_resource']['url'])) {
                if ($this->logger) {
                    $this->logger->log('Theme install: pending asset upload failed for ' . $package_path, 'error', ['project' => $project]);
                }
                $image['status'] = 'UPLOAD_FAILED';
                $image['error'] = is_wp_error($result) ? $result->get_error_message() : __('No attachment URL returned', 'transjt-ai');
                $images[] = $image;
                continue;
            }
            $image['url'] = $result['wp_resource']['url'];
            $replacements[$original_url] = $image['url'];
            $images[] = $image;
        }
        $next = $i;
        if ($next >= $total && file_exists($manifest_path)) {
            $stale_paths[] = $manifest_path;
        }

        remove_filter('upload_mimes', $allow_svg);

        if ($replacements) {
            $replaced = $this->_apply_replacements($theme_dir, $replacements);
            foreach ($images as &$image) {
                if ($image['status'] === 'UPLOADED') {
                    $image['replaced'] = $replaced[$image['originalUrl']] ?? 0;
                }
            }
            unset($image);
        }

        foreach ($stale_paths as $path) {
            // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink -- local theme file, not from download_url()
            if (file_exists($path)) unlink($path);
        }

        return ['images' => $images, 'next' => $next, 'total' => $total];
    }

    /**
     * the assets deploy.json lists, [] without it
     */
    private function _pending_assets(string $theme_dir): array {
        $manifest_path = rtrim($theme_dir, '/') . '/deploy.json';
        if (!file_exists($manifest_path)) {
            return [];
        }
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_get_contents -- local theme file, not from download_url()
        $manifest = json_decode(file_get_contents($manifest_path), true);
        return array_values($manifest['assets'] ?? []);
    }

    /**
     * search & replace pending asset URLs across the installed theme's text files.
     * returns the number of occurrences replaced per original URL.
     */
    private function _apply_replacements(string $theme_dir, array $replacements): array {
        $replaced = array_fill_keys(array_keys($replacements), 0);

        // a migrated site's bundled videos and documents are still in the theme here: read as text, one large video
        // could take the request's whole memory
        $binary_exts = ['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'avif', 'apng', 'woff', 'woff2', 'ttf', 'otf', 'ico', 'mp4', 'webm', 'mov', 'pdf'];

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($theme_dir, \RecursiveDirectoryIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if (!$file->isFile()) {
                continue;
            }
            if (in_array(strtolower($file->getExtension()), $binary_exts, true)) {
                continue;
            }
            $path = $file->getPathname();
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_get_contents -- local theme file, not from download_url()
            $content = file_get_contents($path);
            if ($content === false) {
                continue;
            }
            foreach (array_keys($replacements) as $search) {
                $replaced[$search] += substr_count($content, $search);
            }
            $new_content = strtr($content, $replacements);
            if ($new_content !== $content) {
                // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- local theme file, not from download_url()
                file_put_contents($path, $new_content);
            }
        }

        return $replaced;
    }

    private function _perform_install(string $project, string $zip_url, string $zip_hash): \WP_Error|bool {
        $tmp_file = $this->_download_verified_zip($project, $zip_url, $zip_hash);
        if (is_wp_error($tmp_file)) {
            return $tmp_file;
        }

        // install via WordPress core upgrader; overwrite_package handles both new installs and updates
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        if (!class_exists('WP_Ajax_Upgrader_Skin')) {
            require_once ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php';
        }

        $skin     = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new \Theme_Upgrader($skin);
        $result   = $upgrader->install($tmp_file, ['overwrite_package' => true]);

        if (file_exists($tmp_file)) unlink($tmp_file); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink

        if (!$result || is_wp_error($result)) {
            $error_msg = is_wp_error($result)
                ? $result->get_error_message()
                : implode('; ', $skin->get_errors() ?: [__('Unknown installation error', 'transjt-ai')]);
            if ($this->logger) {
                $this->logger->log('Theme install failed: ' . $error_msg, 'error', ['project' => $project]);
            }
            return new \WP_Error('install_failed', $error_msg, ['status' => 500]);
        }

        if ($this->logger) {
            $this->logger->log('Theme installed successfully', 'file', ['project' => $project]);
        }

        return true;
    }

    // the package ZIP downloaded to a temp file and checked against its sha256; the caller removes the file
    private function _download_verified_zip(string $project, string $zip_url, string $zip_hash): \WP_Error|string {
        $zip_url = esc_url_raw($zip_url);
        if (empty($zip_url) || !filter_var($zip_url, FILTER_VALIDATE_URL)) {
            return new \WP_Error('invalid_url', __('Invalid ZIP URL provided', 'transjt-ai'), ['status' => 400]);
        }

        $scheme = wp_parse_url($zip_url, PHP_URL_SCHEME);
        if (!in_array($scheme, ['http', 'https'], true)) {
            return new \WP_Error('invalid_url', __('Only HTTP and HTTPS URLs are allowed', 'transjt-ai'), ['status' => 400]);
        }

        $host    = wp_parse_url($zip_url, PHP_URL_HOST);
        $allowed = defined('TRANSJT_ALLOWED_DOMAINS') && TRANSJT_ALLOWED_DOMAINS
            ? array_map('trim', explode(',', TRANSJT_ALLOWED_DOMAINS))
            : [];

        if (empty($allowed) || !in_array($host, $allowed, true)) {
            return new \WP_Error('disallowed_domain', __('ZIP URL domain is not allowed', 'transjt-ai'), ['status' => 403]);
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';

        $tmp_file = download_url($zip_url, 60);

        if (is_wp_error($tmp_file)) {
            if ($this->logger) {
                $this->logger->log('Theme install: ZIP download failed — ' . $tmp_file->get_error_message(), 'error', ['project' => $project]);
            }
            // translators: %s: Error message.
            return new \WP_Error('download_failed', sprintf(__('Could not download theme ZIP: %s', 'transjt-ai'), $tmp_file->get_error_message()), ['status' => 500]);
        }

        // verify hash before the file is used
        $actual_hash = hash_file('sha256', $tmp_file);
        if (!hash_equals((string) $zip_hash, $actual_hash)) {
            if (file_exists($tmp_file)) unlink($tmp_file); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
            if ($this->logger) {
                $this->logger->log('Theme install: ZIP hash mismatch', 'error', ['project' => $project]);
            }
            return new \WP_Error('hash_mismatch', __('Theme ZIP integrity check failed: hash mismatch', 'transjt-ai'), ['status' => 422]);
        }

        return $tmp_file;
    }
}
