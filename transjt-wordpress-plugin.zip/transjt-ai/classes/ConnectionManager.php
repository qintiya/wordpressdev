<?php
namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

class ConnectionManager {
    private $config;
    private $logger;

    public function __construct(Config $config, ?Logger $logger = null) {
        $this->config = $config;
        $this->logger = $logger;

        add_action('admin_init', [$this, 'handle_connection_action']);
    }

    private function log_connection($action, $success, $details = []) {
        if ($this->logger) {
            $this->logger->log_connection($action, $success, $details);
        }
    }

    public function check_status() {
        $access_key = $this->config->get_access_key();

        if (empty($access_key)) {
            return false;
        }

        $cached = get_transient('transjt_connection_status');
        if ($cached !== false) {
            return (bool) $cached;
        }

        $endpoint = TRANSJT_STATUS_ENDPOINT;
        $request_args = [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode(['accessKey' => $access_key]),
            'timeout' => 10,
        ];

        // extract basic auth from URL if present
        $request_args = $this->add_basic_auth_from_url($endpoint, $request_args);

        $response = wp_remote_post($endpoint, $request_args);

        if (is_wp_error($response)) {
            $this->log_connection('status_check', false, [
                'url' => $this->sanitize_url_for_log($endpoint),
                'error' => $response->get_error_message()
            ]);
            return false;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $is_connected = $response_code === 200;

        if (!$is_connected) {
            $response_body = wp_remote_retrieve_body($response);
            $this->log_connection('status_check', false, [
                'url' => $this->sanitize_url_for_log($endpoint),
                'response_code' => $response_code,
                'response_body' => substr($response_body, 0, 500)
            ]);
        }

        set_transient('transjt_connection_status', $is_connected ? 1 : 0, 5 * MINUTE_IN_SECONDS);

        return $is_connected;
    }

    /**
     * extract basic auth credentials from URL and add to request args
     */
    private function add_basic_auth_from_url($url, $args) {
        $parsed = wp_parse_url($url);

        if (!empty($parsed['user'])) {
            $args['headers'] = $args['headers'] ?? [];
            $args['headers']['Authorization'] = 'Basic ' . base64_encode(
                $parsed['user'] . ':' . ($parsed['pass'] ?? '')
            );
        }

        return $args;
    }

    /**
     * remove credentials from URL for safe logging
     */
    private function sanitize_url_for_log($url) {
        $parsed = wp_parse_url($url);
        if (empty($parsed['user'])) {
            return $url;
        }

        // rebuild URL without credentials
        $sanitized = $parsed['scheme'] . '://' . $parsed['host'];
        if (!empty($parsed['port'])) {
            $sanitized .= ':' . $parsed['port'];
        }
        if (!empty($parsed['path'])) {
            $sanitized .= $parsed['path'];
        }
        if (!empty($parsed['query'])) {
            $sanitized .= '?' . $parsed['query'];
        }
        return $sanitized;
    }

    public function disconnect() {
        $access_key = $this->config->get_access_key();

        if (empty($access_key)) {
            return [
                'success' => false,
                'message' => __('No access key found', 'transjt-ai'),
            ];
        }

        $endpoint = TRANSJT_ENDPOINT;
        $request_args = [
            'method' => 'DELETE',
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode([
                'accessKey' => $access_key,
            ]),
            'timeout' => 15,
        ];
        $request_args = $this->add_basic_auth_from_url($endpoint, $request_args);
        $response = wp_remote_request($endpoint, $request_args);

        if (is_wp_error($response)) {
            $this->log_connection('disconnect', false, [
                'url' => $this->sanitize_url_for_log($endpoint),
                'error' => $response->get_error_message()
            ]);
            return [
                'success' => false,
                // translators: %s: Error message.
                'message' => sprintf(__('Failed to disconnect from transjt.ai: %s', 'transjt-ai'), $response->get_error_message()),
            ];
        }

        $response_code = wp_remote_retrieve_response_code($response);

        if ($response_code >= 200 && $response_code < 300) {
            $this->config->delete_access_key();
            delete_transient('transjt_connection_status');
            $this->log_connection('disconnect', true, [
                'url' => $this->sanitize_url_for_log($endpoint)
            ]);

            return [
                'success' => true,
                'message' => __('Successfully disconnected from transjt.ai', 'transjt-ai'),
            ];
        }

        $this->log_connection('disconnect', false, [
            'url' => $this->sanitize_url_for_log($endpoint),
            'response_code' => $response_code
        ]);
        return [
            'success' => false,
            // translators: %s: HTTP response code.
            'message' => sprintf(__('Failed to disconnect from transjt.ai. Response code: %s', 'transjt-ai'), $response_code),
        ];
    }

    public function handle_connection_action() {
        if (!isset($_POST['transjt_connect_nonce'])) {
            return;
        }

        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['transjt_connect_nonce'])), 'transjt_connect_action')) {
            Helper::set_notice('error', __('Security check failed', 'transjt-ai'));
            return;
        }

        if (!current_user_can('manage_options')) {
            Helper::set_notice('error', __('Permission denied', 'transjt-ai'));
            return;
        }

        if (isset($_POST['transjt_disconnect'])) {
            $result = $this->disconnect();
            Helper::set_notice(
                $result['success'] ? 'success' : 'error',
                $result['message']
            );
            wp_safe_redirect(admin_url('admin.php?page=transjt-sync'));
            exit;
        }
    }

    /**
     * generate OTP request_code, store temporarily, return app popup URL
     */
    public function prepare_connection() {
        $request_code = Helper::generate_secure_key(32);
        $site_url = get_site_url();

        // store as one-time token - 10 min expiry
        set_transient('transjt_request_code', $request_code, 10 * MINUTE_IN_SECONDS);

        $this->log_connection('prepare', true, ['site_url' => $site_url]);

        $app_url = TRANSJT_APP_CONNECT_ENDPOINT
            . '?request_code=' . $request_code
            . '&site_url=' . rawurlencode($site_url);

        return ['appUrl' => $app_url, 'requestCode' => $request_code];
    }

    /**
     * exchange stored request_code for access_key from backend => store permanently
     */
    public function exchange_token($request_code = null) {
        if (empty($request_code)) {
            $request_code = get_transient('transjt_request_code');
        }

        if (empty($request_code)) {
            $this->log_connection('exchange', false, ['reason' => 'no pending request token']);
            return [
                'success' => false,
                'message' => __('No pending connection found', 'transjt-ai'),
            ];
        }

        $endpoint = TRANSJT_TOKEN_ENDPOINT;
        $request_args = [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode(['requestCode' => $request_code]),
            'timeout' => 15,
        ];
        $request_args = $this->add_basic_auth_from_url($endpoint, $request_args);
        $response = wp_remote_post($endpoint, $request_args);

        if (is_wp_error($response)) {
            $this->log_connection('exchange', false, [
                'url'   => $this->sanitize_url_for_log($endpoint),
                'error' => $response->get_error_message()
            ]);
            return [
                'success' => false,
                // translators: %s: Error message.
                'message' => sprintf(__('Token exchange failed: %s', 'transjt-ai'), $response->get_error_message()),
            ];
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $access_key = is_array($body) ? ($body['data']['accessKey'] ?? null) : null;

        if ($response_code === 200 && !empty($access_key)) {
            $this->config->set_access_key($access_key);
            delete_transient('transjt_request_code');
            delete_transient('transjt_connection_status');
            $this->log_connection('exchange', true, [
                'url' => $this->sanitize_url_for_log($endpoint)
            ]);

            return [
                'success' => true,
                'message' => __('Successfully connected to transjt.ai!', 'transjt-ai'),
            ];
        }

        $this->log_connection('exchange', false, [
            'url'           => $this->sanitize_url_for_log($endpoint),
            'response_code' => $response_code,
            'response_body' => substr(wp_remote_retrieve_body($response), 0, 500)
        ]);
        return [
            'success' => false,
            'message' => __('Token exchange failed. Please try again.', 'transjt-ai'),
        ];
    }

    public function cancel_pending_connection() {
        delete_transient('transjt_request_code');
        $this->log_connection('cancel', true);
    }

    public function get_packages() {
        $access_key = $this->config->get_access_key();
        if (empty($access_key)) {
            return new \WP_Error('no_access_key', __('No access key configured', 'transjt-ai'));
        }

        $endpoint = TRANSJT_PACKAGES_ENDPOINT;
        $request_args = [
            'headers' => [
                'Content-Type'         => 'application/json',
                'X-Transjt-Access-Key' => $access_key,
            ],
            'timeout' => 15,
        ];
        $request_args = $this->add_basic_auth_from_url($endpoint, $request_args);
        $response = wp_remote_get($endpoint, $request_args);

        if (is_wp_error($response)) {
            $this->log_connection('get_packages', false, ['error' => $response->get_error_message()]);
            return $response;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($response_code !== 200 || !isset($body['data']['packages'])) {
            $this->log_connection('get_packages', false, ['response_code' => $response_code]);
            return new \WP_Error('packages_error', __('Failed to retrieve packages list', 'transjt-ai'));
        }

        $this->log_connection('get_packages', true);
        return $body['data']['packages'];
    }

    public function get_package_details($package_id) {
        $access_key = $this->config->get_access_key();
        if (empty($access_key)) {
            return new \WP_Error('no_access_key', __('No access key configured', 'transjt-ai'));
        }

        $endpoint = TRANSJT_PACKAGES_ENDPOINT . '/' . rawurlencode($package_id);
        $request_args = [
            'headers' => [
                'Content-Type'         => 'application/json',
                'X-Transjt-Access-Key' => $access_key,
            ],
            'timeout' => 15,
        ];
        $request_args = $this->add_basic_auth_from_url($endpoint, $request_args);
        $response = wp_remote_get($endpoint, $request_args);

        if (is_wp_error($response)) {
            $this->log_connection('get_package_details', false, ['error' => $response->get_error_message()]);
            return $response;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($response_code !== 200 || empty($body['data'])) {
            $this->log_connection('get_package_details', false, ['response_code' => $response_code, 'package_id' => $package_id]);
            return new \WP_Error('package_error', __('Failed to retrieve package details', 'transjt-ai'));
        }

        $this->log_connection('get_package_details', true, ['package_id' => $package_id]);
        return $body['data'];
    }

    public function acknowledge_installation($package_id, $status, $error = null, $report = null) {
        $access_key = $this->config->get_access_key();
        if (empty($access_key)) {
            return false;
        }

        $body = ['status' => $status];
        if ($error !== null) {
            $body['error'] = $error;
        }
        if ($report !== null) {
            $body['report'] = $report;
        }

        $endpoint = TRANSJT_PACKAGES_ENDPOINT . '/' . rawurlencode($package_id);
        $request_args = [
            'headers' => [
                'Content-Type'         => 'application/json',
                'X-Transjt-Access-Key' => $access_key,
            ],
            'body'    => wp_json_encode($body),
            'timeout' => 15,
        ];
        $request_args = $this->add_basic_auth_from_url($endpoint, $request_args);
        $response = wp_remote_post($endpoint, $request_args);

        $success = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
        $this->log_connection('acknowledge_installation', $success, ['package_id' => $package_id, 'status' => $status]);
        return $success;
    }

    public function delete_package($package_id) {
        $access_key = $this->config->get_access_key();
        if (empty($access_key)) {
            return false;
        }

        $endpoint = TRANSJT_PACKAGES_ENDPOINT . '/' . rawurlencode($package_id);
        $request_args = [
            'method'  => 'DELETE',
            'headers' => [
                'X-Transjt-Access-Key' => $access_key,
            ],
            'timeout' => 15,
        ];
        $request_args = $this->add_basic_auth_from_url($endpoint, $request_args);
        $response = wp_remote_request($endpoint, $request_args);

        $success = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
        $this->log_connection('delete_package', $success, ['package_id' => $package_id]);
        return $success;
    }
}
