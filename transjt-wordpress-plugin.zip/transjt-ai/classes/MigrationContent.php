<?php
namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

/**
 * a site migration's content, written by the backend after the theme deploy. every item carries the backend's
 * id, so a rerun updates what it wrote and leaves alone what the site owner has since edited, published or trashed
 */
class MigrationContent {
    const META_ID = '_transjt_migration_id';
    const META_PATH = '_transjt_migration_path';
    const META_HASH = '_transjt_migration_hash';
    const META_FILE = '_transjt_migration_file';
    const META_AUTHOR = '_transjt_migration_author';
    const META_FORM = '_transjt_migration_form';
    const META_MENU = '_transjt_migration_menu';
    // the collection post types; this plugin registers them on every request
    const TYPES_OPTION = 'transjt_migration_types';
    // old address => new path, served on every front-end request
    const REDIRECTS_OPTION = 'transjt_migration_redirects';
    const MAX_ITEMS = 50;
    const MAX_REDIRECTS_PER_CALL = 1000;
    const MAX_REDIRECTS = 20000;
    const FORM_FIELD_TYPES = [
        'text' => 'text', 'email' => 'email', 'tel' => 'tel', 'url' => 'url', 'number' => 'number', 'date' => 'date',
        'textarea' => 'textarea', 'select' => 'select', 'checkbox' => 'checkbox', 'radio' => 'radio', 'file' => 'file',
    ];

    private $logger;

    public function __construct(?Logger $logger = null) {
        $this->logger = $logger;

        add_action('init', [$this, 'register_types']);
        add_filter('pll_get_post_types', [$this, 'translated_types']);
        add_action('template_redirect', [$this, 'redirect'], 1);
    }

    public function register_types() {
        $types = get_option(self::TYPES_OPTION, false);
        // a missing option is a query on every request: stored empty and autoloaded, a site that never moved reads it
        // with the other options
        if ($types === false) {
            self::add_types_option();
            return;
        }
        foreach ((array) $types as $key => $type) {
            if (post_type_exists($key)) {
                continue;
            }
            register_post_type($key, [
                'labels'       => ['name' => $type['label'], 'singular_name' => $type['label']],
                'public'       => true,
                'show_in_rest' => true,
                'has_archive'  => false,
                'hierarchical' => false,
                'menu_icon'    => 'dashicons-portfolio',
                // WP_Rewrite reads every %xx of a percent-encoded slug as a rewrite tag, and matches a request decoded too
                'rewrite'      => ['slug' => urldecode($type['slug']), 'with_front' => false],
                'supports'     => ['title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'revisions'],
            ]);
        }
    }

    public static function add_types_option() {
        add_option(self::TYPES_OPTION, [], '', true);
    }

    // Polylang translates a plugin's post types only when asked to
    public function translated_types($types) {
        foreach (array_keys((array) get_option(self::TYPES_OPTION, [])) as $key) {
            $types[$key] = $key;
        }
        return $types;
    }

    /**
     * 301 for an old address that has a counterpart at another path or on another site, the address with its
     * query first; only where WordPress found no page, so a redirect never hides one
     */
    public function redirect() {
        if (!is_404()) {
            return;
        }
        $map = get_option(self::REDIRECTS_OPTION);
        if (!$map || !is_array($map)) {
            return;
        }
        $uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only compared with the stored map keys
        $with_query = self::redirect_key($uri);
        $path = self::redirect_key((string) strtok($uri, '?'));
        $to = $map[$with_query] ?? ($map[$path] ?? null);
        if (!$to || ($to[0] === '/' && self::redirect_key($to) === $path)) {
            return;
        }
        wp_redirect($to, 301, 'transjt.ai'); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- targets come only from the access-key route, other sites included
        exit;
    }

    public static function redirect_key($address) {
        $parts = wp_parse_url((string) $address);
        $path = '/' . trim(rawurldecode($parts['path'] ?? ''), '/');
        return isset($parts['query']) && $parts['query'] !== '' ? $path . '?' . $parts['query'] : $path;
    }

    /**
     * POST migration/media { items: [{ id, filename, data? }] } - data: the file in base64. an id already uploaded
     * answers its attachment without data; a missing one asked without data answers null
     */
    public function handle_media($request) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        wp_raise_memory_limit('image');
        // as the core upgrader gives an install: one large image alone can outlast the host's default limit
        @set_time_limit(300); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

        return $this->batch($request, '/migration/media', 'files', function ($id, $item) {
            $attachment_id = $this->find_post('attachment', self::META_FILE, $id);
            if (!$attachment_id && isset($item['data'])) {
                $attachment_id = $this->save_media($id, $item);
            }
            if (is_wp_error($attachment_id) || !$attachment_id) {
                return $attachment_id ?: null;
            }
            return ['attachmentId' => $attachment_id, 'url' => wp_get_attachment_url($attachment_id)];
        });
    }

    /**
     * POST migration/authors { items: [{ id, name, slug? }] }
     */
    public function handle_authors($request) {
        return $this->batch($request, '/migration/authors', 'authors', [$this, 'save_author']);
    }

    /**
     * POST migration/terms { items: [{ id, taxonomy: category|post_tag, name, slug?, lang? }] } - answers each
     * one's term and its archive path
     */
    public function handle_terms($request) {
        return $this->batch($request, '/migration/terms', 'terms', [$this, 'save_term']);
    }

    /**
     * POST migration/types { items: [{ id, label, path }] } - one post type per collection, its
     * entries at {path}/{slug}; answers the post type of each collection
     */
    public function handle_types($request) {
        $items = $this->items($request, self::MAX_ITEMS);
        if (is_wp_error($items)) {
            return $items;
        }

        $before = (array) get_option(self::TYPES_OPTION, []);
        // a key register_post_type() rewrites (3.3.0 made one of a slug in another script) never held a post: made again
        $types = array_filter($before, function ($key) {
            return $key === sanitize_key($key);
        }, ARRAY_FILTER_USE_KEY);
        $keys = [];
        foreach ($items as $item) {
            $id = $this->item_id($item);
            $slug = implode('/', array_filter(array_map('sanitize_title', explode('/', (string) ($item['path'] ?? '')))));
            if ($id === null || $slug === '') {
                continue;
            }
            $key = $this->type_key($types, $id, $slug);
            $types[$key] = [
                'id'    => $id,
                'label' => sanitize_text_field((string) ($item['label'] ?? '')) ?: $slug,
                'slug'  => $slug,
            ];
            $keys[$id] = $key;
        }

        if ($types !== $before) {
            update_option(self::TYPES_OPTION, $types, true);
            $this->register_types();
            flush_rewrite_rules();
        }

        return rest_ensure_response(['status' => 'OK', 'data' => ['types' => (object) $keys]]);
    }

    /**
     * POST migration/posts { items: [{ id, type, slug, path, status?, lang?, translationOf?, title, content | texts,
     * excerpt?, date?, authorId?, categoryIds?, tagIds?, imageId? }] } - drafts unless status is publish; texts instead
     * of content copies the main page with its texts translated. answers each one's post, its status and its path
     */
    public function handle_posts($request) {
        require_once ABSPATH . 'wp-admin/includes/post.php';
        // the content is the site's own, moved as it was; the access key already installs whole themes
        kses_remove_filters();
        return $this->batch($request, '/migration/posts', 'posts', [$this, 'save_post']);
    }

    /**
     * POST migration/forms { items: [{ id, name, fields: [{ name, type, label, required?, options?: [{ label, value }], placeholder? }], submit?, mailTo?, pages? }] }
     * - pages: the old paths the form was on; answers the ones whose page has it in a form block (placed)
     */
    public function handle_forms($request) {
        if (!class_exists('WPCF7_ContactForm') || !function_exists('wpcf7_save_contact_form')) {
            return new \WP_Error('CF7_MISSING', __('Contact Form 7 is not active', 'transjt-ai'), ['status' => 409]);
        }
        // a theme deployed before Contact Form 7 came in has not created its own forms yet
        if (strpos(get_stylesheet(), 'tj-') === 0) {
            Helper::run_cf7_setup(get_template_directory());
        }
        // a page a form is set in is the theme's own markup, saved as it was
        kses_remove_filters();
        return $this->batch($request, '/migration/forms', 'forms', [$this, 'save_form'], true);
    }

    /**
     * POST migration/menus { items: [{ id, name, lang?, items: [{ label, path?, url?, children? }] }] } - menus no
     * theme location shows until the site owner assigns them in Appearance > Menus
     */
    public function handle_menus($request) {
        return $this->batch($request, '/migration/menus', 'menus', [$this, 'save_menu']);
    }

    /**
     * POST migration/redirects { items: [{ from, to }] } - from: an old address, to: a path on this site. answers
     * created, updated, existing or skipped (the home page, a target off this site, a redirect to itself) per from
     */
    public function handle_redirects($request) {
        $items = $this->items($request, self::MAX_REDIRECTS_PER_CALL);
        if (is_wp_error($items)) {
            return $items;
        }

        $map = (array) get_option(self::REDIRECTS_OPTION, []);
        $results = [];
        foreach ($items as $item) {
            $given = (string) ($item['from'] ?? '');
            $from = self::redirect_key($given);
            $to = $this->redirect_target($item['to'] ?? '');
            if ($from === '/' || $to === null || ($to[0] === '/' && self::redirect_key($to) === $from) || (!isset($map[$from]) && count($map) >= self::MAX_REDIRECTS)) {
                $results[$given] = 'skipped';
                continue;
            }
            $results[$given] = !isset($map[$from]) ? 'created' : ($map[$from] === $to ? 'existing' : 'updated');
            $map[$from] = $to;
        }
        update_option(self::REDIRECTS_OPTION, $map, false);

        $this->log('/migration/redirects', ['redirects' => count($results)]);
        return rest_ensure_response(['status' => 'OK', 'data' => ['redirects' => (object) $results]]);
    }

    private function save_media($id, array $item) {
        $bytes = base64_decode((string) $item['data'], true);
        if ($bytes === false || $bytes === '') {
            return new \WP_Error('INVALID_FILE', __('The file is not valid base64', 'transjt-ai'));
        }
        $filename = sanitize_file_name((string) ($item['filename'] ?? '')) ?: 'file';
        $tmp = wp_tempnam($filename);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- temp file handed to media_handle_sideload()
        if (!$tmp || file_put_contents($tmp, $bytes) === false) {
            return new \WP_Error('WRITE_FAILED', __('Could not stage the file', 'transjt-ai'));
        }

        if (strtolower(pathinfo($filename, PATHINFO_EXTENSION)) === 'svg') {
            $clean = Helper::sanitize_svg_content($bytes);
            if (is_wp_error($clean)) {
                unlink($tmp); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
                return $clean;
            }
            file_put_contents($tmp, $clean); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        }

        $attachment_id = media_handle_sideload(['name' => $filename, 'tmp_name' => $tmp], 0);
        if (is_wp_error($attachment_id)) {
            if (file_exists($tmp)) unlink($tmp); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
            return $attachment_id;
        }
        update_post_meta($attachment_id, self::META_FILE, $id);
        return $attachment_id;
    }

    private function save_post($id, array $item) {
        $type = (string) ($item['type'] ?? 'post');
        if (!in_array($type, array_merge(['post', 'page'], array_keys((array) get_option(self::TYPES_OPTION, []))), true) || !post_type_exists($type)) {
            // translators: %s: Post type.
            return new \WP_Error('INVALID_TYPE', sprintf(__('Unknown post type %s', 'transjt-ai'), $type));
        }

        $status = ($item['status'] ?? '') === 'publish' ? 'publish' : 'draft';
        $existing = $this->find_post($type, self::META_ID, $id);
        if ($existing && $this->changed_on_site($existing, $status)) {
            return ['postId' => $existing, 'status' => 'kept', 'path' => $this->draft_path($existing)];
        }

        $lang = isset($item['lang']) ? strtolower((string) $item['lang']) : null;
        $main_id = !empty($item['translationOf']) ? $this->main_post($type, (string) $item['translationOf']) : 0;
        $content = (string) ($item['content'] ?? '');
        $parent_id = 0;
        // a translated page: the main page as it is on this site, with the translation's texts
        if (!isset($item['content']) && isset($item['texts'])) {
            if (!$main_id) {
                return new \WP_Error('MAIN_PAGE_NOT_FOUND', __('The page this one translates is not on the site', 'transjt-ai'));
            }
            $content = $this->translate_content(get_post_field('post_content', $main_id, 'raw'), (array) $item['texts']);
            $main_parent = (int) get_post_field('post_parent', $main_id);
            if ($main_parent && $lang && function_exists('pll_get_post')) {
                $parent_id = (int) (pll_get_post($main_parent, $lang) ?: 0);
            }
        }

        $postarr = [
            'post_type'    => $type,
            'post_status'  => $status,
            'post_title'   => sanitize_text_field((string) ($item['title'] ?? '')),
            'post_name'    => sanitize_title((string) ($item['slug'] ?? '')),
            'post_content' => $content,
            'post_excerpt' => (string) ($item['excerpt'] ?? ''),
            'post_author'  => $this->post_author($item['authorId'] ?? 0),
            'post_parent'  => $parent_id,
        ];
        // WordPress makes a draft's slug unique only on publish, so a translation sharing it would move the path of the first
        if ($postarr['post_name'] !== '') {
            $postarr['post_name'] = wp_unique_post_slug($postarr['post_name'], $existing, 'publish', $type, $postarr['post_parent']);
        }
        $date = isset($item['date']) ? strtotime((string) $item['date']) : false;
        if ($date) {
            // a draft keeps a date only with its gmt part, and keeps it when published
            $postarr['post_date_gmt'] = gmdate('Y-m-d H:i:s', $date);
            $postarr['post_date'] = get_date_from_gmt($postarr['post_date_gmt']);
        }
        if ($existing) {
            $postarr['ID'] = $existing;
        }

        $post_id = $existing ? wp_update_post(wp_slash($postarr), true) : wp_insert_post(wp_slash($postarr), true);
        if (is_wp_error($post_id)) {
            return $post_id;
        }

        update_post_meta($post_id, self::META_ID, $id);
        update_post_meta($post_id, self::META_PATH, (string) ($item['path'] ?? ''));
        update_post_meta($post_id, self::META_HASH, md5(get_post_field('post_content', $post_id, 'raw')));

        MigrationSite::set_post_language($post_id, $type, $lang, $main_id);

        $this->assign_terms($post_id, 'category', $item['categoryIds'] ?? []);
        $this->assign_terms($post_id, 'post_tag', $item['tagIds'] ?? []);
        if (!empty($item['imageId']) && get_post_type((int) $item['imageId']) === 'attachment') {
            set_post_thumbnail($post_id, (int) $item['imageId']);
        }

        return ['postId' => $post_id, 'status' => $existing ? 'updated' : 'created', 'path' => $this->draft_path($post_id)];
    }

    // the migrated item with that id, else for a page the theme's page at that path
    private function main_post($type, $key) {
        $post_id = $this->find_post($type, self::META_ID, $key);
        if (!$post_id && $type === 'page') {
            $page = $this->theme_page($key);
            $post_id = $page ? $page->ID : 0;
        }
        return $post_id;
    }

    // the theme's page at a path, the front page for /
    private function theme_page($path) {
        $path = trim($path, '/');
        $front = (int) get_option('page_on_front');
        return $path === '' ? ($front ? get_post($front) : null) : get_page_by_path($path, OBJECT, 'page');
    }

    /**
     * swap each [main text, translation] pair, in document order, where a whole text node or a whole string
     * attribute of a block reads as the main text; a text with fewer pairs than places keeps its last one
     */
    private function translate_content($content, array $texts) {
        $queue = [];
        foreach ($texts as $pair) {
            if (is_array($pair) && count($pair) === 2) {
                $from = $this->visible_text((string) $pair[0]);
                if ($from !== '') {
                    $queue[$from][] = (string) $pair[1];
                }
            }
        }
        if (!$queue) {
            return $content;
        }
        return serialize_blocks($this->translate_blocks(parse_blocks($content), $queue));
    }

    private function translate_blocks(array $blocks, array &$queue) {
        foreach ($blocks as &$block) {
            if (!empty($block['attrs'])) {
                $block['attrs'] = $this->translate_value($block['attrs'], $queue);
            }
            // a theme's block keeps its texts as its attributes' defaults, which the page does not write: a default that
            // translates goes into the translated page
            $type = !empty($block['blockName']) ? \WP_Block_Type_Registry::get_instance()->get_registered($block['blockName']) : null;
            foreach ((array) ($type->attributes ?? []) as $name => $schema) {
                if (array_key_exists($name, (array) $block['attrs']) || !isset($schema['default'])) {
                    continue;
                }
                $translated = $this->translate_value($schema['default'], $queue);
                if ($translated !== $schema['default']) {
                    $block['attrs'][$name] = $translated;
                }
            }
            foreach ($block['innerContent'] as &$chunk) {
                if (is_string($chunk)) {
                    $chunk = $this->translate_html($chunk, $queue);
                }
            }
            unset($chunk);
            $block['innerBlocks'] = $this->translate_blocks($block['innerBlocks'], $queue);
        }
        unset($block);
        return $blocks;
    }

    private function translate_value($value, array &$queue) {
        if (is_array($value)) {
            foreach ($value as $key => $inner) {
                $value[$key] = $this->translate_value($inner, $queue);
            }
            return $value;
        }
        if (!is_string($value) || $value === '') {
            return $value;
        }
        if (strpos($value, '<') !== false) {
            return $this->translate_html($value, $queue);
        }
        $translation = $this->next_translation($this->visible_text($value), $queue);
        return $translation === null ? $value : $translation;
    }

    private function translate_html($html, array &$queue) {
        $parts = preg_split('/(<[^>]*>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
        $in_script = false;
        foreach ($parts as $i => $part) {
            if ($part !== '' && $part[0] === '<') {
                $in_script = (bool) preg_match('/^<(script|style)\b/i', $part) || ($in_script && !preg_match('/^<\/(script|style)/i', $part));
                continue;
            }
            if ($in_script || trim($part) === '') {
                continue;
            }
            $translation = $this->next_translation($this->visible_text(html_entity_decode($part, ENT_QUOTES | ENT_HTML5, 'UTF-8')), $queue);
            if ($translation !== null) {
                preg_match('/^(\s*).*?(\s*)$/su', $part, $space);
                $parts[$i] = $space[1] . esc_html($translation) . $space[2];
            }
        }
        return implode('', $parts);
    }

    private function next_translation($text, array &$queue) {
        if (!isset($queue[$text])) {
            return null;
        }
        return count($queue[$text]) > 1 ? array_shift($queue[$text]) : $queue[$text][0];
    }

    private function visible_text($text) {
        return trim((string) preg_replace('/\s+/u', ' ', $text));
    }

    /**
     * published, trashed or edited since the last run: the site owner's now. a draft of an earlier run is still this
     * plugin's, so an item now sent published goes live
     */
    private function changed_on_site($post_id, $status) {
        $post = get_post($post_id);
        return !$post || !in_array($post->post_status, ['draft', $status], true) || get_post_meta($post_id, self::META_HASH, true) !== md5($post->post_content);
    }

    // the path the draft gets when it is published; none for a trashed one
    private function draft_path($post_id) {
        if (get_post_status($post_id) === 'trash') {
            return null;
        }
        list($permalink, $name) = get_sample_permalink($post_id);
        $url = str_replace(['%pagename%', '%postname%'], $name, $permalink);
        return wp_make_link_relative($url);
    }

    /**
     * a user per author: the one this plugin made before, else one with that display name, else a new
     * Author with no email and a random password
     */
    private function save_author($id, array $item) {
        $name = sanitize_text_field((string) ($item['name'] ?? ''));
        if ($name === '') {
            return new \WP_Error('INVALID_AUTHOR', __('An author needs a name', 'transjt-ai'));
        }

        $users = get_users(['meta_key' => self::META_AUTHOR, 'meta_value' => $id, 'number' => 1, 'fields' => 'ID']); // phpcs:ignore WordPress.DB.SlowDBQuery
        if (!$users) {
            $users = get_users(['search' => $name, 'search_columns' => ['display_name'], 'number' => 1, 'fields' => 'ID']);
        }
        if ($users) {
            update_user_meta((int) $users[0], self::META_AUTHOR, $id);
            return ['userId' => (int) $users[0], 'status' => 'existing'];
        }

        $login = sanitize_user((string) ($item['slug'] ?? '') ?: $name, true) ?: 'author';
        $base = $login;
        for ($i = 2; username_exists($login); $i++) {
            $login = $base . '-' . $i;
        }
        $user_id = wp_insert_user([
            'user_login'   => $login,
            'user_pass'    => wp_generate_password(32, true, true),
            'display_name' => $name,
            'nickname'     => $name,
            'role'         => 'author',
        ]);
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        update_user_meta($user_id, self::META_AUTHOR, $id);
        return ['userId' => $user_id, 'status' => 'created'];
    }

    private function post_author($author_id) {
        if ($author_id && get_userdata((int) $author_id)) {
            return (int) $author_id;
        }
        if (get_current_user_id()) {
            return get_current_user_id();
        }
        $admins = get_users(['role' => 'administrator', 'orderby' => 'ID', 'order' => 'ASC', 'number' => 1, 'fields' => 'ID']);
        return $admins ? (int) $admins[0] : 0;
    }

    private function assign_terms($post_id, $taxonomy, $term_ids) {
        if (!is_array($term_ids) || !$term_ids || !is_object_in_taxonomy(get_post_type($post_id), $taxonomy)) {
            return;
        }
        $ids = [];
        foreach ($term_ids as $term_id) {
            $term = get_term((int) $term_id, $taxonomy);
            if ($term && !is_wp_error($term)) {
                $ids[] = (int) $term->term_id;
            }
        }
        wp_set_object_terms($post_id, $ids, $taxonomy);
    }

    /**
     * the term this plugin made before, else one of that name in the language, else a new one; with
     * Polylang free two languages cannot share a slug, so a translation's gets the language appended
     */
    private function save_term($id, array $item) {
        $taxonomy = (string) ($item['taxonomy'] ?? '');
        $name = sanitize_text_field((string) ($item['name'] ?? ''));
        $lang = isset($item['lang']) ? strtolower((string) $item['lang']) : null;
        if (!in_array($taxonomy, ['category', 'post_tag'], true) || $name === '') {
            return new \WP_Error('INVALID_TERM', __('A term needs a name and the taxonomy category or post_tag', 'transjt-ai'));
        }

        $found = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false, 'fields' => 'ids', 'lang' => '', 'meta_key' => self::META_ID, 'meta_value' => $id]); // phpcs:ignore WordPress.DB.SlowDBQuery
        $term_id = is_array($found) && $found ? (int) $found[0] : 0;
        if (!$term_id) {
            $named = get_terms(['taxonomy' => $taxonomy, 'name' => $name, 'hide_empty' => false, 'fields' => 'ids', 'lang' => '']);
            foreach (is_array($named) ? $named : [] as $candidate) {
                $term_lang = MigrationSite::term_language($candidate, $taxonomy);
                if (!$lang || $term_lang === null || $term_lang === $lang) {
                    $term_id = (int) $candidate;
                    break;
                }
            }
        }
        $status = $term_id ? 'existing' : 'created';

        if (!$term_id) {
            $slug = sanitize_title((string) ($item['slug'] ?? '') ?: $name);
            if ($lang && term_exists($slug, $taxonomy)) {
                $slug .= '-' . $lang;
            }
            $created = wp_insert_term($name, $taxonomy, ['slug' => $slug]);
            if (is_wp_error($created)) {
                return $created;
            }
            $term_id = (int) $created['term_id'];
            MigrationSite::set_term_language($term_id, $taxonomy, $lang);
        }
        update_term_meta($term_id, self::META_ID, $id);

        $link = get_term_link($term_id, $taxonomy);
        return ['termId' => $term_id, 'status' => $status, 'path' => is_wp_error($link) ? null : wp_make_link_relative($link)];
    }

    private function save_form($id, array $item) {
        $fields = array_values(array_filter((array) ($item['fields'] ?? []), 'is_array'));
        $pages = array_values(array_filter((array) ($item['pages'] ?? []), 'is_string'));
        $existing = $this->find_post('wpcf7_contact_form', self::META_FORM, $id);
        if ($existing && get_post_meta($existing, self::META_HASH, true) !== md5((string) get_post_meta($existing, '_form', true))) {
            return $this->form_result(\WPCF7_ContactForm::get_instance($existing), 'kept', $this->place_form($existing, $fields, $pages));
        }

        $title = sanitize_text_field((string) ($item['name'] ?? '')) ?: __('Contact form', 'transjt-ai');
        $mail = \WPCF7_ContactForm::get_template()->prop('mail');
        $mail['subject'] = '[_site_title] "' . $title . '"';
        $mail['body'] = $this->form_mail_body($fields);
        $reply_to = $this->form_reply_to($fields);
        $mail['additional_headers'] = $reply_to ? 'Reply-To: [' . $reply_to . ']' : '';
        // the address `PUT migration/forms` set (`mailTo`); else the site's admin address, as Contact Form 7's own template has it
        if (is_email((string) ($item['mailTo'] ?? ''))) {
            $mail['recipient'] = sanitize_email((string) $item['mailTo']);
        }

        $form = wpcf7_save_contact_form([
            'id'    => $existing ?: -1,
            'title' => $title,
            'form'  => $this->form_markup($fields, (string) ($item['submit'] ?? '')),
            'mail'  => $mail,
        ]);
        if (!$form || !$form->id()) {
            return new \WP_Error('FORM_SAVE_FAILED', __('Contact Form 7 did not save the form', 'transjt-ai'));
        }
        update_post_meta($form->id(), self::META_FORM, $id);
        update_post_meta($form->id(), self::META_HASH, md5((string) get_post_meta($form->id(), '_form', true)));
        // the saved object has no hash yet; the shortcode needs it
        return $this->form_result(\WPCF7_ContactForm::get_instance($form->id()), $existing ? 'updated' : 'created', $this->place_form($form->id(), $fields, $pages));
    }

    private function form_result($form, $status, array $placed) {
        return ['formId' => $form->id(), 'shortcode' => $form->shortcode(), 'status' => $status, 'placed' => $placed];
    }

    // the form set in a form block of each of its pages: a block that takes a Contact Form 7 form (cf7FormId) and has
    // none yet, the first whose own form sends every field this one has. a block in a template part (the header, the
    // footer) or a synced pattern is picked once in the editor. -> the paths whose page has it
    private function place_form($form_id, array $fields, array $paths) {
        $names = array_map([$this, 'form_field_name'], $fields);
        $placed = [];
        foreach ($names ? $paths : [] as $path) {
            $page = $this->form_page($path);
            if (!$page) {
                continue;
            }
            $blocks = parse_blocks($page->post_content);
            if (!$this->form_block($blocks, (int) $form_id, $names, false)) {
                if (!$this->form_block($blocks, (int) $form_id, $names, true)) {
                    continue;
                }
                $saved = wp_update_post(['ID' => $page->ID, 'post_content' => wp_slash(serialize_blocks($blocks))], true);
                if (!$saved || is_wp_error($saved)) {
                    continue;
                }
            }
            $placed[] = $path;
        }
        return $placed;
    }

    // the page at an old path: one the move made there (a translation), else the theme's
    private function form_page($path) {
        $post_id = $this->find_post('page', self::META_PATH, $path);
        $page = $post_id ? get_post($post_id) : $this->theme_page($path);
        return $page && $page->post_status !== 'trash' ? $page : null;
    }

    // $set false: whether a form block already has the form; $set true: the first form block without one whose own
    // form sends every one of $names takes it
    private function form_block(array &$blocks, $form_id, array $names, $set) {
        foreach ($blocks as &$block) {
            $type = $block['blockName'] ? \WP_Block_Type_Registry::get_instance()->get_registered($block['blockName']) : null;
            if ($type && isset($type->attributes['cf7FormId'])) {
                $current = (int) ($block['attrs']['cf7FormId'] ?? 0);
                if (!$set && $current === $form_id) {
                    return true;
                }
                if ($set && !$current && $this->sends_fields($this->block_markup($block), $names)) {
                    $block['attrs']['cf7FormId'] = $form_id;
                    return true;
                }
            }
            if (!empty($block['innerBlocks']) && $this->form_block($block['innerBlocks'], $form_id, $names, $set)) {
                return true;
            }
        }
        unset($block);
        return false;
    }

    // the block as its page prints it; what a theme's render echoes or throws stays out of this route's answer
    private function block_markup(array $block) {
        ob_start();
        try {
            $html = render_block($block);
        } catch (\Throwable $e) {
            $html = '';
        }
        return $html . ob_get_clean();
    }

    // the block's markup has a form with a control by each of these names (a group's name[] by its name)
    private function sends_fields($html, array $names) {
        if (stripos($html, '<form') === false || !preg_match_all('/<(?:input|select|textarea)\b[^>]*?(?<![\w-])name\s*=\s*(["\'])(.*?)\1/is', $html, $m)) {
            return false;
        }
        $sent = array_map(function ($name) {
            return preg_replace('/\[\]$/', '', html_entity_decode($name, ENT_QUOTES));
        }, $m[2]);
        return !array_diff($names, $sent);
    }

    private function form_markup(array $fields, $submit) {
        $lines = [];
        foreach ($fields as $field) {
            $type = self::FORM_FIELD_TYPES[strtolower((string) ($field['type'] ?? 'text'))] ?? 'text';
            $name = $this->form_field_name($field);
            $label = esc_html(sanitize_text_field((string) ($field['label'] ?? '')));
            $required = !empty($field['required']) ? '*' : '';
            $options = '';
            if (in_array($type, ['select', 'checkbox', 'radio'], true)) {
                // the visible label is what the form shows and the mail carries
                $choices = array_map(function ($option) {
                    return $this->form_value($option['label'] ?? '');
                }, (array) ($field['options'] ?? []));
                $options = ($type === 'select' ? '' : ' use_label_element') . ($choices ? ' "' . implode('" "', $choices) . '"' : '');
            } elseif (!empty($field['placeholder']) && !in_array($type, ['file', 'date'], true)) {
                $options = ' placeholder "' . $this->form_value($field['placeholder']) . '"';
            }
            $lines[] = '<label> ' . $label . "\n    [" . $type . $required . ' ' . $name . $options . '] </label>';
        }
        $lines[] = '[submit "' . ($this->form_value($submit) ?: esc_html__('Send', 'transjt-ai')) . '"]';
        return implode("\n\n", $lines);
    }

    private function form_mail_body(array $fields) {
        $lines = [];
        foreach ($fields as $field) {
            $type = self::FORM_FIELD_TYPES[strtolower((string) ($field['type'] ?? 'text'))] ?? 'text';
            if ($type !== 'file') {
                $label = sanitize_text_field((string) ($field['label'] ?? '')) ?: $this->form_field_name($field);
                $lines[] = $label . ': [' . $this->form_field_name($field) . ']';
            }
        }
        $lines[] = "\n-- \n" . __('This e-mail was sent from a contact form on [_site_title] ([_site_url])', 'transjt-ai');
        return implode("\n", $lines);
    }

    private function form_reply_to(array $fields) {
        foreach ($fields as $field) {
            if (strtolower((string) ($field['type'] ?? '')) === 'email') {
                return $this->form_field_name($field);
            }
        }
        return null;
    }

    // Contact Form 7 names start with a letter and hold letters, digits and -_:.
    private function form_field_name(array $field) {
        $name = preg_replace('/[^A-Za-z0-9:._-]+/', '-', (string) ($field['name'] ?? ''));
        $name = trim((string) $name, '-');
        if ($name === '') {
            $name = substr(md5((string) wp_json_encode($field)), 0, 6);
        }
        return preg_match('/^[A-Za-z]/', $name) ? $name : 'field-' . $name;
    }

    // a tag value cannot hold quotes or brackets
    private function form_value($value) {
        return trim(str_replace(['"', '[', ']'], '', sanitize_text_field((string) $value)));
    }

    private function save_menu($id, array $item) {
        $menus = get_terms(['taxonomy' => 'nav_menu', 'hide_empty' => false, 'meta_key' => self::META_MENU, 'meta_value' => $id, 'fields' => 'ids']); // phpcs:ignore WordPress.DB.SlowDBQuery
        $menu_id = is_array($menus) && $menus ? (int) $menus[0] : 0;

        if ($menu_id) {
            $current = $this->menu_items($menu_id);
            // in a theme location, or edited since the last run: the site owner's now
            if (in_array($menu_id, array_map('intval', get_nav_menu_locations()), true) || get_term_meta($menu_id, self::META_HASH, true) !== $this->menu_signature($current)) {
                return ['menuId' => $menu_id, 'status' => 'kept'];
            }
            foreach ($current as $menu_item) {
                wp_delete_post($menu_item->ID, true);
            }
        } else {
            $name = sanitize_text_field((string) ($item['name'] ?? '')) ?: __('Menu', 'transjt-ai');
            if (wp_get_nav_menu_object($name)) {
                $name .= ' (' . __('migrated', 'transjt-ai') . ')';
            }
            for ($i = 2; wp_get_nav_menu_object($name); $i++) {
                $name = preg_replace('/ \d+$/', '', $name) . ' ' . $i;
            }
            $menu_id = wp_create_nav_menu($name);
            if (is_wp_error($menu_id)) {
                return $menu_id;
            }
            add_term_meta($menu_id, self::META_MENU, $id, true);
        }

        $this->add_menu_items($menu_id, (array) ($item['items'] ?? []), 0, isset($item['lang']) ? strtolower((string) $item['lang']) : null);
        update_term_meta($menu_id, self::META_HASH, $this->menu_signature($this->menu_items($menu_id)));
        return ['menuId' => $menu_id, 'status' => $menus ? 'updated' : 'created'];
    }

    // the statuses core itself lists menu items with; 'any' finds none
    private function menu_items($menu_id) {
        return wp_get_nav_menu_items($menu_id, ['post_status' => 'publish,draft']) ?: [];
    }

    private function menu_signature(array $items) {
        return md5((string) wp_json_encode(array_map(function ($menu_item) {
            return [$menu_item->ID, $menu_item->title, $menu_item->url, (int) $menu_item->menu_item_parent, (int) $menu_item->menu_order];
        }, $items)));
    }

    private function add_menu_items($menu_id, array $items, $parent_id, $lang, &$position = 0) {
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }
            // a menu of draft items reads as empty and core deletes such items after a week, so the
            // items are published and the menu stays a draft by having no theme location
            $args = array_merge($this->menu_target($item, $lang), [
                'menu-item-title'     => sanitize_text_field((string) ($item['label'] ?? '')),
                'menu-item-status'    => 'publish',
                'menu-item-parent-id' => $parent_id,
                'menu-item-position'  => ++$position,
            ]);
            $item_id = wp_update_nav_menu_item($menu_id, 0, $args);
            if (is_wp_error($item_id)) {
                continue;
            }
            $this->add_menu_items($menu_id, (array) ($item['children'] ?? []), $item_id, $lang, $position);
        }
    }

    // a page or post of this site where one has the old path, else a link
    private function menu_target(array $item, $lang) {
        $path = isset($item['path']) ? (string) $item['path'] : '';
        if ($path !== '') {
            $post_id = $this->find_post('any', self::META_PATH, $path);
            if (!$post_id) {
                $page = get_page_by_path(trim($path, '/'), OBJECT, 'page');
                $post_id = $page ? $page->ID : 0;
            }
            if ($post_id && $lang && function_exists('pll_get_post')) {
                $post_id = pll_get_post($post_id, $lang) ?: $post_id;
            }
            if ($post_id) {
                return ['menu-item-type' => 'post_type', 'menu-item-object' => get_post_type($post_id), 'menu-item-object-id' => $post_id];
            }
            return ['menu-item-type' => 'custom', 'menu-item-url' => $path];
        }
        return ['menu-item-type' => 'custom', 'menu-item-url' => esc_url_raw((string) ($item['url'] ?? '#'))];
    }

    // a path on this site, or an http(s) address on another site; one on this site's host becomes its path
    private function redirect_target($to) {
        $to = trim((string) $to);
        if ($to === '') {
            return null;
        }
        $parts = wp_parse_url($to);
        if (isset($parts['host'])) {
            if (strtolower($parts['host']) !== strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST))) {
                return in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true) ? (esc_url_raw($to) ?: null) : null;
            }
            $to = ($parts['path'] ?? '/') . (isset($parts['query']) ? '?' . $parts['query'] : '') . (isset($parts['fragment']) ? '#' . $parts['fragment'] : '');
        }
        return strpos($to, '/') === 0 && strpos($to, '//') !== 0 ? $to : null;
    }

    private function type_key(array $types, $id, $slug) {
        foreach ($types as $key => $type) {
            if (($type['id'] ?? null) === $id) {
                return $key;
            }
        }
        // post type keys are at most 20 characters, and register_post_type() keeps only a-z, 0-9, _ and - of one: a slug in
        // another script (percent-encoded by sanitize_title) gives way to its hash, or no post would find its type
        $name = str_replace(['/', '-'], '_', $slug);
        $base = substr('tj_' . (preg_match('/^[a-z0-9_]+$/', $name) ? $name : substr(md5($slug), 0, 12)), 0, 20);
        $key = $base;
        for ($i = 2; isset($types[$key]) || post_type_exists($key); $i++) {
            $key = substr($base, 0, 20 - strlen((string) $i)) . $i;
        }
        return $key;
    }

    private function find_post($type, $meta_key, $value) {
        $ids = get_posts([
            'post_type'        => $type,
            'post_status'      => array_keys(get_post_stati()),
            'meta_key'         => $meta_key, // phpcs:ignore WordPress.DB.SlowDBQuery
            'meta_value'       => $value, // phpcs:ignore WordPress.DB.SlowDBQuery
            'fields'           => 'ids',
            'posts_per_page'   => 1,
            'no_found_rows'    => true,
            'suppress_filters' => true,
            'lang'             => '',
        ]);
        return $ids ? (int) $ids[0] : 0;
    }

    // one save per item; an item that fails is answered under errors and the rest still go through
    private function batch($request, $route, $key, callable $save, $allow_empty = false) {
        $items = $this->items($request, self::MAX_ITEMS, $allow_empty);
        if (is_wp_error($items)) {
            return $items;
        }
        $done = [];
        $errors = [];
        foreach ($items as $item) {
            $id = $this->item_id($item);
            if ($id === null) {
                continue;
            }
            $result = $save($id, $item);
            if (is_wp_error($result)) {
                $errors[$id] = $result->get_error_code() . ': ' . $result->get_error_message();
            } else {
                $done[$id] = $result;
            }
        }
        $this->log($route, [$key => count($done), 'errors' => count($errors)]);
        return rest_ensure_response(['status' => 'OK', 'data' => [$key => (object) $done, 'errors' => (object) $errors]]);
    }

    private function items($request, $max, $allow_empty = false) {
        $items = $request->get_param('items');
        if (!is_array($items) || (!$items && !$allow_empty)) {
            return new \WP_Error('rest_error', __('Invalid request: items must be a non-empty array', 'transjt-ai'), ['status' => 400]);
        }
        if (count($items) > $max) {
            return new \WP_Error('rest_error', __('Invalid request: too many items', 'transjt-ai'), ['status' => 400]);
        }
        return array_values(array_filter($items, 'is_array'));
    }

    private function item_id(array $item) {
        $id = isset($item['id']) ? (string) $item['id'] : '';
        return $id !== '' && strlen($id) <= 191 ? $id : null;
    }

    private function log($route, array $details) {
        if ($this->logger) {
            $this->logger->log_api($route, 'migration content written', $details);
        }
    }
}
