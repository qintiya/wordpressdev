<?php
namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

/**
 * what a site migration needs from the site before its content moves in: the site address for the
 * "not the live site" check, Contact Form 7, Polylang or WPML with the languages, post-name permalinks
 */
class MigrationSite {
    const POST_NAME_STRUCTURE = '/%postname%/';
    // the only plugins the backend may install
    const PLUGINS = [
        'contact-form-7' => 'contact-form-7/wp-contact-form-7.php',
        'polylang'       => 'polylang/polylang.php',
    ];
    // a bare language code names its main country, as Polylang's own list cannot tell en_US from en_AU
    const LOCALES = [
        'ar' => 'ar', 'cs' => 'cs_CZ', 'da' => 'da_DK', 'de' => 'de_DE', 'el' => 'el', 'en' => 'en_US',
        'es' => 'es_ES', 'fi' => 'fi', 'fr' => 'fr_FR', 'he' => 'he_IL', 'hu' => 'hu_HU', 'it' => 'it_IT',
        'ja' => 'ja', 'ko' => 'ko_KR', 'nb' => 'nb_NO', 'nl' => 'nl_NL', 'no' => 'nb_NO', 'pl' => 'pl_PL',
        'pt' => 'pt_PT', 'ro' => 'ro_RO', 'ru' => 'ru_RU', 'sk' => 'sk_SK', 'sv' => 'sv_SE', 'tr' => 'tr_TR',
        'uk' => 'uk', 'zh' => 'zh_CN',
    ];

    private $logger;

    public function __construct(?Logger $logger = null) {
        $this->logger = $logger;
    }

    /**
     * GET migration/site
     */
    public function handle_site($request) {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        return rest_ensure_response([
            'status' => 'OK',
            'data'   => [
                'siteUrl'      => get_site_url(),
                'homeUrl'      => home_url('/'),
                'version'      => TRANSJT_VERSION,
                'permalinks'   => (string) get_option('permalink_structure'),
                'plugins'      => [
                    'contact-form-7' => $this->plugin_info('contact-form-7'),
                    'polylang'       => $this->plugin_info('polylang'),
                ],
                'languages'    => self::languages(),
                'maxBodyBytes' => $this->max_body_bytes(),
            ],
        ]);
    }

    // installable: whether migration/plugins can make it active on this site
    private function plugin_info($slug) {
        $file = self::PLUGINS[$slug];
        $state = $this->plugin_state($file);
        if ($state === 'active') {
            return ['state' => $state, 'installable' => true];
        }
        if ($state === 'inactive') {
            return ['state' => $state, 'installable' => !is_wp_error(validate_plugin_requirements($file))];
        }
        return ['state' => $state, 'installable' => $this->can_install_plugins() && !is_wp_error($this->plugin_download($slug))];
    }

    /**
     * POST migration/plugins { slug } - install from wordpress.org when missing, then activate
     */
    public function handle_plugin($request) {
        $slug = (string) $request->get_param('slug');
        if (!isset(self::PLUGINS[$slug])) {
            return new \WP_Error('INVALID_PLUGIN', __('This plugin cannot be installed by transjt.ai', 'transjt-ai'), ['status' => 400]);
        }
        $file = self::PLUGINS[$slug];

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        if (is_plugin_active($file)) {
            return rest_ensure_response(['status' => 'OK']);
        }

        $installed = false;
        if (!isset(get_plugins()[$file])) {
            if (!$this->can_install_plugins()) {
                return new \WP_Error('PLUGIN_INSTALL_BLOCKED', __('This site does not allow plugins to be installed from code', 'transjt-ai'), ['status' => 409]);
            }
            $result = $this->install_plugin($slug);
            if (is_wp_error($result)) {
                return $result;
            }
            $installed = true;
        }

        $activated = activate_plugin($file);
        if (is_wp_error($activated)) {
            return new \WP_Error('PLUGIN_ACTIVATION_FAILED', $activated->get_error_message(), ['status' => 500]);
        }

        if ($this->logger) {
            $this->logger->log_api('/migration/plugins', 'plugin ready', ['slug' => $slug, 'installed' => $installed]);
        }

        return rest_ensure_response(['status' => 'OK']);
    }

    /**
     * POST migration/permalinks - post-name permalinks
     */
    public function handle_permalinks($request) {
        global $wp_rewrite;
        if (get_option('permalink_structure') !== self::POST_NAME_STRUCTURE) {
            require_once ABSPATH . 'wp-admin/includes/misc.php';
            $wp_rewrite->set_permalink_structure(self::POST_NAME_STRUCTURE);
            flush_rewrite_rules();
        }
        return rest_ensure_response(['status' => 'OK']);
    }

    /**
     * POST migration/languages { main, languages: [{ code }] } - Polylang gets the languages it lacks, the main
     * one first so it becomes the default; WPML's are only read. answers the codes the site has
     */
    public function handle_languages($request) {
        $main = strtolower((string) $request->get_param('main'));
        $wanted = $request->get_param('languages');
        if (!$main || !is_array($wanted)) {
            return new \WP_Error('rest_error', __('Invalid request: main and languages required', 'transjt-ai'), ['status' => 400]);
        }

        $current = self::languages();
        if ($current['plugin'] === null) {
            return new \WP_Error('LANGUAGE_PLUGIN_MISSING', __('Neither Polylang nor WPML is active', 'transjt-ai'), ['status' => 409]);
        }

        $codes = [$main];
        foreach ($wanted as $language) {
            $code = strtolower((string) ($language['code'] ?? ''));
            if (preg_match('/^[a-z]{2,3}(-[a-z0-9]{2,8})?$/', $code)) {
                $codes[] = $code;
            }
        }
        $codes = array_values(array_unique($codes));

        if ($current['plugin'] === 'polylang') {
            $had_none = !$current['codes'];
            $added = [];
            foreach ($codes as $code) {
                if (in_array($code, $current['codes'], true)) {
                    continue;
                }
                $result = $this->add_polylang_language($code, count($current['codes']) + count($added));
                if (is_wp_error($result)) {
                    return $result;
                }
                $added[] = $code;
            }
            // what the deploy created before Polylang came in gets the main language
            if ($had_none && $added && method_exists(PLL()->model, 'set_language_in_mass')) {
                PLL()->model->clean_languages_cache();
                PLL()->model->set_language_in_mass();
            }
            $current = self::languages();
        }

        return rest_ensure_response(['status' => 'OK', 'data' => ['codes' => $current['codes']]]);
    }

    /**
     * ['plugin' => 'polylang'|'wpml'|null, 'default' => code|null, 'codes' => [code, ...]]
     */
    public static function languages() {
        if (function_exists('pll_languages_list')) {
            return [
                'plugin'  => 'polylang',
                'default' => pll_default_language() ?: null,
                'codes'   => array_values((array) pll_languages_list(['fields' => 'slug'])),
            ];
        }
        if (defined('ICL_SITEPRESS_VERSION')) {
            $active = apply_filters('wpml_active_languages', null, ['skip_missing' => 0]);
            return [
                'plugin'  => 'wpml',
                'default' => apply_filters('wpml_default_language', null) ?: null,
                'codes'   => array_values(array_map('strval', array_keys(is_array($active) ? $active : []))),
            ];
        }
        return ['plugin' => null, 'default' => null, 'codes' => []];
    }

    /**
     * give a post the language of the package item and join it to the translations of its main-language item
     */
    public static function set_post_language($post_id, $post_type, $lang, $main_post_id = 0) {
        $languages = self::languages();
        if (!$lang || !in_array($lang, $languages['codes'], true)) {
            return;
        }
        if ($languages['plugin'] === 'polylang') {
            pll_set_post_language($post_id, $lang);
            if ($main_post_id && $main_post_id !== $post_id) {
                $translations = pll_get_post_translations($main_post_id);
                $translations[$lang] = $post_id;
                pll_save_post_translations($translations);
            }
        } elseif ($languages['plugin'] === 'wpml') {
            $element_type = 'post_' . $post_type;
            $trid = $main_post_id ? apply_filters('wpml_element_trid', null, $main_post_id, $element_type) : null;
            do_action('wpml_set_element_language_details', [
                'element_id'           => $post_id,
                'element_type'         => $element_type,
                'trid'                 => $trid ?: false,
                'language_code'        => $lang,
                'source_language_code' => $trid ? $languages['default'] : null,
            ]);
        }
    }

    public static function set_term_language($term_id, $taxonomy, $lang) {
        $languages = self::languages();
        if (!$lang || !in_array($lang, $languages['codes'], true)) {
            return;
        }
        if ($languages['plugin'] === 'polylang') {
            pll_set_term_language($term_id, $lang);
        } elseif ($languages['plugin'] === 'wpml') {
            $term = get_term($term_id, $taxonomy);
            if ($term && !is_wp_error($term)) {
                do_action('wpml_set_element_language_details', [
                    'element_id'    => $term->term_taxonomy_id,
                    'element_type'  => 'tax_' . $taxonomy,
                    'trid'          => false,
                    'language_code' => $lang,
                ]);
            }
        }
    }

    /**
     * the language of a term, null when no language plugin knows it
     */
    public static function term_language($term_id, $taxonomy) {
        $languages = self::languages();
        if ($languages['plugin'] === 'polylang') {
            return pll_get_term_language($term_id) ?: null;
        }
        if ($languages['plugin'] === 'wpml') {
            $term = get_term($term_id, $taxonomy);
            $details = $term && !is_wp_error($term)
                ? apply_filters('wpml_element_language_details', null, ['element_id' => $term->term_taxonomy_id, 'element_type' => $taxonomy])
                : null;
            return $details->language_code ?? null;
        }
        return null;
    }

    private function add_polylang_language($code, $order) {
        $parts = explode('-', $code);
        $locale = count($parts) > 1 ? $parts[0] . '_' . strtoupper($parts[1]) : (self::LOCALES[$code] ?? $code);
        $predefined = $this->polylang_predefined($locale);
        $args = [
            'name'       => (string) ($predefined['name'] ?? strtoupper($code)),
            'slug'       => $code,
            'locale'     => $locale,
            'rtl'        => ($predefined['dir'] ?? '') === 'rtl',
            'term_group' => $order,
        ];
        if (!empty($predefined['flag'])) {
            $args['flag'] = (string) $predefined['flag'];
        }

        $model = PLL()->model;
        if (isset($model->languages) && is_object($model->languages) && method_exists($model->languages, 'add')) {
            $result = $model->languages->add($args);
        } else {
            // before Polylang 3.7 only the admin model adds languages
            if (!method_exists($model, 'add_language') && class_exists('PLL_Admin_Model')) {
                $model = new \PLL_Admin_Model(PLL()->options);
            }
            $result = $model->add_language($args);
        }
        if (is_wp_error($result)) {
            // translators: 1: Language code, 2: Error message.
            return new \WP_Error('LANGUAGE_ADD_FAILED', sprintf(__('Could not add the language %1$s: %2$s', 'transjt-ai'), $code, $result->get_error_message()), ['status' => 500]);
        }
        if ($result === false) {
            // translators: %s: Language code.
            return new \WP_Error('LANGUAGE_ADD_FAILED', sprintf(__('Could not add the language %s', 'transjt-ai'), $code), ['status' => 500]);
        }
        PLL()->model->clean_languages_cache();
        return true;
    }

    // Polylang's own list of languages, moved to src/ in 3.7
    private function polylang_predefined($locale) {
        foreach (['/src/settings/languages.php', '/settings/languages.php'] as $file) {
            if (defined('POLYLANG_DIR') && is_file(POLYLANG_DIR . $file)) {
                $list = include POLYLANG_DIR . $file;
                return is_array($list) && isset($list[$locale]) ? (array) $list[$locale] : [];
            }
        }
        return [];
    }

    // the download link of the current release, when this site's PHP and WordPress can run it
    private function plugin_download($slug) {
        require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        $api = plugins_api('plugin_information', ['slug' => $slug, 'fields' => ['sections' => false]]);
        if (is_wp_error($api) || empty($api->download_link)) {
            // translators: %s: Plugin slug.
            return new \WP_Error('PLUGIN_INSTALL_FAILED', sprintf(__('wordpress.org did not answer for %s', 'transjt-ai'), $slug), ['status' => 502]);
        }
        if (!is_php_version_compatible($api->requires_php ?? null) || !is_wp_version_compatible($api->requires ?? null)) {
            // translators: 1: Plugin slug, 2: PHP version, 3: WordPress version.
            return new \WP_Error('PLUGIN_INCOMPATIBLE', sprintf(__('%1$s needs PHP %2$s and WordPress %3$s', 'transjt-ai'), $slug, $api->requires_php ?? '-', $api->requires ?? '-'), ['status' => 409]);
        }
        return $api->download_link;
    }

    private function install_plugin($slug) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        if (!class_exists('WP_Ajax_Upgrader_Skin')) {
            require_once ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php';
        }

        $download = $this->plugin_download($slug);
        if (is_wp_error($download)) {
            return $download;
        }

        $skin = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader($skin);
        $result = $upgrader->install($download);
        if (!$result || is_wp_error($result)) {
            $message = is_wp_error($result) ? $result->get_error_message() : implode('; ', $skin->get_errors() ?: [__('Unknown installation error', 'transjt-ai')]);
            if ($this->logger) {
                $this->logger->log('Plugin install failed: ' . $message, 'error', ['slug' => $slug]);
            }
            return new \WP_Error('PLUGIN_INSTALL_FAILED', $message, ['status' => 500]);
        }
        wp_clean_plugins_cache();
        return true;
    }

    private function plugin_state($file) {
        if (is_plugin_active($file)) {
            return 'active';
        }
        return isset(get_plugins()[$file]) ? 'inactive' : 'missing';
    }

    // the theme install needs the same, so a site that took the deploy can normally take this too
    private function can_install_plugins() {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        return wp_is_file_mod_allowed('transjt_migration') && get_filesystem_method([], WP_PLUGIN_DIR) === 'direct';
    }

    private function max_body_bytes() {
        $limit = wp_convert_hr_to_bytes((string) ini_get('post_max_size'));
        return $limit > 0 ? $limit : 0;
    }
}
