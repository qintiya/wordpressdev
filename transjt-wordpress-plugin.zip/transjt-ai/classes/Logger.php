<?php
namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

class Logger {
    private static $instance = null;

    const LOG_OPTION_NAME  = 'transjt_logging_enabled';
    const LOG_DATA_OPTION  = 'transjt_log';
    const MAX_LOG_ENTRIES  = 200;

    // $config parameter kept for API compatibility; Logger is instantiated as new Logger($config)
    public function __construct(Config $config) {
        self::$instance = $this;
    }

    /**
     * get singleton instance for static access
     */
    public static function instance() {
        return self::$instance;
    }

    public function is_enabled() {
        return (bool) get_option(self::LOG_OPTION_NAME, false);
    }

    public function enable() {
        update_option(self::LOG_OPTION_NAME, true);
        $this->log('Logging enabled', 'system');
    }

    public function disable() {
        $this->log('Logging disabled', 'system');
        update_option(self::LOG_OPTION_NAME, false);
    }

    /**
     * append a log entry to the wp_options ring buffer (newest entries first)
     */
    public function log($message, $type = 'info', $context = []) {
        if (!$this->is_enabled()) {
            return;
        }

        $entry = [
            'time'    => current_time('Y-m-d H:i:s'),
            'type'    => strtoupper($type),
            'message' => $message,
            'context' => $context,
        ];

        $entries = get_option(self::LOG_DATA_OPTION, []);
        if (!is_array($entries)) {
            $entries = [];
        }

        array_unshift($entries, $entry);

        if (count($entries) > self::MAX_LOG_ENTRIES) {
            $entries = array_slice($entries, 0, self::MAX_LOG_ENTRIES);
        }

        update_option(self::LOG_DATA_OPTION, $entries, false);
    }

    public function log_block_registration($block_name, $success, $details = []) {
        $status = $success ? 'registered' : 'failed';
        $message = sprintf('Block "%s" %s', $block_name, $status);
        $type = $success ? 'block' : 'error';

        $this->log($message, $type, $details);
    }

    public function log_connection($action, $success, $details = []) {
        $status = $success ? 'succeeded' : 'failed';
        $message = sprintf('Connection %s %s', $action, $status);
        $type = $success ? 'connection' : 'error';

        $this->log($message, $type, $details);
    }

    public function log_api($endpoint, $action, $details = []) {
        $message = sprintf('API %s: %s', $endpoint, $action);
        $this->log($message, 'api', $details);
    }

    public function log_api_auth_failure($endpoint, $reason, $details = []) {
        $message = sprintf('API auth failed on %s: %s', $endpoint, $reason);
        $this->log($message, 'error', $details);
    }

    public function log_file_upload($project, $path, $filename, $success, $details = []) {
        $status = $success ? 'uploaded' : 'failed';
        $message = sprintf('File "%s/%s" %s for project "%s"', $path, $filename, $status, $project);
        $type = $success ? 'file' : 'error';

        $this->log($message, $type, $details);
    }

    public function log_asset_upload($project, $filename, $success, $details = []) {
        $status = $success ? 'uploaded' : 'failed';
        $message = sprintf('Asset "%s" %s for project "%s"', $filename, $status, $project);
        $type = $success ? 'asset' : 'error';

        $this->log($message, $type, $details);
    }

    /**
     * return the most recent $lines entries formatted as strings, newest first.
     * format matches the old file-based output so the log viewer is unchanged.
     */
    public function get_logs($lines = 100) {
        $entries = get_option(self::LOG_DATA_OPTION, []);
        if (!is_array($entries) || empty($entries)) {
            return [];
        }

        $entries = array_slice($entries, 0, $lines);
        $result  = [];

        foreach ($entries as $entry) {
            $line = sprintf('[%s] [%s] %s', $entry['time'], $entry['type'], $entry['message']);
            if (!empty($entry['context'])) {
                $line .= ' | Context: ' . wp_json_encode($entry['context']);
            }
            $result[] = $line;
        }

        return $result;
    }

    public function clear_logs() {
        update_option(self::LOG_DATA_OPTION, [], false);
        $this->log('Logs cleared', 'system');
    }

    /**
     * return approximate byte size of stored log data for the admin viewer header
     */
    public function get_log_size() {
        $entries = get_option(self::LOG_DATA_OPTION, []);
        return strlen(wp_json_encode($entries));
    }
}
