<?php
namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

class AdminInterface {
    private $connection_manager;
    private $config;
    private $logger;

    public function __construct(ConnectionManager $connection_manager, Config $config, ?Logger $logger = null) {
        $this->connection_manager = $connection_manager;
        $this->config = $config;
        $this->logger = $logger;

        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_notices', [$this, 'display_notices']);
        add_action('admin_init', [$this, 'handle_logging_actions']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('wp_ajax_transjt_prepare_connection', [$this, 'ajax_prepare_connection']);
        add_action('wp_ajax_transjt_exchange_token', [$this, 'ajax_exchange_token']);
        add_action('wp_ajax_transjt_cancel_connection', [$this, 'ajax_cancel_connection']);
        add_action('wp_ajax_transjt_get_packages',     [$this, 'ajax_get_packages']);
        add_action('wp_ajax_transjt_install_package',  [$this, 'ajax_install_package']);
        add_action('wp_ajax_transjt_delete_package',   [$this, 'ajax_delete_package']);
        add_action('admin_init', [$this, 'handle_templates_actions']);
    }

    public function handle_logging_actions() {
        if (!current_user_can('manage_options') || !$this->logger) {
            return;
        }

        // Handle logging toggle
        if (isset($_POST['transjt_toggle_logging']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['transjt_logging_nonce'] ?? '')), 'transjt_logging_action')) {
            if ($this->logger->is_enabled()) {
                $this->logger->disable();
                Helper::set_notice('success', __('Logging has been disabled.', 'transjt-ai'));
            } else {
                $this->logger->enable();
                Helper::set_notice('success', __('Logging has been enabled.', 'transjt-ai'));
            }
            wp_safe_redirect(admin_url('admin.php?page=transjt-sync'));
            exit;
        }

        // Handle clear logs
        if (isset($_POST['transjt_clear_logs']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['transjt_logging_nonce'] ?? '')), 'transjt_logging_action')) {
            $this->logger->clear_logs();
            Helper::set_notice('success', __('Logs have been cleared.', 'transjt-ai'));
            wp_safe_redirect(admin_url('admin.php?page=transjt-sync'));
            exit;
        }
    }

    public function handle_templates_actions() {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (isset($_POST['transjt_reset_templates']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['transjt_templates_nonce'] ?? '')), 'transjt_templates_action')) {
            $include_parts = !empty($_POST['transjt_reset_template_parts']);
            $tm = new TemplateManager();
            $count = $tm->reset($include_parts);
            // translators: %d: Number of templates reset.
            Helper::set_notice('success', sprintf(__('Successfully reset %d template(s) to their original theme file versions.', 'transjt-ai'), $count));
            wp_safe_redirect(admin_url('admin.php?page=transjt-sync'));
            exit;
        }
    }

    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_transjt-sync') {
            return;
        }

        wp_enqueue_style(
            'transjt-admin',
            TRANSJT_PLUGIN_URL . 'assets/css/admin.css',
            [],
            TRANSJT_VERSION
        );

        wp_enqueue_script(
            'transjt-admin-connect',
            TRANSJT_PLUGIN_URL . 'assets/js/admin-connect.js',
            ['jquery'],
            TRANSJT_VERSION,
            true
        );

        wp_add_inline_style('transjt-admin', '#adminmenu #toplevel_page_transjt-sync .wp-menu-image img { filter: none !important; }');

        wp_localize_script('transjt-admin-connect', 'transjtConnect', [
            'ajaxUrl'       => admin_url('admin-ajax.php'),
            'nonce'         => wp_create_nonce('transjt_connect_nonce'),
            'packagesNonce' => wp_create_nonce('transjt_packages_action'),
            'allowedOrigin' => $this->config->get_allowed_origin(),
            'i18n' => [
                'connecting'      => __('Connecting...', 'transjt-ai'),
                'connectBtn'      => __('Connect to transjt.ai', 'transjt-ai'),
                'error'           => __('Connection failed. Please try again.', 'transjt-ai'),
                'success'         => __('Successfully connected!', 'transjt-ai'),
                'popupBlocked'    => __('Popup blocked. Please allow popups for this site.', 'transjt-ai'),
                'installing'      => __('Installing...', 'transjt-ai'),
                'installBtn'      => __('Install', 'transjt-ai'),
                'reinstallBtn'    => __('Re-install', 'transjt-ai'),
                'installSuccess'  => __('Installed successfully', 'transjt-ai'),
                'installConfirm'  => __('Are you sure you want to install this theme?', 'transjt-ai'),
                'deleteBtn'       => __('Delete', 'transjt-ai'),
                'deleting'        => __('Deleting...', 'transjt-ai'),
                'deleteSuccess'   => __('Deleted successfully', 'transjt-ai'),
                'deleteConfirm'   => __('Are you sure you want to delete this theme?', 'transjt-ai'),
                'loadingPackages' => __('Loading packages...', 'transjt-ai'),
                'noPackages'      => __('No install packages available.', 'transjt-ai'),
                'packagesError'   => __('Failed to load packages. Please try again.', 'transjt-ai'),
                'notInstalled'    => __('Never installed', 'transjt-ai'),
                'installed'       => __('Installed', 'transjt-ai'),
                'created'         => __('Created', 'transjt-ai'),
                'copyReportBtn'   => __('Copy install report', 'transjt-ai'),
                'reportCopied'    => __('Install report copied - paste it into your message to support', 'transjt-ai'),
                'reportCopyError' => __('Could not copy the install report', 'transjt-ai'),
                'installFailed'   => __('Last install failed', 'transjt-ai'),
                'imagesFailed'    => __('Some images were not uploaded', 'transjt-ai'),
            ],
        ]);
    }

    private function log($message, $type = 'info', $context = []) {
        if ($this->logger) {
            $this->logger->log($message, $type, $context);
        }
    }

    /**
     * AJAX handler - generate request_code and return app popup URL
     */
    public function ajax_prepare_connection() {
        check_ajax_referer('transjt_connect_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied', 'transjt-ai')]);
            return;
        }

        $result = $this->connection_manager->prepare_connection();
        wp_send_json_success(['appUrl' => $result['appUrl'], 'requestCode' => $result['requestCode']]);
    }

    /**
     * AJAX handler - exchange request_code for access_key after app confirms
     */
    public function ajax_exchange_token() {
        check_ajax_referer('transjt_connect_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied', 'transjt-ai')]);
            return;
        }

        $request_code = isset($_POST['requestCode']) ? sanitize_text_field(wp_unslash($_POST['requestCode'])) : null;
        $result = $this->connection_manager->exchange_token($request_code);

        if ($result['success']) {
            wp_send_json_success(['message' => $result['message']]);
        } else {
            wp_send_json_error(['message' => $result['message']]);
        }
    }

    /**
     * AJAX handler - cancel pending connection
     */
    public function ajax_cancel_connection() {
        check_ajax_referer('transjt_connect_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            $this->log('Admin AJAX cancel_connection: permission denied', 'error');
            wp_send_json_error(['message' => __('Permission denied', 'transjt-ai')]);
            return;
        }

        $this->connection_manager->cancel_pending_connection();
        wp_send_json_success();
    }

    /**
     * AJAX handler - fetch available theme packages from the backend
     */
    public function ajax_get_packages() {
        check_ajax_referer('transjt_packages_action', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied', 'transjt-ai')]);
            return;
        }

        $packages = $this->connection_manager->get_packages();

        if (is_wp_error($packages)) {
            wp_send_json_error(['message' => $packages->get_error_message()]);
            return;
        }

        wp_send_json_success(['packages' => $packages]);
    }

    /**
     * AJAX handler - fetch package details, download and install the theme ZIP, then acknowledge
     */
    public function ajax_install_package() {
        check_ajax_referer('transjt_packages_action', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied', 'transjt-ai')]);
            return;
        }

        $package_id = isset($_POST['package_id']) ? sanitize_text_field(wp_unslash($_POST['package_id'])) : '';
        if (empty($package_id)) {
            wp_send_json_error(['message' => __('Missing package ID', 'transjt-ai')]);
            return;
        }

        $details = $this->connection_manager->get_package_details($package_id);

        if (is_wp_error($details)) {
            wp_send_json_error(['message' => $details->get_error_message()]);
            return;
        }

        $installer = new ThemeInstaller($this->logger);
        $result = $installer->install_from_details([
            'project'  => $details['slug'] ?? $package_id,
            'zip_url'  => $details['zip_url'] ?? '',
            'zip_hash' => $details['zip_hash'] ?? '',
        ]);

        $this->connection_manager->acknowledge_installation(
            $package_id,
            $result['success'] ? 'installed' : 'failed',
            $result['success'] ? null : $result['message'],
            $result['report']
        );

        if ($result['success']) {
            $theme_slug = $details['slug'] ?? $package_id;
            if ($theme_slug === get_stylesheet()) {
                Helper::run_cf7_setup(get_template_directory());
            }
            wp_send_json_success(['message' => $result['message'], 'report' => $result['report']]);
        } else {
            wp_send_json_error(['message' => $result['message'], 'report' => $result['report']]);
        }
    }

    public function ajax_delete_package() {
        check_ajax_referer('transjt_packages_action', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied', 'transjt-ai')]);
            return;
        }

        $package_id = isset($_POST['package_id']) ? sanitize_text_field(wp_unslash($_POST['package_id'])) : '';
        if (empty($package_id)) {
            wp_send_json_error(['message' => __('Missing package ID', 'transjt-ai')]);
            return;
        }

        if ($this->connection_manager->delete_package($package_id)) {
            wp_send_json_success();
        } else {
            wp_send_json_error(['message' => __('Failed to delete package', 'transjt-ai')]);
        }
    }

    public function add_menu() {
        add_menu_page(
            'transjt.ai',
            'transjt.ai',
            'manage_options',
            'transjt-sync',
            [$this, 'render_page'],
            TRANSJT_PLUGIN_URL . 'assets/images/transjt-icon.svg',
            80
        );
    }

    public function display_notices() {
        $notice = Helper::get_notice();

        if (!$notice) {
            return;
        }

        $notice_class = $notice['type'] === 'success' ? 'notice-success' : 'notice-error';
        ?>
        <div class="notice <?php echo esc_attr($notice_class); ?> is-dismissible">
            <p><?php echo esc_html($notice['message']); ?></p>
        </div>
        <?php
    }

    public function render_page() {
        $is_connected = $this->connection_manager->check_status();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab navigation, no data modification
        $current_tab = isset($_GET['tab']) ? sanitize_text_field(wp_unslash($_GET['tab'])) : 'settings';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

            <?php $this->render_tabs($current_tab); ?>

            <?php if ($current_tab === 'settings'): ?>
                <?php $this->render_status_box($is_connected); ?>
                <?php $this->render_info_section(); ?>
                <?php $this->render_connection_form($is_connected); ?>
                <?php $this->render_templates_section(); ?>
                <?php $this->render_logging_settings(); ?>
            <?php elseif ($current_tab === 'themes'): ?>
                <?php $this->render_packages_section($is_connected); ?>
            <?php elseif ($current_tab === 'logs'): ?>
                <?php $this->render_log_viewer(); ?>
            <?php endif; ?>
        </div>
        <?php
    }

    private function render_tabs($current_tab) {
        $tabs = [
            'settings' => __('Settings', 'transjt-ai'),
            'themes'   => __('Install packages', 'transjt-ai'),
            'logs'     => __('Log viewer', 'transjt-ai'),
        ];
        ?>
        <nav class="nav-tab-wrapper">
            <?php foreach ($tabs as $tab_key => $tab_label): ?>
                <a href="<?php echo esc_url(admin_url('admin.php?page=transjt-sync&tab=' . $tab_key)); ?>"
                   class="nav-tab <?php echo esc_attr($current_tab === $tab_key ? 'nav-tab-active' : ''); ?>">
                    <?php echo esc_html($tab_label); ?>
                </a>
            <?php endforeach; ?>
        </nav>
        <br>
        <?php
    }

    private function render_status_box($is_connected) {
        if ($is_connected) {
            ?>
            <div class="notice notice-success">
                <p><strong><?php esc_html_e('Status:', 'transjt-ai'); ?></strong> <?php esc_html_e('Connected to transjt.ai', 'transjt-ai'); ?></p>
            </div>
            <?php
        } else {
            ?>
            <div class="notice notice-warning">
                <p><strong><?php esc_html_e('Status:', 'transjt-ai'); ?></strong> <?php esc_html_e('Not connected to transjt.ai', 'transjt-ai'); ?></p>
            </div>
            <?php
        }
    }

    private function render_connection_form($is_connected) {
        ?>
        <hr>
        <form method="post" action="">
            <?php wp_nonce_field('transjt_connect_action', 'transjt_connect_nonce'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('Connection', 'transjt-ai'); ?></th>
                    <td>
                        <?php if ($is_connected): ?>
                            <?php // translators: %s: Site URL wrapped in code tags. ?>
                            <p><?php echo wp_kses(sprintf(__('Your site (%s) is connected to transjt.ai.', 'transjt-ai'), '<code>' . esc_html(get_site_url()) . '</code>'), ['code' => []]); ?></p>
                            <input type="submit"
                                   class="button button-secondary transjt-disconnect-btn"
                                   name="transjt_disconnect"
                                   value="<?php esc_attr_e('Disconnect', 'transjt-ai'); ?>"
                                   onclick="return confirm('<?php echo esc_js(__('Are you sure you want to disconnect from transjt.ai?', 'transjt-ai')); ?>');" />
                        <?php else: ?>
                            <p><?php echo wp_kses_post(\__("Connect your WP installation to <a href='https://app.transjt.ai' target='_blank'>transjt.ai</a> app to enable automatic synchronization", 'transjt-ai')); ?></p>
                            <button type="button"
                                    id="transjt-connect-btn"
                                    class="button button-primary transjt-disconnect-btn">
                                <?php esc_html_e('Connect to transjt.ai', 'transjt-ai'); ?>
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </form>
        <?php
    }

    private function render_info_section() {
        ?>
        <br>
        <img src='<?php echo \esc_url(TRANSJT_PLUGIN_URL . 'assets/images/transjt-logo.svg'); ?>' class="transjt-info-logo"><br>
        <h2><?php esc_html_e('From Figma to WordPress — up to 17× faster with 80% less development time.', 'transjt-ai'); ?></h2>
        <p>
            <?php esc_html_e('transjt is an AI-powered platform that bridges the gap between design and development. By integrating Figma designs directly into WordPress, it helps to launch polished, functional websites in a fraction of the time — saving up to 80% of development effort.', 'transjt-ai'); ?>
        </p>

        <h3><?php esc_html_e('Need Help?', 'transjt-ai'); ?></h3>
        <p>
            <?php echo wp_kses_post(__('Visit <a href="https://transjt.ai/how-to-work-with-transjt-hubspot-wordpress" target="_blank">transjt.ai knowledge hub</a> for more information or <a href="mailto:support@transjt.ai">reach out</a> to the support.', 'transjt-ai')); ?>
        </p>
        <?php
    }

    private function render_packages_section($is_connected) {
        if (!$is_connected) {
            ?>
            <div class="notice notice-warning">
                <p><?php esc_html_e('Connect to transjt.ai first to install theme packages.', 'transjt-ai'); ?></p>
            </div>
            <?php
            return;
        }
        ?>
        <div id="transjt-packages-section">
            <p class="description transjt-packages-loading"><?php esc_html_e('Loading packages...', 'transjt-ai'); ?></p>
            <table class="wp-list-table widefat fixed striped transjt-packages-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Preview', 'transjt-ai'); ?></th>
                        <th><?php esc_html_e('Project', 'transjt-ai'); ?></th>
                        <th><?php esc_html_e('Package actions', 'transjt-ai'); ?></th>
                    </tr>
                </thead>
                <tbody class="transjt-packages-list"></tbody>
            </table>
            <p class="transjt-packages-empty notice notice-info inline"><?php esc_html_e('No install packages available.', 'transjt-ai'); ?></p>
            <p class="transjt-packages-error notice notice-error inline"></p>
        </div>
        <?php
    }

    private function render_templates_section() {
        $tm             = new TemplateManager();
        $is_transjt     = $tm->is_transjt_theme();
        $templates      = $is_transjt ? $tm->get_modified_templates() : [];
        $template_parts = $is_transjt ? $tm->get_modified_template_parts() : [];
        $has_overrides  = !empty($templates) || !empty($template_parts);
        ?>
        <hr>
        <form method="post" action="">
            <?php wp_nonce_field('transjt_templates_action', 'transjt_templates_nonce'); ?>
            <input type="hidden" name="transjt_reset_templates" value="1">
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('Templates reset', 'transjt-ai'); ?></th>
                    <td>
                        <div class="notice notice-warning inline">
                            <p><?php esc_html_e('Use this feature if you experience issues with templates display', 'transjt-ai'); ?></p>
                        </div>
                        <p class="transjt-template-desc">
                            <?php esc_html_e('Active theme:', 'transjt-ai'); ?> <strong><?php echo esc_html($tm->get_theme_name()); ?></strong>
                        </p>

                        <?php if (!$is_transjt): ?>
                            <p class="description"><?php esc_html_e('This feature is only applicable to transjt-generated themes.', 'transjt-ai'); ?></p>
                            <button class="button button-secondary" disabled><?php esc_html_e('Reset all templates', 'transjt-ai'); ?></button>

                        <?php else: ?>
                            <?php if (!empty($templates)): ?>
                                <p><?php esc_html_e('Modified templates to reset:', 'transjt-ai'); ?></p>
                                <ul class="transjt-template-list">
                                    <?php foreach ($templates as $tpl):
                                        $slug = preg_replace('/^[^\/]+\/\//', '', $tpl->post_name);
                                    ?>
                                        <li><strong><?php echo esc_html($tpl->post_title); ?></strong> <code><?php echo esc_html($slug); ?>.html</code></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>

                            <?php if (!empty($template_parts)): ?>
                                <label>
                                    <input type="checkbox" name="transjt_reset_template_parts" value="1">
                                    <?php esc_html_e('Reset template parts as well:', 'transjt-ai'); ?>
                                </label>
                                <ul class="transjt-template-list">
                                    <?php foreach ($template_parts as $part):
                                        $slug = preg_replace('/^[^\/]+\/\//', '', $part->post_name);
                                    ?>
                                        <li><strong><?php echo esc_html($part->post_title); ?></strong> <code><?php echo esc_html($slug); ?>.html</code></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>

                            <?php if ($has_overrides): ?>
                                <p class="transjt-reset-warning"><?php echo wp_kses_post(__('Reverting templates to their original versions <strong>cannot be undone</strong>.', 'transjt-ai')); ?></p>
                                <button type="submit" class="button button-secondary transjt-reset-btn"
                                        onclick="return confirm('<?php echo esc_js(__('Are you sure? All manually modified templates will be reset to their theme file versions. This cannot be undone.', 'transjt-ai')); ?>');">
                                    <?php esc_html_e('Reset all templates', 'transjt-ai'); ?>
                                </button>
                            <?php else: ?>
                                <p class="description"><?php esc_html_e('Nothing to reset — all templates are at their original versions.', 'transjt-ai'); ?></p>
                                <button class="button button-secondary transjt-reset-btn" disabled><?php esc_html_e('Reset all templates', 'transjt-ai'); ?></button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </form>
        <?php
    }

    private function render_logging_settings() {
        if (!$this->logger) {
            return;
        }

        $is_enabled = $this->logger->is_enabled();
        ?>
        <hr>
        <form method="post" action="">
            <?php wp_nonce_field('transjt_logging_action', 'transjt_logging_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('Enable logging', 'transjt-ai'); ?></th>
                    <td>
                        <label>
                            <input type="hidden" name="transjt_toggle_logging" value="1">
                            <button type="submit" class="button <?php echo esc_attr($is_enabled ? 'button-secondary' : 'button-primary'); ?>">
                                <?php echo $is_enabled ? esc_html(__('Disable logging', 'transjt-ai')) : esc_html(__('Enable logging', 'transjt-ai')); ?>
                            </button>
                        </label>
                        <p class="description">
                            <?php if ($is_enabled): ?>
                                <?php echo wp_kses_post(__('Logging is currently <strong>enabled</strong>. Connection, API, file uploads, asset uploads, and block registration events are being recorded.', 'transjt-ai')); ?>
                            <?php else: ?>
                                <?php esc_html_e('Enable logging to track connection, API, file uploads, asset uploads, and block registration events.', 'transjt-ai'); ?>
                            <?php endif; ?>
                        </p>
                    </td>
                </tr>
            </table>
        </form>
        <?php
    }

    private function render_log_viewer() {
        if (!$this->logger) {
            ?>
            <div class="notice notice-error">
                <p><?php esc_html_e('Logger is not available.', 'transjt-ai'); ?></p>
            </div>
            <?php
            return;
        }

        $is_enabled = $this->logger->is_enabled();
        $logs = $this->logger->get_logs(200);
        $log_size = $this->logger->get_log_size();
        ?>
        <div class="transjt-log-viewer">
            <div class="transjt-log-header">
                <div>
                    <strong><?php esc_html_e('Status:', 'transjt-ai'); ?></strong>
                    <?php if ($is_enabled): ?>
                        <span class="transjt-status-enabled">&#9679; <?php esc_html_e('Enabled', 'transjt-ai'); ?></span>
                    <?php else: ?>
                        <span class="transjt-status-disabled">&#9675; <?php esc_html_e('Disabled', 'transjt-ai'); ?></span>
                    <?php endif; ?>
                    &nbsp;&nbsp;|&nbsp;&nbsp;
                    <strong><?php esc_html_e('Log size:', 'transjt-ai'); ?></strong> <?php echo esc_html(size_format($log_size)); ?>
                </div>
                <div>
                    <?php if (!empty($logs)): ?>
                        <form method="post" action="" class="transjt-clear-form">
                            <?php wp_nonce_field('transjt_logging_action', 'transjt_logging_nonce'); ?>
                            <input type="hidden" name="transjt_clear_logs" value="1">
                            <button type="submit" class="button button-secondary" onclick="return confirm('<?php echo esc_js(__('Are you sure you want to clear all logs?', 'transjt-ai')); ?>');">
                                <?php esc_html_e('Clear Logs', 'transjt-ai'); ?>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (empty($logs)): ?>
                <div class="notice notice-info">
                    <p><?php esc_html_e('No log entries yet.', 'transjt-ai'); ?>
                        <?php if (!$is_enabled): ?>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=transjt-sync&tab=settings')); ?>"><?php esc_html_e('Enable logging', 'transjt-ai'); ?></a> <?php esc_html_e('to start recording events.', 'transjt-ai'); ?>
                        <?php endif; ?>
                    </p>
                </div>
            <?php else: ?>
                <div class="transjt-log-output">
                    <?php foreach ($logs as $log_line): ?>
                        <?php
                        $line_class = 'transjt-log-line';
                        if (strpos($log_line, '[ERROR]') !== false) {
                            $line_class .= ' log-error';
                        } elseif (strpos($log_line, '[CONNECTION]') !== false) {
                            $line_class .= ' log-connection';
                        } elseif (strpos($log_line, '[API]') !== false) {
                            $line_class .= ' log-api';
                        } elseif (strpos($log_line, '[FILE]') !== false) {
                            $line_class .= ' log-file';
                        } elseif (strpos($log_line, '[ASSET]') !== false) {
                            $line_class .= ' log-asset';
                        } elseif (strpos($log_line, '[BLOCK]') !== false) {
                            $line_class .= ' log-block';
                        } elseif (strpos($log_line, '[SYSTEM]') !== false) {
                            $line_class .= ' log-system';
                        } elseif (strpos($log_line, '[INFO]') !== false) {
                            $line_class .= ' log-info';
                        }
                        ?>
                        <div class="<?php echo esc_attr($line_class); ?>">
                            <?php echo esc_html($log_line); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p class="description transjt-log-meta">
                    <?php
                    // translators: %d: Number of log entries shown.
                    printf( esc_html__( 'Showing the most recent %d log entries (newest first).', 'transjt-ai' ), count( $logs ) ); ?>
                </p>
            <?php endif; ?>
        </div>
        <?php
    }
}
