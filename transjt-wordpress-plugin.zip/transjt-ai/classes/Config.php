<?php
namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

class Config {
    private $config = [];
    
    public function __construct() {
        $this->config = [
            'access_key_option_name' => 'transjt_sync_access_key',
            'access_key_header' => 'X-Transjt-Access-Key',
            'rest_namespace' => 'transjt/sync',
            'plugin_dir' => TRANSJT_PLUGIN_DIR,
            'plugin_url' => TRANSJT_PLUGIN_URL,
        ];
    }
    
    public function get($key, $default = null) {
        return $this->config[$key] ?? $default;
    }
    
    public function set($key, $value) {
        $this->config[$key] = $value;
    }
    
    public function all() {
        return $this->config;
    }
    
    /**
     * get allowed origin for postMessage validation (extracted from app connect URL)
     */
    public function get_allowed_origin() {
        $parsed = wp_parse_url(TRANSJT_APP_CONNECT_ENDPOINT);
        return $parsed['scheme'] . '://' . $parsed['host'];
    }

    public function get_access_key() {
        return get_option($this->get('access_key_option_name'));
    }
    
    public function set_access_key($key) {
        return update_option($this->get('access_key_option_name'), $key);
    }
    
    public function delete_access_key() {
        return delete_option($this->get('access_key_option_name'));
    }
    
    public function has_access_key() {
        return !empty($this->get_access_key());
    }
}