<?php
namespace Transjt;

// SPDX-License-Identifier: GPL-2.0-or-later

if (!defined('ABSPATH')) exit;

class DependencyManager {
    /**
     * list of recommended plugins with their WordPress.org slugs
     */
    private $recommended_plugins = [
        'contact-form-7' => [
            'name' => 'Contact Form 7',
            'file' => 'contact-form-7/wp-contact-form-7.php',
        ],
    ];

    private function is_plugin_installed($plugin_file) {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $installed_plugins = get_plugins();
        return isset($installed_plugins[$plugin_file]);
    }

    /**
     * get list of missing dependencies for admin notices
     */
    public function get_missing_dependencies() {
        $missing = [];

        foreach ($this->recommended_plugins as $slug => $plugin_info) {
            if (!$this->is_plugin_installed($plugin_info['file'])) {
                $missing[$slug] = $plugin_info;
                $missing[$slug]['status'] = 'not_installed';
            } elseif (!is_plugin_active($plugin_info['file'])) {
                $missing[$slug] = $plugin_info;
                $missing[$slug]['status'] = 'inactive';
            }
        }

        return $missing;
    }
}
