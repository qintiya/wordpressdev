<?php
namespace Transjt\SvgSanitize\data;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Interface TagInterface
 *
 * @package Transjt\SvgSanitize\tags
 */
interface TagInterface
{

    /**
     * Returns an array of tags
     *
     * @return array
     */
    public static function getTags();

}