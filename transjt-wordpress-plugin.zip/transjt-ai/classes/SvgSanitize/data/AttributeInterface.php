<?php
namespace Transjt\SvgSanitize\data;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Class AttributeInterface
 *
 * @package Transjt\SvgSanitize\data
 */
interface AttributeInterface
{

    /**
     * Returns an array of attributes
     *
     * @return array
     */
    public static function getAttributes();
}
