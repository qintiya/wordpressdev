<?php
/**
 * Plugin Name: transjt.ai
 * Description: Use this plugin to automatically convert your Figma designs directly into functional WordPress theme and launch polished, functional websites in a fraction of the time — saving up to 80% of development effort.
 * Version: 3.3.7
 * Author: transjt Inc.
 * Author URI: https://transjt.ai
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: transjt-ai
 * Domain Path: /languages
 * Requires at least: 6.0
 * Tested up to: 7.1.3
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

define('TRANSJT_ENDPOINT', 'https://backend.transjt.ai/api/integrations/wp');
define('TRANSJT_STATUS_ENDPOINT', 'https://backend.transjt.ai/api/integrations/wp/status');
define('TRANSJT_TOKEN_ENDPOINT', 'https://backend.transjt.ai/api/integrations/wp/token');
define('TRANSJT_APP_CONNECT_ENDPOINT', 'https://app.transjt.ai/connect-wp');
define('TRANSJT_PACKAGES_ENDPOINT', 'https://backend.transjt.ai/api/integrations/wp/install-packages');
define('TRANSJT_ALLOWED_DOMAINS', 'backend.transjt.ai,render.transjt.ai');
define('TRANSJT_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('TRANSJT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TRANSJT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('TRANSJT_VERSION', '3.3.7');
define('TRANSJT_ENV', 'live');
define('TRANSJT_UPDATE_INFO_URL', 'https://backend.transjt.ai/api/config/wp/plugin/update-info?v=2');
define('TRANSJT_UPDATE_CACHE_TTL', (int)'300');

if (TRANSJT_ENV === 'local') {
    add_filter('http_request_args', function ($args) {
        $args['reject_unsafe_urls'] = false;
        return $args;
    });
}

if (file_exists(TRANSJT_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once TRANSJT_PLUGIN_DIR . 'vendor/autoload.php';
}

spl_autoload_register(function ($class) {
    if (strpos($class, 'Transjt\\') !== 0) {
        return;
    }
    $class = str_replace('Transjt\\', '', $class);
    $file = TRANSJT_PLUGIN_DIR . 'classes/' . str_replace('\\', '/', $class) . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

register_activation_hook(__FILE__, 'transjt_activation');

function transjt_activation() {
    Transjt\MigrationContent::add_types_option();
    flush_rewrite_rules();
}

function transjt_init() {
    $config = new Transjt\Config();
    $logger = new Transjt\Logger($config);
    $asset_handler = new Transjt\AssetHandler($logger);
    $connection_manager = new Transjt\ConnectionManager($config, $logger);
    $migration_site = new Transjt\MigrationSite($logger);
    // registers the collection post types and serves the redirects on every request
    $migration_content = new Transjt\MigrationContent($logger);
    $rest_api = new Transjt\RestApiManager($config, $asset_handler, $logger, $connection_manager, $migration_site, $migration_content);
    $admin = new Transjt\AdminInterface($connection_manager, $config, $logger);
    new Transjt\UpdateManager($logger);
    add_action('admin_notices', 'transjt_show_dependency_notices');
}

add_action('plugins_loaded', 'transjt_init');

function transjt_show_dependency_notices() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $dependency_manager = new Transjt\DependencyManager();
    $missing = $dependency_manager->get_missing_dependencies();

    foreach ($missing as $slug => $info) {
        $notice_kses = ['a' => ['href' => []]];
        if ($info['status'] === 'not_installed') {
            $url = admin_url('plugin-install.php?s=' . urlencode($slug) . '&tab=search&type=term');
            echo '<div class="notice notice-warning is-dismissible"><p>';
            // translators: 1: Plugin name, 2: URL to install plugin.
            echo wp_kses(sprintf(__('transjt.ai recommends the "%1$s" plugin for full functionality. Please <a href="%2$s">install it</a>.', 'transjt-ai'), esc_html($info['name']), esc_url($url)), $notice_kses);
            echo '</p></div>';
        } else {
            $url = admin_url('plugins.php');
            echo '<div class="notice notice-warning is-dismissible"><p>';
            // translators: 1: Plugin name, 2: URL to activate plugin.
            echo wp_kses(sprintf(__('transjt.ai recommends activating the "%1$s" plugin for full functionality. Please <a href="%2$s">activate it</a>.', 'transjt-ai'), esc_html($info['name']), esc_url($url)), $notice_kses);
            echo '</p></div>';
        }
    }
}