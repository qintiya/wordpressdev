<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;

// SPDX-License-Identifier: GPL-2.0-or-later

delete_option('transjt_sync_access_key');
delete_option('transjt_logging_enabled');
delete_option('transjt_log');
delete_transient('transjt_request_code');
delete_transient('transjt_connection_status');
delete_transient('transjt_admin_notice');

delete_post_meta_by_key('_transjt_project');
